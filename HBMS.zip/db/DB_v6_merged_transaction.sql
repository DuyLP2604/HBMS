﻿USE [master];
GO

IF DB_ID(N'QLKS') IS NOT NULL
BEGIN
    ALTER DATABASE QLKS SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE QLKS;
END;
GO

CREATE DATABASE QLKS;
GO

USE QLKS;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
GO

CREATE TABLE HOTEL (
    HotelName NVARCHAR(50) NOT NULL,
    HotelImage NVARCHAR(100) NULL,
    RoomImage NVARCHAR(100) NULL,
    PoolImage NVARCHAR(100) NULL,
    RestaurantImage NVARCHAR(100) NULL,
    Address NVARCHAR(500) NOT NULL,

    CONSTRAINT PK_HOTEL PRIMARY KEY (HotelName),
    CONSTRAINT CK_HOTEL_SingleHotel CHECK (HotelName = N'Simple Bear Hotel')
);
GO

CREATE TABLE USERS (
    UserID INT IDENTITY(1,1) NOT NULL,
    Username VARCHAR(50) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Role VARCHAR(50) NOT NULL,
    MustChangePassword BIT NOT NULL CONSTRAINT DF_USERS_MustChangePassword DEFAULT (0),

    CONSTRAINT PK_USERS PRIMARY KEY (UserID),
    CONSTRAINT UQ_USERS_Username UNIQUE (Username),
    CONSTRAINT CK_USERS_Role
    CHECK (
        Role IN (
            'Admin',
            'Staff',
            'Customer'
        )
    )
);
GO

CREATE TABLE NATIONALITY (
    NationalityID VARCHAR(50) NOT NULL,
    NationalityName NVARCHAR(100) NOT NULL,

    CONSTRAINT PK_NATIONALITY PRIMARY KEY (NationalityID),
    CONSTRAINT UQ_NATIONALITY_Name UNIQUE (NationalityName)
);
GO

CREATE TABLE CUSTOMER (
    CustomerID CHAR(6) NOT NULL,
    FullName NVARCHAR(100) NOT NULL,
    Phone VARCHAR(15) NULL,
    Email VARCHAR(100) NULL,
    Address NVARCHAR(200) NULL,
    NationalityID VARCHAR(50) NULL,
    UserID INT NOT NULL,

    CONSTRAINT PK_CUSTOMER PRIMARY KEY (CustomerID),
    CONSTRAINT UQ_CUSTOMER_User UNIQUE (UserID),
    CONSTRAINT UQ_CUSTOMER_Email UNIQUE (Email),
    CONSTRAINT FK_CUSTOMER_USERS
        FOREIGN KEY (UserID) REFERENCES USERS(UserID),
    CONSTRAINT FK_CUSTOMER_NATIONALITY
        FOREIGN KEY (NationalityID) REFERENCES NATIONALITY(NationalityID)
);
GO

CREATE TABLE ROOM_TYPE (
    RoomTypeID CHAR(4) NOT NULL,
    TypeName NVARCHAR(50) NOT NULL,
    Capacity INT NOT NULL,
    Price DECIMAL(12,2) NOT NULL,
    RoomTypeImage NVARCHAR(255) NULL,
    Description NVARCHAR(500) NULL,

    CONSTRAINT PK_ROOM_TYPE PRIMARY KEY (RoomTypeID),
    CONSTRAINT UQ_ROOM_TYPE_Name UNIQUE (TypeName),
    CONSTRAINT CK_ROOM_TYPE_Capacity CHECK (Capacity > 0),
    CONSTRAINT CK_ROOM_TYPE_Price CHECK (Price >= 0)
);
GO

CREATE TABLE ROOM (
    RoomID CHAR(3) NOT NULL,
    RoomNumber NVARCHAR(20) NOT NULL,
    RoomImage NVARCHAR(100) NULL,
    Status VARCHAR(20) NOT NULL
        CONSTRAINT DF_ROOM_Status DEFAULT 'ACTIVE',
    RoomTypeID CHAR(4) NOT NULL,

    CONSTRAINT PK_ROOM PRIMARY KEY (RoomID),
    CONSTRAINT UQ_ROOM_Number UNIQUE (RoomNumber),
    CONSTRAINT FK_ROOM_ROOM_TYPE
        FOREIGN KEY (RoomTypeID) REFERENCES ROOM_TYPE(RoomTypeID),
    CONSTRAINT CK_ROOM_Status
        CHECK (Status IN ('ACTIVE', 'MAINTENANCE', 'INACTIVE'))
);
GO

CREATE TABLE EMPLOYEE (
    EmployeeID CHAR(6) NOT NULL,
    FullName NVARCHAR(100) NOT NULL,
    Position NVARCHAR(50) NOT NULL,
    Salary DECIMAL(12,2) NULL,
    Shift NVARCHAR(20) NULL,
    Address NVARCHAR(200) NULL,
    Phone VARCHAR(20) NULL,
    Email VARCHAR(100) NULL,
    UserID INT NOT NULL,

    CONSTRAINT PK_EMPLOYEE PRIMARY KEY (EmployeeID),
    CONSTRAINT UQ_EMPLOYEE_User UNIQUE (UserID),
    CONSTRAINT UQ_EMPLOYEE_Phone UNIQUE (Phone),
    CONSTRAINT FK_EMPLOYEE_USERS
        FOREIGN KEY (UserID) REFERENCES USERS(UserID),
    CONSTRAINT CK_EMPLOYEE_Salary
        CHECK (Salary IS NULL OR Salary >= 0)
);
GO

CREATE UNIQUE INDEX UQ_EMPLOYEE_Email
    ON dbo.EMPLOYEE (Email)
    WHERE Email IS NOT NULL;
GO

CREATE TABLE BOOKING (
    BookingID CHAR(6) NOT NULL,
    PaymentOption VARCHAR(10) NOT NULL
        CONSTRAINT DF_BOOKING_PaymentOption DEFAULT 'FULL',
    FirstPaidAt DATETIME2(3) NULL,
    BookingAmountAtFirstPayment DECIMAL(12,2) NULL,
    RefundDeadline AS DATEADD(HOUR, 24, FirstPaidAt) PERSISTED,
    CancelledAt DATETIME2(3) NULL,
    CancellationReason VARCHAR(30) NULL,
    CancelledByUserID INT NULL,
    BookingDate DATETIME NOT NULL
        CONSTRAINT DF_BOOKING_BookingDate DEFAULT GETDATE(),
    PaymentDeadline DATETIME NULL,
    CheckInDate DATE NOT NULL,
    CheckOutDate DATE NOT NULL,
    BookingStatus VARCHAR(30) NOT NULL,
    GuestCCCDs VARCHAR(500) NULL,
    BookedByUserID INT NULL,
    CustomerID CHAR(6) NOT NULL,
    TotalAmount DECIMAL(12,2) NOT NULL
        CONSTRAINT DF_BOOKING_TotalAmount DEFAULT 0,

    CONSTRAINT PK_BOOKING PRIMARY KEY (BookingID),
    CONSTRAINT UQ_BOOKING_CustomerBooking UNIQUE (CustomerID, BookingID),
    CONSTRAINT FK_BOOKING_CancelledBy FOREIGN KEY (CancelledByUserID) REFERENCES USERS(UserID),
    CONSTRAINT CK_BOOKING_PaymentOption CHECK (PaymentOption IN ('DEPOSIT', 'FULL')),
    CONSTRAINT CK_BOOKING_FirstPayment CHECK (
        (FirstPaidAt IS NULL AND BookingAmountAtFirstPayment IS NULL)
        OR (FirstPaidAt IS NOT NULL AND BookingAmountAtFirstPayment IS NOT NULL AND BookingAmountAtFirstPayment > 0)
    ),
    CONSTRAINT CK_BOOKING_CancellationReason CHECK (
        CancellationReason IS NULL OR CancellationReason IN (
            'CUSTOMER_REQUEST', 'STAFF_REQUEST', 'PAYMENT_TIMEOUT'
        )
    ),
    CONSTRAINT FK_BOOKING_BookedByUser FOREIGN KEY (BookedByUserID) REFERENCES USERS(UserID),
    CONSTRAINT FK_BOOKING_CUSTOMER
        FOREIGN KEY (CustomerID) REFERENCES CUSTOMER(CustomerID),
    CONSTRAINT CK_BOOKING_Date
        CHECK (CheckOutDate > CheckInDate),
    CONSTRAINT CK_BOOKING_Status
        CHECK (BookingStatus IN (
            'PENDING_PAYMENT',
            'CONFIRMED',
            'ASSIGNED',
            'CHECKED_IN',
            'CHECKED_OUT',
            'CANCELLED'
        )),
    CONSTRAINT CK_BOOKING_TotalAmount CHECK (TotalAmount >= 0),
    CONSTRAINT CK_BOOKING_PaymentDeadline CHECK (
        BookingStatus <> 'PENDING_PAYMENT'
        OR PaymentDeadline IS NOT NULL
    )
);
GO

CREATE TABLE BOOKING_DETAIL (
    BookingDetailID INT IDENTITY(1,1) NOT NULL,
    BookingID CHAR(6) NOT NULL,
    RoomTypeID CHAR(4) NOT NULL,
    Quantity INT NOT NULL,
    GuestCount INT NOT NULL,
    UnitPrice DECIMAL(12,2) NOT NULL,
    Subtotal DECIMAL(12,2) NOT NULL,

    CONSTRAINT PK_BOOKING_DETAIL PRIMARY KEY (BookingDetailID),
    CONSTRAINT UQ_BOOKING_DETAIL_Type
        UNIQUE (BookingID, RoomTypeID),
    CONSTRAINT FK_BOOKING_DETAIL_BOOKING
        FOREIGN KEY (BookingID) REFERENCES BOOKING(BookingID),
    CONSTRAINT FK_BOOKING_DETAIL_ROOM_TYPE
        FOREIGN KEY (RoomTypeID) REFERENCES ROOM_TYPE(RoomTypeID),
    CONSTRAINT CK_BOOKING_DETAIL_Quantity CHECK (Quantity > 0),
    CONSTRAINT CK_BOOKING_DETAIL_GuestCount CHECK (GuestCount > 0),
    CONSTRAINT CK_BOOKING_DETAIL_UnitPrice CHECK (UnitPrice >= 0),
    CONSTRAINT CK_BOOKING_DETAIL_Subtotal CHECK (Subtotal >= 0)
);
GO

CREATE TABLE ROOM_ASSIGNMENT (
    AssignmentID INT IDENTITY(1,1) NOT NULL,
    BookingDetailID INT NOT NULL,
    RoomID CHAR(3) NOT NULL,
    EmployeeID CHAR(6) NULL,
    AssignedAt DATETIME NOT NULL
        CONSTRAINT DF_ROOM_ASSIGNMENT_AssignedAt DEFAULT GETDATE(),

    CONSTRAINT PK_ROOM_ASSIGNMENT PRIMARY KEY (AssignmentID),
    CONSTRAINT UQ_ROOM_ASSIGNMENT_DetailRoom
        UNIQUE (BookingDetailID, RoomID),
    CONSTRAINT FK_ROOM_ASSIGNMENT_DETAIL
        FOREIGN KEY (BookingDetailID)
        REFERENCES BOOKING_DETAIL(BookingDetailID),
    CONSTRAINT FK_ROOM_ASSIGNMENT_ROOM
        FOREIGN KEY (RoomID) REFERENCES ROOM(RoomID),
    CONSTRAINT FK_ROOM_ASSIGNMENT_EMPLOYEE
        FOREIGN KEY (EmployeeID) REFERENCES EMPLOYEE(EmployeeID)
);
GO

CREATE TABLE SERVICE (
    ServiceID CHAR(4) NOT NULL,
    ServiceName NVARCHAR(60) NOT NULL,
    UnitPrice DECIMAL(12,2) NOT NULL,

    CONSTRAINT PK_SERVICE PRIMARY KEY (ServiceID),
    CONSTRAINT UQ_SERVICE_Name UNIQUE (ServiceName),
    CONSTRAINT CK_SERVICE_UnitPrice CHECK (UnitPrice >= 0)
);
GO

CREATE TABLE BOOKING_SERVICE (
    BookingID CHAR(6) NOT NULL,
    ServiceID CHAR(4) NOT NULL,
    ServiceStatus VARCHAR(20) DEFAULT 'PENDING',
    Quantity INT NOT NULL
        CONSTRAINT DF_BOOKING_SERVICE_Quantity DEFAULT 1,
    UnitPrice DECIMAL(12,2) NOT NULL,
    Subtotal DECIMAL(12,2) NOT NULL,

    CONSTRAINT PK_BOOKING_SERVICE
        PRIMARY KEY (BookingID, ServiceID),
    CONSTRAINT FK_BOOKING_SERVICE_BOOKING
        FOREIGN KEY (BookingID) REFERENCES BOOKING(BookingID),
    CONSTRAINT FK_BOOKING_SERVICE_SERVICE
        FOREIGN KEY (ServiceID) REFERENCES SERVICE(ServiceID),
    CONSTRAINT CK_BOOKING_SERVICE_Quantity CHECK (Quantity > 0),
    CONSTRAINT CK_BOOKING_SERVICE_UnitPrice CHECK (UnitPrice >= 0),
    CONSTRAINT CK_BOOKING_SERVICE_Subtotal CHECK (Subtotal >= 0),
    CONSTRAINT CK_BOOKING_SERVICE_Total
        CHECK (Subtotal = Quantity * UnitPrice)
);
GO

CREATE TABLE PAYMENTMETHOD (
    MethodID CHAR(4) NOT NULL,
    MethodName NVARCHAR(30) NOT NULL,

    CONSTRAINT PK_PAYMENTMETHOD PRIMARY KEY (MethodID),
    CONSTRAINT UQ_PAYMENTMETHOD_Name UNIQUE (MethodName),
    CONSTRAINT CK_PAYMENTMETHOD_Supported CHECK (MethodID IN ('PT01', 'PT02', 'PT03'))
);
GO

CREATE TABLE dbo.[TRANSACTION] (
    id BIGINT IDENTITY(1,1) NOT NULL,
    TransactionID VARCHAR(100) NOT NULL,
    TransactionCode VARCHAR(100) NULL,
    TransactionType VARCHAR(20) NOT NULL,
    TransactionValue DECIMAL(12,2) NOT NULL,

    CONSTRAINT PK_TRANSACTION PRIMARY KEY (id),
    CONSTRAINT UQ_TRANSACTION_TransactionID UNIQUE (TransactionID),
    CONSTRAINT CK_TRANSACTION_Type CHECK (TransactionType IN ('PAYMENT', 'REFUND')),
    CONSTRAINT CK_TRANSACTION_Value CHECK (TransactionValue > 0),
    CONSTRAINT CK_TRANSACTION_ID CHECK (LEN(LTRIM(RTRIM(TransactionID))) > 0)
);
GO

CREATE TABLE PAYMENT (
    PaymentID CHAR(6) NOT NULL,
    BookingID CHAR(6) NOT NULL,
    PaymentType VARCHAR(10) NOT NULL
        CONSTRAINT DF_PAYMENT_Type DEFAULT 'FULL',
    PaymentTime DATETIME2(3) NULL,
    Amount DECIMAL(12,2) NOT NULL,
    Status VARCHAR(30) NOT NULL,
    MethodID CHAR(4) NULL,
    TransactionID VARCHAR(100) NULL,
    CollectedByUserID INT NULL,
    WalletAuthorizedByUserID INT NULL,
    WalletAmount DECIMAL(12,2) NOT NULL CONSTRAINT DF_PAYMENT_WalletAmount DEFAULT (0),
    ExternalAmount AS CAST(Amount - WalletAmount AS DECIMAL(12,2)) PERSISTED,

    CONSTRAINT PK_PAYMENT PRIMARY KEY (PaymentID),
    CONSTRAINT FK_PAYMENT_CollectedByUser FOREIGN KEY (CollectedByUserID) REFERENCES USERS(UserID),
    CONSTRAINT FK_PAYMENT_WalletAuthorizedByUser FOREIGN KEY (WalletAuthorizedByUserID) REFERENCES USERS(UserID),
    CONSTRAINT UQ_PAYMENT_BookingPayment UNIQUE (BookingID, PaymentID),
    CONSTRAINT UQ_PAYMENT_PaymentTransaction UNIQUE (PaymentID, TransactionID),
    CONSTRAINT UQ_PAYMENT_BookingTransaction UNIQUE (BookingID, PaymentID, TransactionID),
    CONSTRAINT FK_PAYMENT_TRANSACTION FOREIGN KEY (TransactionID)
        REFERENCES dbo.[TRANSACTION](TransactionID),
    CONSTRAINT CK_PAYMENT_Type CHECK (PaymentType IN ('DEPOSIT', 'FULL', 'BALANCE')),
    CONSTRAINT FK_PAYMENT_BOOKING
        FOREIGN KEY (BookingID) REFERENCES BOOKING(BookingID),
    CONSTRAINT FK_PAYMENT_METHOD
        FOREIGN KEY (MethodID) REFERENCES PAYMENTMETHOD(MethodID),
    CONSTRAINT CK_PAYMENT_Amount CHECK (Amount > 0),
    CONSTRAINT CK_PAYMENT_WalletAmount CHECK (WalletAmount >= 0 AND WalletAmount <= Amount),
    CONSTRAINT CK_PAYMENT_Status
        CHECK (Status IN ('PENDING', 'PAID', 'FAILED', 'REFUNDED')),
    CONSTRAINT CK_PAYMENT_CompletedData CHECK (
        Status IN ('PENDING', 'FAILED')
        OR (PaymentTime IS NOT NULL AND MethodID IS NOT NULL AND TransactionID IS NOT NULL)
    )
);
GO

CREATE TABLE dbo.PAYOS_ORDER (
    OrderCode BIGINT NOT NULL PRIMARY KEY,
    BookingID CHAR(6) NOT NULL REFERENCES dbo.BOOKING(BookingID),
    UserID INT NOT NULL REFERENCES dbo.USERS(UserID),
    PaymentType VARCHAR(10) NOT NULL CHECK (PaymentType IN ('DEPOSIT', 'FULL', 'BALANCE')),
    Amount DECIMAL(12,2) NOT NULL,
    WalletAmount DECIMAL(12,2) NOT NULL DEFAULT (0),
    ExternalAmount DECIMAL(12,2) NOT NULL,
    PaymentLinkId VARCHAR(100) NULL,
    Status VARCHAR(20) NOT NULL DEFAULT ('PENDING') CHECK (Status IN ('PENDING','PROCESSING','PAID','FAILED')),
    Reference VARCHAR(100) NULL,
    ErrorMessage VARCHAR(300) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    PaidAt DATETIME2 NULL,
    PaymentID CHAR(6) NULL REFERENCES dbo.PAYMENT(PaymentID),
    CheckInStaffUserID INT NULL REFERENCES dbo.USERS(UserID),
    CheckInExpiresAt BIGINT NULL,
    CheckInQrCode VARCHAR(2000) NULL,
    CheckInCheckoutUrl VARCHAR(500) NULL,
    CONSTRAINT CK_PAYOS_ORDER_Amount CHECK (WalletAmount >= 0 AND ExternalAmount > 0
        AND Amount = WalletAmount + ExternalAmount)
);
CREATE UNIQUE INDEX UX_PAYOS_ORDER_PaymentLinkId ON dbo.PAYOS_ORDER(PaymentLinkId)
    WHERE PaymentLinkId IS NOT NULL;
CREATE INDEX IX_PAYOS_ORDER_Booking ON dbo.PAYOS_ORDER(BookingID, UserID, CreatedAt DESC);
GO

CREATE TABLE INVOICE (
    InvoiceID CHAR(6) NOT NULL,
    InvoiceDate DATE NOT NULL
        CONSTRAINT DF_INVOICE_Date DEFAULT CAST(GETDATE() AS DATE),
    TotalAmount DECIMAL(12,2) NOT NULL,
    Status NVARCHAR(30) NOT NULL
        CONSTRAINT DF_INVOICE_Status DEFAULT N'Có hiệu lực',
    ReplacedInvoiceID CHAR(6) NULL,
    EmployeeID CHAR(6) NULL,
    BookingID CHAR(6) NOT NULL,

    CONSTRAINT PK_INVOICE PRIMARY KEY (InvoiceID),
    CONSTRAINT UQ_INVOICE_BookingInvoice UNIQUE (BookingID, InvoiceID),
    CONSTRAINT FK_INVOICE_EMPLOYEE
        FOREIGN KEY (EmployeeID) REFERENCES EMPLOYEE(EmployeeID),
    CONSTRAINT FK_INVOICE_BOOKING
        FOREIGN KEY (BookingID) REFERENCES BOOKING(BookingID),
    CONSTRAINT FK_INVOICE_REPLACED
        FOREIGN KEY (ReplacedInvoiceID) REFERENCES INVOICE(InvoiceID),
    CONSTRAINT CK_INVOICE_Status
        CHECK (Status IN (N'Có hiệu lực', N'Mất hiệu lực')),
    CONSTRAINT CK_INVOICE_TotalAmount
        CHECK (TotalAmount >= 0)
);
GO

CREATE UNIQUE INDEX UQ_INVOICE_ActiveBooking
ON INVOICE (BookingID)
WHERE Status = N'Có hiệu lực';
GO

CREATE TABLE INVOICE_TRANSACTION (
    InvoiceID CHAR(6) NOT NULL,
    BookingID CHAR(6) NOT NULL,
    PaymentID CHAR(6) NOT NULL,
    TransactionID VARCHAR(100) NOT NULL,

    CONSTRAINT PK_INVOICE_TRANSACTION PRIMARY KEY (InvoiceID, TransactionID),
    CONSTRAINT UQ_INVOICE_TRANSACTION_Payment UNIQUE (InvoiceID, PaymentID),
    CONSTRAINT FK_INVOICE_TRANSACTION_INVOICE FOREIGN KEY (BookingID, InvoiceID)
        REFERENCES INVOICE(BookingID, InvoiceID),
    CONSTRAINT FK_INVOICE_TRANSACTION_PAYMENT FOREIGN KEY (BookingID, PaymentID, TransactionID)
        REFERENCES PAYMENT(BookingID, PaymentID, TransactionID),
    CONSTRAINT FK_INVOICE_TRANSACTION_TRANSACTION FOREIGN KEY (TransactionID)
        REFERENCES dbo.[TRANSACTION](TransactionID)
);
GO

CREATE INDEX IX_INVOICE_TRANSACTION_TransactionID ON INVOICE_TRANSACTION(TransactionID);
GO

CREATE TABLE COMPLAINT (
    ComplaintID INT IDENTITY(1,1) NOT NULL,
    Title NVARCHAR(200) NOT NULL,
    Content NVARCHAR(MAX) NOT NULL,
    CreatedAt DATETIME NOT NULL
        CONSTRAINT DF_COMPLAINT_CreatedAt DEFAULT GETDATE(),
    Status NVARCHAR(30) NOT NULL
        CONSTRAINT DF_COMPLAINT_Status DEFAULT N'Chưa xử lý',
    CustomerID CHAR(6) NULL,

    CONSTRAINT PK_COMPLAINT PRIMARY KEY (ComplaintID),
    CONSTRAINT FK_COMPLAINT_CUSTOMER
        FOREIGN KEY (CustomerID) REFERENCES CUSTOMER(CustomerID),
    CONSTRAINT CK_COMPLAINT_Status
        CHECK (Status IN (N'Chưa xử lý', N'Đang xử lý', N'Đã xử lý'))
);
GO

CREATE TABLE CUSTOMER_WALLET (
    WalletID BIGINT IDENTITY(1,1) NOT NULL,
    CustomerID CHAR(6) NOT NULL,
    CreatedAt DATETIME2(3) NOT NULL CONSTRAINT DF_WALLET_Created DEFAULT SYSDATETIME(),
    CONSTRAINT PK_CUSTOMER_WALLET PRIMARY KEY (WalletID),
    CONSTRAINT UQ_WALLET_Customer UNIQUE (CustomerID),
    CONSTRAINT UQ_WALLET_Owner UNIQUE (CustomerID, WalletID),
    CONSTRAINT FK_WALLET_Customer FOREIGN KEY (CustomerID) REFERENCES CUSTOMER(CustomerID)
);
GO

CREATE TABLE BOOKING_REFUND (
    RefundID BIGINT IDENTITY(1,1) NOT NULL,
    BookingID CHAR(6) NOT NULL,
    CustomerID CHAR(6) NOT NULL,
    WalletID BIGINT NOT NULL,
    Amount DECIMAL(12,2) NOT NULL,
    RefundedAt DATETIME2(3) NOT NULL,
    TransactionID VARCHAR(100) NOT NULL,
    CONSTRAINT PK_BOOKING_REFUND PRIMARY KEY (RefundID),
    CONSTRAINT UQ_REFUND_Booking UNIQUE (BookingID),
    CONSTRAINT UQ_REFUND_BookingRefund UNIQUE (BookingID, RefundID),
    CONSTRAINT UQ_REFUND_WalletRefund UNIQUE (WalletID, RefundID),
    CONSTRAINT UQ_REFUND_TransactionID UNIQUE (TransactionID),
    CONSTRAINT UQ_REFUND_WalletTransaction UNIQUE (WalletID, RefundID, TransactionID),
    CONSTRAINT FK_REFUND_TRANSACTION FOREIGN KEY (TransactionID)
        REFERENCES dbo.[TRANSACTION](TransactionID),
    CONSTRAINT FK_REFUND_BookingOwner FOREIGN KEY (CustomerID, BookingID)
        REFERENCES BOOKING(CustomerID, BookingID),
    CONSTRAINT FK_REFUND_WalletOwner FOREIGN KEY (CustomerID, WalletID)
        REFERENCES CUSTOMER_WALLET(CustomerID, WalletID),
    CONSTRAINT CK_REFUND_Amount CHECK (Amount > 0)
);
GO

CREATE TABLE REFUND_PAYMENT (
    RefundID BIGINT NOT NULL,
    BookingID CHAR(6) NOT NULL,
    PaymentID CHAR(6) NOT NULL,
    Amount DECIMAL(12,2) NOT NULL,
    CONSTRAINT PK_REFUND_PAYMENT PRIMARY KEY (RefundID, PaymentID),
    CONSTRAINT UQ_REFUND_PAYMENT_Payment UNIQUE (PaymentID),
    CONSTRAINT FK_REFUND_PAYMENT_Refund FOREIGN KEY (BookingID, RefundID)
        REFERENCES BOOKING_REFUND(BookingID, RefundID),
    CONSTRAINT FK_REFUND_PAYMENT_Payment FOREIGN KEY (BookingID, PaymentID)
        REFERENCES PAYMENT(BookingID, PaymentID),
    CONSTRAINT CK_REFUND_PAYMENT_Amount CHECK (Amount > 0)
);
GO

CREATE TABLE WALLET_TRANSACTION (
    WalletTransactionID BIGINT IDENTITY(1,1) NOT NULL,
    WalletID BIGINT NOT NULL,
    TransactionType VARCHAR(20) NOT NULL,
    Amount DECIMAL(12,2) NOT NULL,
    TransactionTime DATETIME2(3) NOT NULL CONSTRAINT DF_WALLET_TX_Time DEFAULT SYSDATETIME(),
    RefundID BIGINT NULL,
    PaymentID CHAR(6) NULL,
    TransactionID VARCHAR(100) NOT NULL,
    CONSTRAINT PK_WALLET_TRANSACTION PRIMARY KEY (WalletTransactionID),
    CONSTRAINT FK_WALLET_TX_Wallet FOREIGN KEY (WalletID) REFERENCES CUSTOMER_WALLET(WalletID),
    CONSTRAINT FK_WALLET_TX_Refund FOREIGN KEY (WalletID, RefundID)
        REFERENCES BOOKING_REFUND(WalletID, RefundID),
    CONSTRAINT FK_WALLET_TX_Payment FOREIGN KEY (PaymentID) REFERENCES PAYMENT(PaymentID),
    CONSTRAINT FK_WALLET_TX_TRANSACTION FOREIGN KEY (TransactionID)
        REFERENCES dbo.[TRANSACTION](TransactionID),
    CONSTRAINT FK_WALLET_TX_PaymentTransaction FOREIGN KEY (PaymentID, TransactionID)
        REFERENCES PAYMENT(PaymentID, TransactionID),
    CONSTRAINT FK_WALLET_TX_RefundTransaction FOREIGN KEY (WalletID, RefundID, TransactionID)
        REFERENCES BOOKING_REFUND(WalletID, RefundID, TransactionID),
    CONSTRAINT CK_WALLET_TX_Amount CHECK (Amount > 0),
    CONSTRAINT CK_WALLET_TX_Source CHECK (
        (TransactionType = 'REFUND_CREDIT' AND RefundID IS NOT NULL AND PaymentID IS NULL)
        OR (TransactionType = 'PAYMENT_DEBIT' AND PaymentID IS NOT NULL AND RefundID IS NULL)
    )
);
GO

CREATE UNIQUE INDEX UQ_WALLET_TX_Refund ON WALLET_TRANSACTION(RefundID) WHERE RefundID IS NOT NULL;
CREATE UNIQUE INDEX UQ_WALLET_TX_Payment ON WALLET_TRANSACTION(PaymentID) WHERE PaymentID IS NOT NULL;
CREATE INDEX IX_WALLET_TX_WalletTime ON WALLET_TRANSACTION(WalletID, TransactionTime);
CREATE INDEX IX_WALLET_TX_TransactionID ON WALLET_TRANSACTION(TransactionID);
GO

CREATE TABLE USER_BOOKING_CONTROL (
    UserID INT NOT NULL,
    WindowStartedAt DATETIME2(3) NULL,
    ConsecutiveCancellationCount INT NOT NULL CONSTRAINT DF_CONTROL_Streak DEFAULT 0,
    CancellationCountInWindow INT NOT NULL CONSTRAINT DF_CONTROL_Total DEFAULT 0,
    PenaltyLevel TINYINT NOT NULL CONSTRAINT DF_CONTROL_Level DEFAULT 0,
    BookingLockedUntil DATETIME2(3) NULL,
    UpdatedAt DATETIME2(3) NOT NULL CONSTRAINT DF_CONTROL_Updated DEFAULT SYSDATETIME(),
    CONSTRAINT PK_USER_BOOKING_CONTROL PRIMARY KEY (UserID),
    CONSTRAINT FK_CONTROL_User FOREIGN KEY (UserID) REFERENCES USERS(UserID),
    CONSTRAINT CK_CONTROL_Counts CHECK (
        ConsecutiveCancellationCount >= 0 AND CancellationCountInWindow >= ConsecutiveCancellationCount
    ),
    CONSTRAINT CK_CONTROL_Level CHECK (PenaltyLevel BETWEEN 0 AND 3)
);
GO

CREATE TABLE BOOKING_LOCK_HISTORY (
    LockHistoryID BIGINT IDENTITY(1,1) NOT NULL,
    UserID INT NOT NULL,
    TriggerBookingID CHAR(6) NOT NULL,
    PenaltyLevel TINYINT NOT NULL,
    LockedAt DATETIME2(3) NOT NULL,
    LockedUntil DATETIME2(3) NOT NULL,
    DurationMinutes INT NOT NULL,
    CONSTRAINT PK_BOOKING_LOCK_HISTORY PRIMARY KEY (LockHistoryID),
    CONSTRAINT UQ_LOCK_HISTORY_Booking UNIQUE (TriggerBookingID),
    CONSTRAINT FK_LOCK_HISTORY_User FOREIGN KEY (UserID) REFERENCES USERS(UserID),
    CONSTRAINT FK_LOCK_HISTORY_Booking FOREIGN KEY (TriggerBookingID) REFERENCES BOOKING(BookingID),
    CONSTRAINT CK_LOCK_HISTORY_Duration CHECK (
        (PenaltyLevel = 1 AND DurationMinutes = 5)
        OR (PenaltyLevel = 2 AND DurationMinutes = 15)
        OR (PenaltyLevel = 3 AND DurationMinutes = 60)
    ),
    CONSTRAINT CK_LOCK_HISTORY_Time CHECK (LockedUntil = DATEADD(MINUTE, DurationMinutes, LockedAt))
);
GO

CREATE UNIQUE INDEX UQ_BOOKING_OnePendingPerCustomer
ON BOOKING(CustomerID) WHERE BookingStatus = 'PENDING_PAYMENT';
CREATE UNIQUE INDEX UQ_TRANSACTION_TransactionCode
ON dbo.[TRANSACTION](TransactionCode) WHERE TransactionCode IS NOT NULL;
CREATE UNIQUE INDEX UQ_PAYMENT_TransactionID
ON PAYMENT(TransactionID) WHERE TransactionID IS NOT NULL;
GO

CREATE TRIGGER TR_PAYMENT_ValidateTransaction ON PAYMENT AFTER INSERT, UPDATE AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted AS p
        LEFT JOIN dbo.[TRANSACTION] AS t ON t.TransactionID = p.TransactionID
        WHERE p.TransactionID IS NOT NULL
          AND (t.TransactionID IS NULL OR t.TransactionType <> 'PAYMENT' OR t.TransactionValue <> p.Amount)
    ) THROW 51200, 'Payment must reference a PAYMENT transaction for the same amount.', 1;
END;
GO

CREATE TRIGGER TR_REFUND_ValidateTransaction ON BOOKING_REFUND AFTER INSERT, UPDATE AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted AS r
        JOIN dbo.[TRANSACTION] AS t ON t.TransactionID = r.TransactionID
        WHERE t.TransactionType <> 'REFUND' OR t.TransactionValue <> r.Amount
    ) THROW 51201, 'Refund must reference a REFUND transaction for the same amount.', 1;
END;
GO

CREATE TRIGGER TR_WALLET_ValidateTransaction ON WALLET_TRANSACTION AFTER INSERT, UPDATE AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted AS w
        JOIN CUSTOMER_WALLET AS cw ON cw.WalletID = w.WalletID
        JOIN PAYMENT AS p ON p.PaymentID = w.PaymentID
        JOIN BOOKING AS b ON b.BookingID = p.BookingID
        WHERE w.TransactionType = 'PAYMENT_DEBIT'
          AND (p.Status NOT IN ('PAID', 'REFUNDED') OR p.WalletAmount <> w.Amount OR cw.CustomerID <> b.CustomerID)
    ) OR EXISTS (
        SELECT 1 FROM inserted AS w JOIN BOOKING_REFUND AS r ON r.RefundID = w.RefundID
        WHERE w.TransactionType = 'REFUND_CREDIT' AND w.Amount <> r.Amount
    ) THROW 51202, 'Wallet entry must match its owner and payment or refund amount.', 1;
END;
GO

CREATE TRIGGER TR_INVOICE_TRANSACTION_Validate ON INVOICE_TRANSACTION AFTER INSERT, UPDATE AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted AS i JOIN PAYMENT AS p ON p.PaymentID = i.PaymentID
        WHERE p.Status NOT IN ('PAID', 'REFUNDED')
    ) THROW 51203, 'Invoices can reference only successfully captured payment transactions.', 1;
END;
GO

CREATE TRIGGER TR_TRANSACTION_ValidateReferences ON dbo.[TRANSACTION] AFTER UPDATE AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted AS t JOIN PAYMENT AS p ON p.TransactionID = t.TransactionID
        WHERE t.TransactionType <> 'PAYMENT' OR t.TransactionValue <> p.Amount
    ) OR EXISTS (
        SELECT 1 FROM inserted AS t JOIN BOOKING_REFUND AS r ON r.TransactionID = t.TransactionID
        WHERE t.TransactionType <> 'REFUND' OR t.TransactionValue <> r.Amount
    ) THROW 51204, 'A transaction must remain consistent with its payment or refund.', 1;
END;
GO

CREATE TRIGGER TR_CUSTOMER_CreateWalletAndControl ON CUSTOMER AFTER INSERT AS
BEGIN
    SET NOCOUNT ON;
    INSERT CUSTOMER_WALLET(CustomerID) SELECT CustomerID FROM inserted;
    INSERT USER_BOOKING_CONTROL(UserID) SELECT UserID FROM inserted;
END;
GO

CREATE TRIGGER TR_BOOKING_DETAIL_Validate
ON BOOKING_DETAIL
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1
        FROM inserted AS i
        INNER JOIN BOOKING AS b
            ON b.BookingID = i.BookingID
        INNER JOIN ROOM_TYPE AS rt
            ON rt.RoomTypeID = i.RoomTypeID
        WHERE i.GuestCount > i.Quantity * rt.Capacity
           OR i.Subtotal <>
              i.Quantity * i.UnitPrice
              * DATEDIFF(DAY, b.CheckInDate, b.CheckOutDate)
    )
    BEGIN
        RAISERROR (
            'Invalid guest count or booking-detail subtotal.',
            16,
            1
        );
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        RETURN;
    END;
END;
GO

CREATE TRIGGER TR_BOOKING_DETAIL_RecalculateTotal
ON BOOKING_DETAIL
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ChangedBooking AS (
        SELECT BookingID FROM inserted
        UNION
        SELECT BookingID FROM deleted
    )
    UPDATE b
    SET TotalAmount =
        COALESCE((
            SELECT SUM(bd.Subtotal)
            FROM BOOKING_DETAIL AS bd
            WHERE bd.BookingID = b.BookingID
        ), 0)
        +
        COALESCE((
            SELECT SUM(bs.Subtotal)
            FROM BOOKING_SERVICE AS bs
            WHERE bs.BookingID = b.BookingID
        ), 0)
    FROM BOOKING AS b
    INNER JOIN ChangedBooking AS cb
        ON cb.BookingID = b.BookingID;
END;
GO

CREATE TRIGGER TR_BOOKING_SERVICE_RecalculateTotal
ON BOOKING_SERVICE
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ChangedBooking AS (
        SELECT BookingID FROM inserted
        UNION
        SELECT BookingID FROM deleted
    )
    UPDATE b
    SET TotalAmount =
        COALESCE((
            SELECT SUM(bd.Subtotal)
            FROM BOOKING_DETAIL AS bd
            WHERE bd.BookingID = b.BookingID
        ), 0)
        +
        COALESCE((
            SELECT SUM(bs.Subtotal)
            FROM BOOKING_SERVICE AS bs
            WHERE bs.BookingID = b.BookingID
        ), 0)
    FROM BOOKING AS b
    INNER JOIN ChangedBooking AS cb
        ON cb.BookingID = b.BookingID;
END;
GO

CREATE TRIGGER TR_ROOM_ASSIGNMENT_Validate
ON ROOM_ASSIGNMENT
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1
        FROM inserted AS i
        INNER JOIN BOOKING_DETAIL AS bd
            ON bd.BookingDetailID = i.BookingDetailID
        INNER JOIN BOOKING AS b
            ON b.BookingID = bd.BookingID
        INNER JOIN ROOM AS r
            ON r.RoomID = i.RoomID
        WHERE r.RoomTypeID <> bd.RoomTypeID
           OR r.Status <> 'ACTIVE'
           OR b.BookingStatus NOT IN (
               'CONFIRMED', 'ASSIGNED', 'CHECKED_IN', 'CHECKED_OUT'
           )
    )
    BEGIN
        RAISERROR (
            'Room must be active, match the requested type and belong to an assignable booking.',
            16,
            1
        );
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        RETURN;
    END;

    IF EXISTS (
        SELECT 1
        FROM BOOKING_DETAIL AS bd
        INNER JOIN (
            SELECT DISTINCT BookingDetailID
            FROM inserted
        ) AS changed
            ON changed.BookingDetailID = bd.BookingDetailID
        CROSS APPLY (
            SELECT COUNT(*) AS AssignedCount
            FROM ROOM_ASSIGNMENT AS ra
            WHERE ra.BookingDetailID = bd.BookingDetailID
        ) AS counted
        WHERE counted.AssignedCount > bd.Quantity
    )
    BEGIN
        RAISERROR (
            'Assigned-room count cannot exceed requested quantity.',
            16,
            1
        );
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        RETURN;
    END;

    IF EXISTS (
        SELECT 1
        FROM inserted AS i
        INNER JOIN BOOKING_DETAIL AS currentDetail
            ON currentDetail.BookingDetailID = i.BookingDetailID
        INNER JOIN BOOKING AS currentBooking
            ON currentBooking.BookingID = currentDetail.BookingID
        INNER JOIN ROOM_ASSIGNMENT AS otherAssignment
            ON otherAssignment.RoomID = i.RoomID
           AND otherAssignment.AssignmentID <> i.AssignmentID
        INNER JOIN BOOKING_DETAIL AS otherDetail
            ON otherDetail.BookingDetailID =
               otherAssignment.BookingDetailID
        INNER JOIN BOOKING AS otherBooking
            ON otherBooking.BookingID = otherDetail.BookingID
        WHERE currentBooking.BookingStatus NOT IN ('CANCELLED', 'CHECKED_OUT')
          AND otherBooking.BookingStatus NOT IN ('CANCELLED', 'CHECKED_OUT')
          AND currentBooking.CheckInDate < otherBooking.CheckOutDate
          AND currentBooking.CheckOutDate > otherBooking.CheckInDate
    )
    BEGIN
        RAISERROR (
            'This room is already assigned during an overlapping stay.',
            16,
            1
        );
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        RETURN;
    END;
END;
GO

INSERT INTO HOTEL (HotelName, HotelImage, RoomImage, PoolImage, RestaurantImage, Address)
VALUES (
    N'Simple Bear Hotel',
    'hotel2.jpg',
    'hotel3.jpg',
    'hotel.jpg',
    'hotel4.jpg',
    N'Lot E2a-7, D1 Street, High-Tech Park, Tang Nhon Phu Ward, Ho Chi Minh City, Vietnam'
);
GO

INSERT INTO NATIONALITY (NationalityID, NationalityName)
VALUES
('N01', N'Vietnam'),
('N02', N'Japan'),
('N03', N'China'),
('N04', N'South Korea'),
('N05', N'Thailand'),
('N06', N'Singapore'),
('N07', N'Malaysia'),
('N08', N'Indonesia'),
('N09', N'Philippines'),
('N10', N'India'),
('N11', N'United States'),
('N12', N'Canada'),
('N13', N'United Kingdom'),
('N14', N'France'),
('N15', N'Germany'),
('N16', N'Italy'),
('N17', N'Spain'),
('N18', N'Australia'),
('N19', N'New Zealand'),
('N20', N'Other');
GO

INSERT INTO USERS (Username, Password, Role, MustChangePassword)
VALUES
('admin', 'e10adc3949ba59abbe56e057f20f883e', 'Admin', 0),
('nv02', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv03', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv04', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv05', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv06', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv07', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv08', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv09', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv10', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv11', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv12', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv13', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv14', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv15', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv16', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv17', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv18', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv19', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv20', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv21', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv22', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv23', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv24', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv25', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv26', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv27', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv28', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv29', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv30', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('nv31', 'e13dd027be0f2152ce387ac0ea83d863', 'Staff', 0),
('kh01', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh02', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh03', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh04', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh05', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh06', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh07', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh08', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh09', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh10', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh11', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh12', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh13', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh14', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh15', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh16', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh17', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh18', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh19', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh20', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh21', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh22', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh23', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh24', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh25', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh26', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh27', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh28', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh29', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh30', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh31', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh32', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh33', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh34', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh35', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh36', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh37', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh38', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh39', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh40', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh41', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh42', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh43', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh44', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh45', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh46', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh47', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh48', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh49', '4297f44b13955235245b2497399d7a93', 'Customer', 0),
('kh50', '4297f44b13955235245b2497399d7a93', 'Customer', 0);
GO

INSERT INTO EMPLOYEE
(EmployeeID, FullName, Position, Salary, Shift, Address, Phone, Email, UserID)
VALUES
('NV02', N'Nguyễn Minh Anh', N'Receptionist', 9500000, N'Morning', N'Cần Thơ', '0901000002', 'nv02.hbms@gmail.com', 2),
('NV03', N'Trần Quốc Bảo', N'Receptionist', 9500000, N'Afternoon', N'Cần Thơ', '0901000003', 'nv03.hbms@gmail.com', 3),
('NV04', N'Lê Hoàng Nam', N'Receptionist', 10500000, N'Night', N'Cần Thơ', '0901000004', 'nv04.hbms@gmail.com', 4),
('NV05', N'Phạm Thùy Linh', N'Receptionist', 9500000, N'Morning', N'Cần Thơ', '0901000005', 'nv05.hbms@gmail.com', 5),
('NV06', N'Võ Minh Khang', N'Receptionist', 9500000, N'Afternoon', N'Cần Thơ', '0901000006', 'nv06.hbms@gmail.com', 6),

('NV07', N'Nguyễn Ngọc Hân', N'Customer service staff', 8000000, N'Morning', N'Cần Thơ', '0901000007', 'nv07.hbms@gmail.com', 7),
('NV08', N'Trần Thanh Tùng', N'Customer service staff', 8000000, N'Afternoon', N'Cần Thơ', '0901000008', 'nv08.hbms@gmail.com', 8),
('NV09', N'Lê Khánh Vy', N'Customer service staff', 8000000, N'Night', N'Cần Thơ', '0901000009', 'nv09.hbms@gmail.com', 9),
('NV10', N'Phan Gia Huy', N'Customer service staff', 8000000, N'Morning', N'Cần Thơ', '0901000010', 'nv10.hbms@gmail.com', 10),
('NV11', N'Đặng Mỹ Duyên', N'Customer service staff', 8000000, N'Afternoon', N'Cần Thơ', '0901000011', 'nv11.hbms@gmail.com', 11),

('NV12', N'Bùi Thanh Trúc', N'Service staff', 8000000, N'Morning', N'Cần Thơ', '0901000012', 'nv12.hbms@gmail.com', 12),

('NV13', N'Nguyễn Thành Đạt', N'Service staff', 12000000, N'Morning', N'Cần Thơ', '0901000013', 'nv13.hbms@gmail.com', 13),
('NV14', N'Trần Minh Đức', N'Service staff', 10000000, N'Afternoon', N'Cần Thơ', '0901000014', 'nv14.hbms@gmail.com', 14),
('NV15', N'Lê Ngọc Mai', N'Service staff', 10000000, N'Night', N'Cần Thơ', '0901000015', 'nv15.hbms@gmail.com', 15),
('NV16', N'Phạm Quốc Khánh', N'Service staff', 10000000, N'Morning', N'Cần Thơ', '0901000016', 'nv16.hbms@gmail.com', 16),
('NV17', N'Võ Thu Hà', N'Service staff', 10000000, N'Afternoon', N'Cần Thơ', '0901000017', 'nv17.hbms@gmail.com', 17),

('NV18', N'Nguyễn Văn Phúc', N'Service staff', 7000000, N'Morning', N'Cần Thơ', '0901000018', 'nv18.hbms@gmail.com', 18),
('NV19', N'Trần Gia Hưng', N'Service staff', 7000000, N'Afternoon', N'Cần Thơ', '0901000019', 'nv19.hbms@gmail.com', 19),
('NV20', N'Lê Minh Quân', N'Service staff', 7000000, N'Night', N'Cần Thơ', '0901000020', 'nv20.hbms@gmail.com', 20),

('NV21', N'Phạm Thị Hương', N'Service staff', 7000000, N'Morning', N'Cần Thơ', '0901000021', 'nv21.hbms@gmail.com', 21),
('NV22', N'Nguyễn Thị Ngọc', N'Service staff', 7000000, N'Afternoon', N'Cần Thơ', '0901000022', 'nv22.hbms@gmail.com', 22),
('NV23', N'Trần Mỹ Linh', N'Service staff', 7000000, N'Night', N'Cần Thơ', '0901000023', 'nv23.hbms@gmail.com', 23),

('NV24', N'Lê Thị Thanh', N'Service staff', 7000000, N'Morning', N'Cần Thơ', '0901000024', 'nv24.hbms@gmail.com', 24),
('NV25', N'Phạm Ngọc Lan', N'Service staff', 7000000, N'Afternoon', N'Cần Thơ', '0901000025', 'nv25.hbms@gmail.com', 25),
('NV26', N'Nguyễn Thị Mai', N'Service staff', 7000000, N'Night', N'Cần Thơ', '0901000026', 'nv26.hbms@gmail.com', 26),
('NV27', N'Trần Thị Thu', N'Service staff', 7000000, N'Morning', N'Cần Thơ', '0901000027', 'nv27.hbms@gmail.com', 27),

('NV28', N'Võ Ngọc Diệp', N'Service staff', 8000000, N'Afternoon', N'Cần Thơ', '0901000028', 'nv28.hbms@gmail.com', 28),
('NV29', N'Đặng Thảo Vy', N'Service staff', 8000000, N'Night', N'Cần Thơ', '0901000029', 'nv29.hbms@gmail.com', 29),
('NV30', N'Nguyễn Khánh An', N'Service staff', 8000000, N'Morning', N'Cần Thơ', '0901000030', 'nv30.hbms@gmail.com', 30),
('NV31', N'Trần Bảo Trâm', N'Service staff', 8000000, N'Afternoon', N'Cần Thơ', '0901000031', 'nv31.hbms@gmail.com', 31);
GO

INSERT INTO CUSTOMER
(CustomerID, FullName, Phone, Email, Address, NationalityID, UserID)
VALUES
('KH01', N'Phạm Minh Tuấn', '0903456789', 'tuan.pham@gmail.com', N'Quận 1, TP.HCM', 'N01', 32),
('KH02', N'Nguyễn Tuyết Mai', '0912888999', 'maituyet92@yahoo.com', N'Quận Cầu Giấy, Hà Nội', 'N01', 33),
('KH03', N'Lê Hoàng Nam', '0987111222', 'namlh@gmail.com', N'Quận 7, TP.HCM', 'N01', 34),
('KH04', N'Trần Thu Hà', '0356123456', 'hatran@fpt.com.vn', N'Quận Tây Hồ, Hà Nội', 'N01', 35),
('KH05', N'Robert Harrison', '0775123456', 'robert.h@outlook.com', N'London, United Kingdom', 'N13', 36),
('KH06', N'Chen Wei', '0933444555', 'chenwei88@qq.com', N'Beijing, China', 'N03', 37),
('KH07', N'Hans Müller', '0888777666', 'hans.m@gmail.de', N'Berlin, Germany', 'N15', 38),
('KH08', N'Kim Ji-won', '0944555666', 'jiwon.kim@naver.com', N'Seoul, South Korea', 'N04', 39),
('KH09', N'Jean Dupont', '0766112233', 'jean.dupont@france.fr', N'Paris, France', 'N14', 40),
('KH10', N'Đặng Phương Thảo', '0399123456', 'thaophuong@gmail.com', N'Quận Hải Châu, Đà Nẵng', 'N01', 41),

('KH11', N'Vũ Đình Tùng', '0988123123', 'tung.vu@gmail.com', N'Quận 3, TP.HCM', 'N01', 42),
('KH12', N'Lê Thị Thu Hương', '0977234234', 'huongle99@yahoo.com', N'Quận Đống Đa, Hà Nội', 'N01', 43),
('KH13', N'Nguyễn Quang Hải', '0912345345', 'hai.nq@fpt.edu.vn', N'Ninh Kiều, Cần Thơ', 'N01', 44),
('KH14', N'Phan Thanh Bình', '0933456456', 'binhpt@gmail.com', N'Quận 1, TP.HCM', 'N01', 45),
('KH15', N'Đỗ Mỹ Linh', '0944567567', 'mylinh.do@gmail.com', N'Quận Hoàn Kiếm, Hà Nội', 'N01', 46),
('KH16', N'Bùi Tiến Dũng', '0966678678', 'dung.bui@viettel.com.vn', N'Thạch Thất, Hà Nội', 'N01', 47),
('KH17', N'Trần Phương Anh', '0888789789', 'phuonganh.t@yahoo.com', N'Quận Sơn Trà, Đà Nẵng', 'N01', 48),
('KH18', N'Lý Nhã Kỳ', '0901890890', 'nhaky.ly@gmail.com', N'Quận 7, TP.HCM', 'N01', 49),
('KH19', N'Hoàng Lệ Thu', '0922901901', 'thuhl@outlook.com', N'Biên Hòa, Đồng Nai', 'N01', 50),
('KH20', N'Ngô Thanh Vân', '0933012012', 'van.ngo@gmail.com', N'Quận Phú Nhuận, TP.HCM', 'N01', 51),
('KH21', N'Võ Hoàng Yến', '0944123123', 'hoangyen.vo@gmail.com', N'Quận 4, TP.HCM', 'N01', 52),
('KH22', N'Đinh Ngọc Diệp', '0955234234', 'ngocdiep.dinh@yahoo.com', N'Quận Bình Thạnh, TP.HCM', 'N01', 53),
('KH23', N'Lương Xuân Trường', '0966345345', 'truong.lx@hagl.com.vn', N'Pleiku, Gia Lai', 'N01', 54),
('KH24', N'Cao Thái Sơn', '0977456456', 'soncao@gmail.com', N'Quận 10, TP.HCM', 'N01', 55),
('KH25', N'Hồ Ngọc Hà', '0988567567', 'hongocha@gmail.com', N'Quận 2, TP.HCM', 'N01', 56),
('KH26', N'Mai Phương Thúy', '0999678678', 'thuymp@gmail.com', N'Quận Cầu Giấy, Hà Nội', 'N01', 57),
('KH27', N'Dương Trương Thiên Lý', '0901789789', 'thienly.dt@gmail.com', N'Đồng Tháp', 'N01', 58),
('KH28', N'Tăng Thanh Hà', '0912890890', 'hathanh.tang@gmail.com', N'Quận 2, TP.HCM', 'N01', 59),
('KH29', N'Phạm Hương', '0923901901', 'huong.pham@gmail.com', N'Hải Phòng', 'N01', 60),
('KH30', N'Nguyễn Thúc Thùy Tiên', '0934012012', 'thuytien.nt@gmail.com', N'Quận Gò Vấp, TP.HCM', 'N01', 61),
('KH31', N'Lê Quốc Bảo', '0945123123', 'baolq@gmail.com', N'Quận Tân Bình, TP.HCM', 'N01', 62),
('KH32', N'Trần Kim Chi', '0956234234', 'kimchi.tran@yahoo.com', N'Quận Thanh Xuân, Hà Nội', 'N01', 63),
('KH33', N'Phan Đình Phùng', '0967345345', 'phungpd@gmail.com', N'Vinh, Nghệ An', 'N01', 64),
('KH34', N'Vũ Cát Tường', '0978456456', 'cattuong.vu@gmail.com', N'Long Xuyên, An Giang', 'N01', 65),
('KH35', N'Đỗ Trọng Hiếu', '0989567567', 'hieudo@gmail.com', N'Quận Hai Bà Trưng, Hà Nội', 'N01', 66),
('KH36', N'Bùi Anh Tuấn', '0990678678', 'anhtuan.bui@gmail.com', N'Quận 1, TP.HCM', 'N01', 67),
('KH37', N'Lê Minh Sơn', '0902789789', 'sonlm@gmail.com', N'Bắc Ninh', 'N01', 68),
('KH38', N'Hoàng Thùy Linh', '0913890890', 'thuylinh.hoang@gmail.com', N'Quận Ba Đình, Hà Nội', 'N01', 69),
('KH39', N'Nguyễn Trần Trung Quân', '0924901901', 'trungquan.nt@gmail.com', N'Quận Đống Đa, Hà Nội', 'N01', 70),
('KH40', N'Phạm Tiến Dũng', '0935012012', 'dungpt@gmail.com', N'Nha Trang, Khánh Hòa', 'N01', 71),

('KH41', N'Emily Johnson', NULL, 'emily.j@yahoo.com', N'Los Angeles, USA', 'N11', 72),
('KH42', N'Michael Brown', NULL, 'michael.b@outlook.com', N'Chicago, USA', 'N11', 73),
('KH43', N'Li Na', NULL, 'lina.beijing@qq.com', N'Shanghai, China', 'N03', 74),
('KH44', N'Wang Lei', NULL, 'wanglei88@wechat.com', N'Guangzhou, China', 'N03', 75),
('KH45', N'Park Min-young', NULL, 'minyoung.park@naver.com', N'Busan, South Korea', 'N04', 76),
('KH46', N'Lee Jong-suk', NULL, 'jongsuk.lee@daum.net', N'Incheon, South Korea', 'N04', 77),
('KH47', N'Sato Kenji', NULL, 'kenji.sato@yahoo.co.jp', N'Tokyo, Japan', 'N02', 78),
('KH48', N'Tanaka Yuki', NULL, 'yuki.tanaka@gmail.com', N'Osaka, Japan', 'N02', 79),
('KH49', N'Anna Kowalski', NULL, 'anna.k@gmail.com', N'Warsaw, Poland', 'N20', 80),
('KH50', N'David Silva', NULL, 'david.silva@hotmail.com', N'Madrid, Spain', 'N17', 81);
GO

INSERT INTO ROOM_TYPE
(RoomTypeID, TypeName, Capacity, Price, RoomTypeImage, Description)
VALUES
('RT01', N'Phòng đơn', 2, 500000, N'room-type-single.jpg',
 N'1 giường đôi, tối đa 2 khách'),
('RT02', N'Phòng đôi', 4, 800000, N'room-type-double.jpg',
 N'2 giường đôi, tối đa 4 khách'),
('RT03', N'Phòng Luxury đơn', 2, 1200000, N'room-type-luxury-single.jpg',
 N'Phòng cao cấp 1 giường đôi, tối đa 2 khách'),
('RT04', N'Phòng Luxury đôi', 4, 1600000, N'room-type-luxury-double.jpg',
 N'Phòng cao cấp 2 giường đôi, tối đa 4 khách');
GO

INSERT INTO ROOM
(RoomID, RoomNumber, RoomImage, Status, RoomTypeID)
VALUES
('R01', N'101', 'room01.png', 'ACTIVE',      'RT01'),
('R02', N'102', 'room02.png', 'ACTIVE',      'RT01'),
('R03', N'103', 'room03.png', 'MAINTENANCE', 'RT01'),
('R04', N'201', 'room04.png', 'ACTIVE',      'RT02'),
('R05', N'202', 'room05.png', 'ACTIVE',      'RT02'),
('R06', N'203', 'room06.png', 'ACTIVE',      'RT02'),
('R07', N'204', 'room07.png', 'ACTIVE',      'RT02'),
('R08', N'301', 'room08.png', 'ACTIVE',      'RT03'),
('R09', N'302', 'room09.png', 'ACTIVE',      'RT03'),
('R10', N'401', 'room10.png', 'ACTIVE',      'RT04');
GO

INSERT INTO SERVICE (ServiceID, ServiceName, UnitPrice)
VALUES
('S01', N'Giặt ủi', 75000),
('S02', N'Suối nước nóng', 200000),
('S03', N'Thuê xe', 150000),
('S04', N'Spa', 450000),
('S05', N'Ăn uống tại phòng', 0),
('S06', N'Dịch vụ trông trẻ', 150000),
('S07', N'Đưa đón sân bay', 350000),
('S08', N'Dọn dẹp phòng', 0),
('S09', N'Ăn tối buffer', 350000),
('S10', N'Giữ hành lý', 50000);
GO

INSERT INTO BOOKING
(BookingID, BookingDate, PaymentDeadline, CheckInDate, CheckOutDate,
 BookingStatus, CustomerID)
VALUES
('BK0001', '2026-09-01 09:00:00', NULL, '2026-09-05', '2026-09-07',
 'CHECKED_OUT', 'KH01'),
('BK0002', '2026-09-03 10:15:00', NULL, '2026-09-08', '2026-09-10',
 'CHECKED_OUT', 'KH02'),
('BK0003', '2026-09-10 08:30:00', NULL, '2026-09-18', '2026-09-20',
 'ASSIGNED', 'KH03'),
('BK0004', '2026-09-11 14:00:00', NULL, '2026-09-20', '2026-09-22',
 'CONFIRMED', 'KH04'),
('BK0005', '2026-09-12 16:10:00', DATEADD(MINUTE, 15, GETDATE()),
 '2026-09-21', '2026-09-23',
 'PENDING_PAYMENT', 'KH05'),
('BK0006', '2026-09-13 11:45:00', NULL, '2026-09-24', '2026-09-26',
 'CONFIRMED', 'KH06'),
('BK0007', '2026-09-14 09:20:00', NULL, '2026-09-25', '2026-09-27',
 'CANCELLED', 'KH07'),
('BK0008', '2026-09-15 13:30:00', NULL, '2026-09-28', '2026-10-01',
 'ASSIGNED', 'KH08'),
('BK0009', '2026-09-16 15:00:00', NULL, '2026-10-02', '2026-10-04',
 'CONFIRMED', 'KH09'),
('BK0010', '2026-09-17 06:30:00', DATEADD(MINUTE, 15, GETDATE()),
 '2026-10-05', '2026-10-07',
 'PENDING_PAYMENT', 'KH10'),
('BK0011', '2026-07-27 09:00:00', NULL, '2026-08-03', '2026-08-05',
 'CHECKED_OUT', 'KH11'),
('BK0012', '2026-07-28 09:00:00', NULL, '2026-08-04', '2026-08-07',
 'CHECKED_OUT', 'KH12'),
('BK0013', '2026-08-02 09:00:00', NULL, '2026-08-09', '2026-08-11',
 'CHECKED_OUT', 'KH13'),
('BK0014', '2026-08-05 09:00:00', NULL, '2026-08-12', '2026-08-14',
 'CHECKED_OUT', 'KH14'),
('BK0015', '2026-08-10 09:00:00', NULL, '2026-08-17', '2026-08-20',
 'CHECKED_OUT', 'KH15'),
('BK0016', '2026-08-11 09:00:00', NULL, '2026-08-18', '2026-08-21',
 'CHECKED_OUT', 'KH16'),
('BK0017', '2026-08-16 09:00:00', NULL, '2026-08-23', '2026-08-25',
 'CHECKED_OUT', 'KH17'),
('BK0018', '2026-08-19 09:00:00', NULL, '2026-08-26', '2026-08-29',
 'CHECKED_OUT', 'KH18'),
('BK0019', '2026-08-23 09:00:00', NULL, '2026-08-30', '2026-09-01',
 'CHECKED_OUT', 'KH19'),
('BK0020', '2026-08-24 09:00:00', NULL, '2026-08-31', '2026-09-03',
 'CHECKED_OUT', 'KH20'),
('BK0021', '2026-08-28 09:00:00', NULL, '2026-09-04', '2026-09-06',
 'CHECKED_OUT', 'KH21'),
('BK0022', '2026-08-30 09:00:00', NULL, '2026-09-06', '2026-09-08',
 'CHECKED_OUT', 'KH22'),
('BK0023', '2026-09-02 09:00:00', NULL, '2026-09-09', '2026-09-11',
 'CHECKED_OUT', 'KH23'),
('BK0024', '2026-09-04 09:00:00', NULL, '2026-09-11', '2026-09-13',
 'CHECKED_OUT', 'KH24'),
('BK0025', '2026-09-06 09:00:00', NULL, '2026-09-13', '2026-09-16',
 'CHECKED_OUT', 'KH25'),
('BK0026', '2026-09-08 09:00:00', NULL, '2026-09-15', '2026-09-17',
 'CHECKED_OUT', 'KH26'),
('BK0027', '2026-09-10 09:00:00', NULL, '2026-09-17', '2026-09-19',
 'CHECKED_OUT', 'KH27'),
('BK0028', '2026-09-12 09:00:00', NULL, '2026-09-19', '2026-09-21',
 'CHECKED_OUT', 'KH28'),
('BK0029', '2026-09-13 09:00:00', NULL, '2026-09-20', '2026-09-22',
 'CHECKED_OUT', 'KH29'),
('BK0030', '2026-09-14 09:00:00', NULL, '2026-09-21', '2026-09-23',
 'CHECKED_OUT', 'KH30'),
('BK0031', '2026-09-23 09:00:00', NULL, '2026-09-24', '2026-09-26',
 'CONFIRMED', 'KH31'),
('BK0032', '2026-09-20 09:00:00', NULL, '2026-09-26', '2026-09-28',
 'ASSIGNED', 'KH32'),
('BK0033', '2026-09-21 09:00:00', NULL, '2026-09-27', '2026-09-29',
 'CONFIRMED', 'KH07'),
('BK0034', '2026-09-22 09:00:00', NULL, '2026-09-29', '2026-10-01',
 'ASSIGNED', 'KH34'),
('BK0035', '2026-09-23 09:00:00', NULL, '2026-10-02', '2026-10-04',
 'CONFIRMED', 'KH35'),
('BK0036', '2026-09-20 09:00:00', DATEADD(MINUTE, 15, GETDATE()), '2026-10-05', '2026-10-08',
 'PENDING_PAYMENT', 'KH36'),
('BK0037', '2026-09-21 09:00:00', DATEADD(MINUTE, 15, GETDATE()), '2026-10-08', '2026-10-10',
 'PENDING_PAYMENT', 'KH37'),
('BK0038', '2026-09-22 09:00:00', NULL, '2026-10-11', '2026-10-13',
 'CANCELLED', 'KH38'),
('BK0039', '2026-09-23 09:00:00', NULL, '2026-10-14', '2026-10-16',
 'CONFIRMED', 'KH38'),
('BK0040', '2026-09-20 09:00:00', NULL, '2026-10-18', '2026-10-21',
 'CONFIRMED', 'KH40');
GO

SET IDENTITY_INSERT BOOKING_DETAIL ON;

INSERT INTO BOOKING_DETAIL
(BookingDetailID, BookingID, RoomTypeID, Quantity,
 GuestCount, UnitPrice, Subtotal)
VALUES
(1,  'BK0001', 'RT01', 1, 1,  500000, 1000000),
(2,  'BK0002', 'RT02', 1, 2,  800000, 1600000),
(3,  'BK0003', 'RT03', 1, 2, 1200000, 2400000),
(4,  'BK0004', 'RT01', 1, 1,  500000, 1000000),
(5,  'BK0004', 'RT02', 1, 2,  800000, 1600000),
(6,  'BK0005', 'RT01', 1, 1,  500000, 1000000),
(7,  'BK0006', 'RT02', 2, 4,  800000, 3200000),
(8,  'BK0007', 'RT04', 1, 4, 1600000, 3200000),
(9,  'BK0008', 'RT02', 1, 2,  800000, 2400000),
(10, 'BK0009', 'RT01', 1, 1,  500000, 1000000),
(11, 'BK0010', 'RT03', 1, 2, 1200000, 2400000),
(12, 'BK0011', 'RT01', 1, 2, 500000, 1000000),
(13, 'BK0012', 'RT02', 1, 1, 800000, 2400000),
(14, 'BK0013', 'RT03', 1, 2, 1200000, 2400000),
(15, 'BK0014', 'RT04', 1, 2, 1600000, 3200000),
(16, 'BK0015', 'RT01', 1, 1, 500000, 1500000),
(17, 'BK0016', 'RT02', 1, 2, 800000, 2400000),
(18, 'BK0017', 'RT03', 1, 2, 1200000, 2400000),
(19, 'BK0018', 'RT04', 1, 1, 1600000, 4800000),
(20, 'BK0019', 'RT01', 1, 2, 500000, 1000000),
(21, 'BK0020', 'RT02', 1, 2, 800000, 2400000),
(22, 'BK0021', 'RT03', 1, 1, 1200000, 2400000),
(23, 'BK0022', 'RT04', 1, 2, 1600000, 3200000),
(24, 'BK0023', 'RT01', 1, 2, 500000, 1000000),
(25, 'BK0024', 'RT02', 1, 1, 800000, 1600000),
(26, 'BK0025', 'RT03', 1, 2, 1200000, 3600000),
(27, 'BK0026', 'RT04', 1, 2, 1600000, 3200000),
(28, 'BK0027', 'RT01', 1, 1, 500000, 1000000),
(29, 'BK0028', 'RT02', 1, 2, 800000, 1600000),
(30, 'BK0029', 'RT03', 1, 2, 1200000, 2400000),
(31, 'BK0030', 'RT04', 1, 1, 1600000, 3200000),
(32, 'BK0031', 'RT01', 1, 2, 500000, 1000000),
(33, 'BK0032', 'RT02', 1, 2, 800000, 1600000),
(34, 'BK0033', 'RT03', 1, 1, 1200000, 2400000),
(35, 'BK0034', 'RT04', 1, 2, 1600000, 3200000),
(36, 'BK0035', 'RT02', 1, 2, 800000, 1600000),
(37, 'BK0036', 'RT01', 1, 1, 500000, 1500000),
(38, 'BK0037', 'RT03', 1, 2, 1200000, 2400000),
(39, 'BK0038', 'RT04', 1, 2, 1600000, 3200000),
(40, 'BK0039', 'RT01', 1, 1, 500000, 1000000),
(41, 'BK0040', 'RT02', 1, 2, 800000, 2400000);

SET IDENTITY_INSERT BOOKING_DETAIL OFF;
GO

INSERT INTO BOOKING_SERVICE
(BookingID, ServiceID, Quantity, UnitPrice, Subtotal)
VALUES
('BK0001', 'S01', 1,  75000,  75000),
('BK0002', 'S02', 2, 250000, 500000),
('BK0003', 'S05', 1, 100000, 100000),
('BK0004', 'S07', 1, 350000, 350000),
('BK0006', 'S06', 1, 150000, 150000),
('BK0008', 'S02', 2, 250000, 500000),
('BK0009', 'S10', 1,  50000,  50000),
('BK0011', 'S01', 1, 75000, 75000),
('BK0013', 'S04', 1, 450000, 450000),
('BK0015', 'S03', 1, 150000, 150000),
('BK0017', 'S02', 2, 200000, 400000),
('BK0019', 'S10', 1, 50000, 50000),
('BK0021', 'S07', 1, 350000, 350000),
('BK0023', 'S09', 2, 350000, 700000),
('BK0025', 'S04', 1, 450000, 450000),
('BK0027', 'S01', 2, 75000, 150000),
('BK0029', 'S03', 1, 150000, 150000),
('BK0031', 'S07', 1, 350000, 350000),
('BK0032', 'S02', 1, 200000, 200000),
('BK0034', 'S09', 1, 350000, 350000),
('BK0035', 'S06', 1, 150000, 150000),
('BK0039', 'S10', 1, 50000, 50000),
('BK0040', 'S04', 1, 450000, 450000);
GO

INSERT INTO ROOM_ASSIGNMENT
(BookingDetailID, RoomID, EmployeeID, AssignedAt)
VALUES
(1, 'R01', 'NV02', '2026-09-04 15:00:00'),
(2, 'R04', 'NV02', '2026-09-07 16:00:00'),
(3, 'R08', 'NV03', '2026-09-17 09:00:00'),
(9, 'R05', 'NV03', '2026-09-27 10:00:00'),
(12, 'R01', 'NV02', '2026-08-02 15:00:00'),
(13, 'R04', 'NV03', '2026-08-03 15:00:00'),
(14, 'R08', 'NV02', '2026-08-08 15:00:00'),
(15, 'R10', 'NV03', '2026-08-11 15:00:00'),
(16, 'R02', 'NV02', '2026-08-16 15:00:00'),
(17, 'R05', 'NV03', '2026-08-17 15:00:00'),
(18, 'R09', 'NV02', '2026-08-22 15:00:00'),
(19, 'R10', 'NV03', '2026-08-25 15:00:00'),
(20, 'R01', 'NV02', '2026-08-29 15:00:00'),
(21, 'R04', 'NV03', '2026-08-30 15:00:00'),
(22, 'R08', 'NV02', '2026-09-03 15:00:00'),
(23, 'R10', 'NV03', '2026-09-05 15:00:00'),
(24, 'R02', 'NV02', '2026-09-08 15:00:00'),
(25, 'R05', 'NV03', '2026-09-10 15:00:00'),
(26, 'R09', 'NV02', '2026-09-12 15:00:00'),
(27, 'R10', 'NV03', '2026-09-14 15:00:00'),
(28, 'R01', 'NV02', '2026-09-16 15:00:00'),
(29, 'R04', 'NV03', '2026-09-18 15:00:00'),
(30, 'R08', 'NV02', '2026-09-19 15:00:00'),
(31, 'R10', 'NV03', '2026-09-20 15:00:00'),
(33, 'R06', 'NV03', '2026-09-25 15:00:00'),
(35, 'R10', 'NV03', '2026-09-28 15:00:00');
GO

INSERT INTO PAYMENTMETHOD (MethodID, MethodName)
VALUES
('PT01', N'VietQR'),
('PT02', N'Internal wallet'),
('PT03', N'Cash');
GO

INSERT INTO dbo.[TRANSACTION] (TransactionID, TransactionCode, TransactionType, TransactionValue)
VALUES
('PAYMENT-PM0001', 'CASH-PM0001', 'PAYMENT', 1075000),
('PAYMENT-PM0002', 'CASH-PM0002', 'PAYMENT', 2100000),
('VQR-DEMO-PM0003', 'TXN-BK0003', 'PAYMENT', 750000),
('VQR-DEMO-PM0004', 'TXN-BK0004-DEPOSIT', 'PAYMENT', 885000),
('VQR-DEMO-PM0006', 'TXN-BK0006', 'PAYMENT', 3350000),
('VQR-DEMO-PM0007', 'REF-BK0007', 'PAYMENT', 3200000),
('PAYMENT-PM0008', 'CASH-PM0008', 'PAYMENT', 2900000),
('VQR-DEMO-PM0009', 'TXN-BK0009', 'PAYMENT', 1050000),
('VQR-DEMO-PM0011', 'TXN-BK0011', 'PAYMENT', 1075000),
('PAYMENT-PM0012', 'CASH-PM0012', 'PAYMENT', 2400000),
('VQR-DEMO-PM0013', 'TXN-BK0013', 'PAYMENT', 2850000),
('VQR-DEMO-PM0014', 'TXN-BK0014', 'PAYMENT', 3200000),
('VQR-DEMO-PM0015', 'TXN-BK0015', 'PAYMENT', 1650000),
('VQR-DEMO-PM0016', 'TXN-BK0016', 'PAYMENT', 2400000),
('VQR-DEMO-PM0017', 'TXN-BK0017', 'PAYMENT', 2800000),
('VQR-DEMO-PM0018', 'TXN-BK0018', 'PAYMENT', 4800000),
('VQR-DEMO-PM0019', 'TXN-BK0019', 'PAYMENT', 1050000),
('VQR-DEMO-PM0020', 'TXN-BK0020', 'PAYMENT', 2400000),
('VQR-DEMO-PM0021', 'TXN-BK0021', 'PAYMENT', 2750000),
('PAYMENT-PM0022', 'CASH-PM0022', 'PAYMENT', 3200000),
('VQR-DEMO-PM0023', 'TXN-BK0023', 'PAYMENT', 1700000),
('VQR-DEMO-PM0024', 'TXN-BK0024', 'PAYMENT', 1600000),
('VQR-DEMO-PM0025', 'TXN-BK0025', 'PAYMENT', 4050000),
('VQR-DEMO-PM0026', 'TXN-BK0026', 'PAYMENT', 3200000),
('VQR-DEMO-PM0027', 'TXN-BK0027', 'PAYMENT', 1150000),
('PAYMENT-PM0028', 'CASH-PM0028', 'PAYMENT', 1600000),
('VQR-DEMO-PM0029', 'TXN-BK0029', 'PAYMENT', 2550000),
('VQR-DEMO-PM0030', 'TXN-BK0030', 'PAYMENT', 3200000),
('PAYMENT-PM0031', 'CASH-PM0031', 'PAYMENT', 405000),
('VQR-DEMO-PM0032', 'TXN-BK0032', 'PAYMENT', 1800000),
('PAYMENT-PM0033', 'WALLET-PM0033', 'PAYMENT', 2400000),
('PAYMENT-PM0034', 'CASH-PM0034', 'PAYMENT', 3550000),
('VQR-DEMO-PM0035', 'TXN-BK0035', 'PAYMENT', 1750000),
('VQR-DEMO-PM0038', 'REF-BK0038', 'PAYMENT', 3200000),
('VQR-DEMO-PM0039', 'TXN-BK0039', 'PAYMENT', 1050000),
('VQR-DEMO-PM0040', 'TXN-BK0040', 'PAYMENT', 2850000),
('VQR-DEMO-PM0041', 'TXN-BK0004-BALANCE', 'PAYMENT', 2065000),
('REFUND-BK0007', NULL, 'REFUND', 3200000),
('REFUND-BK0038', NULL, 'REFUND', 3200000);
GO

INSERT INTO PAYMENT
(PaymentID, BookingID, PaymentTime, Amount,
 Status, MethodID, TransactionID, PaymentType, WalletAmount)
VALUES
('PM0001', 'BK0001', '2026-09-01 09:05:00', 1075000,
 'PAID', 'PT03', 'PAYMENT-PM0001', 'FULL', 0),
('PM0002', 'BK0002', '2026-09-03 10:20:00', 2100000,
 'PAID', 'PT03', 'PAYMENT-PM0002', 'FULL', 0),
('PM0003', 'BK0003', '2026-09-10 08:35:00', 750000,
 'PAID', 'PT01', 'VQR-DEMO-PM0003', 'DEPOSIT', 0),
('PM0004', 'BK0004', '2026-09-11 14:05:00', 885000,
 'PAID', 'PT01', 'VQR-DEMO-PM0004', 'DEPOSIT', 0),
('PM0005', 'BK0005', '2026-09-12 16:15:00', 1000000,
 'PENDING', 'PT01', NULL, 'FULL', 0),
('PM0006', 'BK0006', '2026-09-13 11:50:00', 3350000,
 'PAID', 'PT01', 'VQR-DEMO-PM0006', 'FULL', 0),
('PM0007', 'BK0007', '2026-09-14 09:25:00', 3200000,
 'REFUNDED', 'PT01', 'VQR-DEMO-PM0007', 'FULL', 0),
('PM0008', 'BK0008', '2026-09-15 13:35:00', 2900000,
 'PAID', 'PT03', 'PAYMENT-PM0008', 'FULL', 0),
('PM0009', 'BK0009', '2026-09-16 15:05:00', 1050000,
 'PAID', 'PT01', 'VQR-DEMO-PM0009', 'FULL', 0),
('PM0010', 'BK0010', '2026-09-17 06:35:00', 2400000,
 'FAILED', 'PT01', NULL, 'FULL', 0),
('PM0011', 'BK0011', '2026-07-27 09:05:00', 1075000,
 'PAID', 'PT01', 'VQR-DEMO-PM0011', 'FULL', 0),
('PM0012', 'BK0012', '2026-07-28 09:05:00', 2400000,
 'PAID', 'PT03', 'PAYMENT-PM0012', 'FULL', 0),
('PM0013', 'BK0013', '2026-08-02 09:05:00', 2850000,
 'PAID', 'PT01', 'VQR-DEMO-PM0013', 'FULL', 0),
('PM0014', 'BK0014', '2026-08-05 09:05:00', 3200000,
 'PAID', 'PT01', 'VQR-DEMO-PM0014', 'FULL', 0),
('PM0015', 'BK0015', '2026-08-10 09:05:00', 1650000,
 'PAID', 'PT01', 'VQR-DEMO-PM0015', 'FULL', 0),
('PM0016', 'BK0016', '2026-08-11 09:05:00', 2400000,
 'PAID', 'PT01', 'VQR-DEMO-PM0016', 'FULL', 0),
('PM0017', 'BK0017', '2026-08-16 09:05:00', 2800000,
 'PAID', 'PT01', 'VQR-DEMO-PM0017', 'FULL', 0),
('PM0018', 'BK0018', '2026-08-19 09:05:00', 4800000,
 'PAID', 'PT01', 'VQR-DEMO-PM0018', 'FULL', 0),
('PM0019', 'BK0019', '2026-08-23 09:05:00', 1050000,
 'PAID', 'PT01', 'VQR-DEMO-PM0019', 'FULL', 0),
('PM0020', 'BK0020', '2026-08-24 09:05:00', 2400000,
 'PAID', 'PT01', 'VQR-DEMO-PM0020', 'FULL', 0),
('PM0021', 'BK0021', '2026-08-28 09:05:00', 2750000,
 'PAID', 'PT01', 'VQR-DEMO-PM0021', 'FULL', 0),
('PM0022', 'BK0022', '2026-08-30 09:05:00', 3200000,
 'PAID', 'PT03', 'PAYMENT-PM0022', 'FULL', 0),
('PM0023', 'BK0023', '2026-09-02 09:05:00', 1700000,
 'PAID', 'PT01', 'VQR-DEMO-PM0023', 'FULL', 0),
('PM0024', 'BK0024', '2026-09-04 09:05:00', 1600000,
 'PAID', 'PT01', 'VQR-DEMO-PM0024', 'FULL', 0),
('PM0025', 'BK0025', '2026-09-06 09:05:00', 4050000,
 'PAID', 'PT01', 'VQR-DEMO-PM0025', 'FULL', 0),
('PM0026', 'BK0026', '2026-09-08 09:05:00', 3200000,
 'PAID', 'PT01', 'VQR-DEMO-PM0026', 'FULL', 0),
('PM0027', 'BK0027', '2026-09-10 09:05:00', 1150000,
 'PAID', 'PT01', 'VQR-DEMO-PM0027', 'FULL', 0),
('PM0028', 'BK0028', '2026-09-12 09:05:00', 1600000,
 'PAID', 'PT03', 'PAYMENT-PM0028', 'FULL', 0),
('PM0029', 'BK0029', '2026-09-13 09:05:00', 2550000,
 'PAID', 'PT01', 'VQR-DEMO-PM0029', 'FULL', 0),
('PM0030', 'BK0030', '2026-09-14 09:05:00', 3200000,
 'PAID', 'PT01', 'VQR-DEMO-PM0030', 'FULL', 0),
('PM0031', 'BK0031', '2026-09-23 09:05:00', 405000,
 'PAID', 'PT03', 'PAYMENT-PM0031', 'DEPOSIT', 0),
('PM0032', 'BK0032', '2026-09-20 09:05:00', 1800000,
 'PAID', 'PT01', 'VQR-DEMO-PM0032', 'FULL', 0),
('PM0033', 'BK0033', '2026-09-21 09:05:00', 2400000,
 'PAID', 'PT02', 'PAYMENT-PM0033', 'FULL', 2400000),
('PM0034', 'BK0034', '2026-09-22 09:05:00', 3550000,
 'PAID', 'PT03', 'PAYMENT-PM0034', 'FULL', 0),
('PM0035', 'BK0035', '2026-09-23 09:05:00', 1750000,
 'PAID', 'PT01', 'VQR-DEMO-PM0035', 'FULL', 0),
('PM0036', 'BK0036', '2026-09-20 09:05:00', 1500000,
 'PENDING', 'PT01', NULL, 'FULL', 0),
('PM0037', 'BK0037', '2026-09-21 09:05:00', 2400000,
 'FAILED', 'PT01', NULL, 'FULL', 0),
('PM0038', 'BK0038', '2026-09-22 09:05:00', 3200000,
 'REFUNDED', 'PT01', 'VQR-DEMO-PM0038', 'FULL', 0),
('PM0039', 'BK0039', '2026-09-23 09:05:00', 1050000,
 'PAID', 'PT01', 'VQR-DEMO-PM0039', 'FULL', 350000),
('PM0040', 'BK0040', '2026-09-20 09:05:00', 2850000,
 'PAID', 'PT01', 'VQR-DEMO-PM0040', 'FULL', 0),
('PM0041', 'BK0004', '2026-09-12 10:00:00', 2065000,
 'PAID', 'PT01', 'VQR-DEMO-PM0041', 'BALANCE', 0);
GO

INSERT INTO INVOICE
(InvoiceID, InvoiceDate, TotalAmount, Status, ReplacedInvoiceID, EmployeeID, BookingID)
VALUES
('HD0005', '2026-09-01',  900000, N'Mất hiệu lực', NULL,     'NV02', 'BK0001'),
('HD0007', '2026-09-01', 1075000, N'Có hiệu lực',  'HD0005', 'NV03', 'BK0001'),
('HD0002', '2026-09-03', 2100000, N'Có hiệu lực',  NULL, 'NV04', 'BK0002'),
('HD0003', '2026-09-10', 2500000, N'Có hiệu lực',  NULL, 'NV05', 'BK0003'),
('HD0004', '2026-09-11', 2950000, N'Có hiệu lực',  NULL, 'NV06', 'BK0004'),
('HD0006', '2026-09-13', 3350000, N'Có hiệu lực',  NULL, 'NV02', 'BK0006'),
('HD0008', '2026-09-15', 2900000, N'Có hiệu lực',  NULL, 'NV03', 'BK0008'),
('HD0009', '2026-09-16', 1050000, N'Có hiệu lực',  NULL, 'NV04', 'BK0009'),
('HD0011', '2026-07-27', 1075000, N'Có hiệu lực',  NULL, 'NV05', 'BK0011'),
('HD0012', '2026-07-28', 2400000, N'Có hiệu lực',  NULL, 'NV06', 'BK0012'),
('HD0013', '2026-08-02', 2850000, N'Có hiệu lực',  NULL, 'NV02', 'BK0013'),
('HD0014', '2026-08-05', 3200000, N'Có hiệu lực',  NULL, 'NV03', 'BK0014'),
('HD0015', '2026-08-10', 1650000, N'Có hiệu lực',  NULL, 'NV04', 'BK0015'),
('HD0016', '2026-08-11', 2400000, N'Có hiệu lực',  NULL, 'NV05', 'BK0016'),
('HD0017', '2026-08-16', 2800000, N'Có hiệu lực',  NULL, 'NV06', 'BK0017'),
('HD0018', '2026-08-19', 4800000, N'Có hiệu lực',  NULL, 'NV02', 'BK0018'),
('HD0019', '2026-08-23', 1050000, N'Có hiệu lực',  NULL, 'NV03', 'BK0019'),
('HD0020', '2026-08-24', 2400000, N'Có hiệu lực',  NULL, 'NV04', 'BK0020'),
('HD0021', '2026-08-28', 2750000, N'Có hiệu lực',  NULL, 'NV05', 'BK0021'),
('HD0022', '2026-08-30', 3200000, N'Có hiệu lực',  NULL, 'NV06', 'BK0022'),
('HD0023', '2026-09-02', 1700000, N'Có hiệu lực',  NULL, 'NV02', 'BK0023'),
('HD0024', '2026-09-04', 1600000, N'Có hiệu lực',  NULL, 'NV03', 'BK0024'),
('HD0025', '2026-09-06', 4050000, N'Có hiệu lực',  NULL, 'NV04', 'BK0025'),
('HD0026', '2026-09-08', 3200000, N'Có hiệu lực',  NULL, 'NV05', 'BK0026'),
('HD0027', '2026-09-10', 1150000, N'Có hiệu lực',  NULL, 'NV06', 'BK0027'),
('HD0028', '2026-09-12', 1600000, N'Có hiệu lực',  NULL, 'NV02', 'BK0028'),
('HD0029', '2026-09-13', 2550000, N'Có hiệu lực',  NULL, 'NV03', 'BK0029'),
('HD0030', '2026-09-14', 3200000, N'Có hiệu lực',  NULL, 'NV04', 'BK0030'),
('HD0031', '2026-09-23', 1350000, N'Có hiệu lực',  NULL, 'NV05', 'BK0031'),
('HD0032', '2026-09-20', 1800000, N'Có hiệu lực',  NULL, 'NV06', 'BK0032'),
('HD0033', '2026-09-21', 2400000, N'Có hiệu lực',  NULL, 'NV02', 'BK0033'),
('HD0034', '2026-09-22', 3550000, N'Có hiệu lực',  NULL, 'NV03', 'BK0034'),
('HD0035', '2026-09-23', 1750000, N'Có hiệu lực',  NULL, 'NV04', 'BK0035'),
('HD0039', '2026-09-23', 1050000, N'Có hiệu lực',  NULL, 'NV05', 'BK0039'),
('HD0040', '2026-09-20', 2850000, N'Có hiệu lực',  NULL, 'NV06', 'BK0040');
GO

INSERT INVOICE_TRANSACTION(InvoiceID, BookingID, PaymentID, TransactionID)
SELECT i.InvoiceID, i.BookingID, p.PaymentID, p.TransactionID
FROM INVOICE AS i JOIN PAYMENT AS p ON p.BookingID = i.BookingID
WHERE i.Status = N'Có hiệu lực' AND p.Status IN ('PAID', 'REFUNDED');
GO

INSERT INTO COMPLAINT (Title, Content, Status, CustomerID)
VALUES (
    N'Yêu cầu hỗ trợ đặt phòng',
    N'Tôi muốn kiểm tra lại thông tin phòng đã được sắp xếp cho booking của mình.',
    N'Chưa xử lý',
    'KH03'
);
GO

CREATE PROCEDURE SP_GET_ROOM_TYPE_AVAILABILITY
    @CheckInDate DATE,
    @CheckOutDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    IF @CheckOutDate <= @CheckInDate
    BEGIN
        RAISERROR (
            'Check-out date must be later than check-in date.',
            16,
            1
        );
        RETURN;
    END;

    SELECT
        rt.RoomTypeID,
        rt.TypeName,
        rt.Capacity,
        rt.Price,
        rt.RoomTypeImage,
        COUNT(CASE WHEN r.Status = 'ACTIVE' THEN 1 END) AS TotalActiveRooms,
        COALESCE(reserved.ReservedQuantity, 0) AS ReservedRooms,
        COUNT(CASE WHEN r.Status = 'ACTIVE' THEN 1 END)
            - COALESCE(reserved.ReservedQuantity, 0) AS AvailableRooms
    FROM ROOM_TYPE AS rt
    LEFT JOIN ROOM AS r
        ON r.RoomTypeID = rt.RoomTypeID
    OUTER APPLY (
        SELECT SUM(bd.Quantity) AS ReservedQuantity
        FROM BOOKING_DETAIL AS bd
        INNER JOIN BOOKING AS b
            ON b.BookingID = bd.BookingID
        WHERE bd.RoomTypeID = rt.RoomTypeID
          AND (
              (
                  b.BookingStatus = 'PENDING_PAYMENT'
                  AND b.PaymentDeadline > GETDATE()
              )
              OR b.BookingStatus IN (
                  'CONFIRMED',
                  'ASSIGNED',
                  'CHECKED_IN'
              )
          )
          AND b.CheckInDate < @CheckOutDate
          AND b.CheckOutDate > @CheckInDate
    ) AS reserved
    GROUP BY
        rt.RoomTypeID,
        rt.TypeName,
        rt.Capacity,
        rt.Price,
        rt.RoomTypeImage,
        reserved.ReservedQuantity
    ORDER BY rt.Price;
END;
GO

CREATE INDEX IX_BOOKING_Date_Status
ON BOOKING (CheckInDate, CheckOutDate, BookingStatus);
GO

CREATE INDEX IX_BOOKING_Customer
ON BOOKING (CustomerID, BookingDate);
GO

CREATE INDEX IX_BOOKING_PaymentTimeout
ON BOOKING (BookingStatus, PaymentDeadline);
GO

CREATE INDEX IX_BOOKING_DETAIL_RoomType
ON BOOKING_DETAIL (RoomTypeID, BookingID);
GO

CREATE INDEX IX_ROOM_RoomType_Status
ON ROOM (RoomTypeID, Status);
GO

CREATE INDEX IX_ROOM_ASSIGNMENT_Room
ON ROOM_ASSIGNMENT (RoomID, BookingDetailID);
GO

CREATE INDEX IX_PAYMENT_Booking_Status
ON PAYMENT (BookingID, Status);
GO

USE QLKS;
GO

ALTER TABLE COMPLAINT
ADD ReplyMessage NVARCHAR(MAX) NULL;

ALTER TABLE COMPLAINT
ADD EmployeeID CHAR(6) NULL;

ALTER TABLE dbo.COMPLAINT WITH CHECK
ADD CONSTRAINT FK_COMPLAINT_EMPLOYEE
    FOREIGN KEY (EmployeeID) REFERENCES dbo.EMPLOYEE(EmployeeID);
GO

UPDATE BOOKING SET PaymentOption = 'DEPOSIT'
WHERE BookingID IN ('BK0003', 'BK0004', 'BK0031');
GO

UPDATE b SET FirstPaidAt = p.FirstPaidAt, BookingAmountAtFirstPayment = b.TotalAmount
FROM BOOKING AS b
CROSS APPLY (
    SELECT MIN(PaymentTime) AS FirstPaidAt FROM PAYMENT
    WHERE BookingID = b.BookingID AND Status IN ('PAID', 'REFUNDED')
) AS p
WHERE p.FirstPaidAt IS NOT NULL;
GO

UPDATE BOOKING SET CancelledAt = DATEADD(HOUR, 1, FirstPaidAt),
    CancellationReason = 'CUSTOMER_REQUEST',
    CancelledByUserID = (SELECT UserID FROM CUSTOMER WHERE CUSTOMER.CustomerID = BOOKING.CustomerID)
WHERE BookingStatus = 'CANCELLED';
GO

INSERT BOOKING_REFUND(BookingID, CustomerID, WalletID, Amount, RefundedAt, TransactionID)
SELECT b.BookingID, b.CustomerID, w.WalletID, SUM(p.Amount), b.CancelledAt, CONCAT('REFUND-', RTRIM(b.BookingID))
FROM BOOKING AS b JOIN CUSTOMER_WALLET AS w ON w.CustomerID = b.CustomerID
JOIN PAYMENT AS p ON p.BookingID = b.BookingID AND p.Status = 'REFUNDED'
GROUP BY b.BookingID, b.CustomerID, w.WalletID, b.CancelledAt;

INSERT REFUND_PAYMENT(RefundID, BookingID, PaymentID, Amount)
SELECT r.RefundID, p.BookingID, p.PaymentID, p.Amount
FROM BOOKING_REFUND AS r JOIN PAYMENT AS p ON p.BookingID = r.BookingID
WHERE p.Status = 'REFUNDED';

INSERT WALLET_TRANSACTION(WalletID, TransactionType, Amount, TransactionTime, RefundID, TransactionID)
SELECT WalletID, 'REFUND_CREDIT', Amount, RefundedAt, RefundID, TransactionID FROM BOOKING_REFUND;

INSERT WALLET_TRANSACTION(WalletID, TransactionType, Amount, TransactionTime, PaymentID, TransactionID)
SELECT w.WalletID, 'PAYMENT_DEBIT', p.WalletAmount, p.PaymentTime, p.PaymentID, p.TransactionID
FROM PAYMENT AS p JOIN BOOKING AS b ON b.BookingID = p.BookingID
JOIN CUSTOMER_WALLET AS w ON w.CustomerID = b.CustomerID
WHERE p.WalletAmount > 0 AND p.Status IN ('PAID', 'REFUNDED');
GO

UPDATE c SET WindowStartedAt = b.CancelledAt, ConsecutiveCancellationCount = 1,
    CancellationCountInWindow = 1, UpdatedAt = b.CancelledAt
FROM USER_BOOKING_CONTROL AS c
JOIN CUSTOMER AS cu ON cu.UserID = c.UserID
JOIN BOOKING AS b ON b.CustomerID = cu.CustomerID AND b.BookingStatus = 'CANCELLED';
GO

ALTER TABLE BOOKING ADD CONSTRAINT CK_BOOKING_CancellationData CHECK (
    (BookingStatus = 'CANCELLED' AND CancelledAt IS NOT NULL AND CancellationReason IS NOT NULL)
    OR (BookingStatus <> 'CANCELLED' AND CancelledAt IS NULL
        AND CancellationReason IS NULL AND CancelledByUserID IS NULL)
);
GO

CREATE VIEW V_WALLET_BALANCE AS
SELECT w.WalletID, w.CustomerID, w.CreatedAt,
    CAST(COALESCE(SUM(CASE WHEN t.TransactionType = 'REFUND_CREDIT'
        THEN t.Amount ELSE -t.Amount END), 0) AS DECIMAL(12,2)) AS Balance
FROM CUSTOMER_WALLET AS w LEFT JOIN WALLET_TRANSACTION AS t ON t.WalletID = w.WalletID
GROUP BY w.WalletID, w.CustomerID, w.CreatedAt;
GO

CREATE VIEW V_BOOKING_PAYMENT_SUMMARY AS
SELECT b.BookingID, b.CustomerID, b.BookingStatus, b.PaymentOption, b.TotalAmount,
    b.BookingAmountAtFirstPayment, b.FirstPaidAt, b.RefundDeadline,
    b.CancelledAt, b.CancellationReason,
    CAST(CASE WHEN b.PaymentOption = 'DEPOSIT'
        THEN ROUND(COALESCE(b.BookingAmountAtFirstPayment, b.TotalAmount) * 0.30, 2)
        ELSE COALESCE(b.BookingAmountAtFirstPayment, b.TotalAmount) END AS DECIMAL(12,2)) AS InitialRequiredAmount,
    p.TotalPaidAmount, COALESCE(r.Amount, 0) AS RefundedAmount,
    p.TotalPaidAmount - COALESCE(r.Amount, 0) AS NetPaidAmount,
    CAST(CASE WHEN b.BookingStatus = 'CANCELLED' THEN 0
        WHEN b.TotalAmount > p.TotalPaidAmount THEN b.TotalAmount - p.TotalPaidAmount
        ELSE 0 END AS DECIMAL(12,2)) AS RemainingAmount,
    CASE WHEN r.RefundID IS NOT NULL THEN 'REFUNDED'
        WHEN b.BookingStatus = 'CANCELLED' AND p.TotalPaidAmount > 0 THEN 'NO_REFUND'
        WHEN p.TotalPaidAmount = 0 THEN 'UNPAID'
        WHEN p.TotalPaidAmount >= b.TotalAmount THEN 'FULLY_PAID'
        ELSE 'DEPOSIT_PAID' END AS PaymentStatus
FROM BOOKING AS b
OUTER APPLY (
    SELECT CAST(COALESCE(SUM(Amount), 0) AS DECIMAL(12,2)) AS TotalPaidAmount
    FROM PAYMENT WHERE BookingID = b.BookingID AND Status IN ('PAID', 'REFUNDED')
) AS p LEFT JOIN BOOKING_REFUND AS r ON r.BookingID = b.BookingID;
GO

CREATE OR ALTER VIEW dbo.V_BOOKING_ROOM_BALANCE AS
SELECT ps.BookingID, charges.RoomTotal, charges.ServiceTotal,
    CAST(CASE WHEN ps.TotalPaidAmount >= charges.RoomTotal THEN charges.RoomTotal
        ELSE ps.TotalPaidAmount END AS DECIMAL(12,2)) AS RoomPaidAmount,
    CAST(CASE WHEN ps.BookingStatus = 'CANCELLED' OR ps.TotalPaidAmount >= charges.RoomTotal THEN 0
        ELSE charges.RoomTotal - ps.TotalPaidAmount END AS DECIMAL(12,2)) AS RoomRemainingAmount,
    CAST(CASE WHEN ps.BookingStatus = 'CANCELLED' THEN 0
        WHEN ps.TotalPaidAmount <= charges.RoomTotal THEN charges.ServiceTotal
        WHEN ps.TotalPaidAmount >= charges.RoomTotal + charges.ServiceTotal THEN 0
        ELSE charges.RoomTotal + charges.ServiceTotal - ps.TotalPaidAmount END AS DECIMAL(12,2)) AS ServiceRemainingAmount
FROM dbo.V_BOOKING_PAYMENT_SUMMARY ps
CROSS APPLY (
    SELECT CAST(COALESCE((SELECT SUM(d.Subtotal) FROM dbo.BOOKING_DETAIL d
        WHERE d.BookingID = ps.BookingID), 0) AS DECIMAL(12,2)) AS RoomTotal,
        CAST(COALESCE((SELECT SUM(s.Subtotal) FROM dbo.BOOKING_SERVICE s
        WHERE s.BookingID = ps.BookingID), 0) AS DECIMAL(12,2)) AS ServiceTotal
) charges;
GO

CREATE VIEW V_USER_BOOKING_ACCESS AS
SELECT c.UserID, cu.CustomerID,
    CASE WHEN c.WindowStartedAt IS NULL OR DATEADD(DAY, 1, c.WindowStartedAt) <= SYSDATETIME()
        THEN 0 ELSE c.ConsecutiveCancellationCount END AS ConsecutiveCancellationCount,
    CASE WHEN c.WindowStartedAt IS NULL OR DATEADD(DAY, 1, c.WindowStartedAt) <= SYSDATETIME()
        THEN 0 ELSE c.CancellationCountInWindow END AS CancellationCountInWindow,
    CASE WHEN c.WindowStartedAt IS NULL OR DATEADD(DAY, 1, c.WindowStartedAt) <= SYSDATETIME()
        THEN 0 ELSE c.PenaltyLevel END AS PenaltyLevel,
    CASE WHEN DATEADD(DAY, 1, c.WindowStartedAt) > SYSDATETIME()
        AND c.BookingLockedUntil > SYSDATETIME() THEN c.BookingLockedUntil END AS BookingLockedUntil,
    pending.BookingID AS PendingBookingID,
    CAST(CASE WHEN pending.BookingID IS NOT NULL OR (
        DATEADD(DAY, 1, c.WindowStartedAt) > SYSDATETIME()
        AND c.BookingLockedUntil > SYSDATETIME()) THEN 0 ELSE 1 END AS BIT) AS CanCreateBooking
FROM USER_BOOKING_CONTROL AS c JOIN CUSTOMER AS cu ON cu.UserID = c.UserID
LEFT JOIN BOOKING AS pending ON pending.CustomerID = cu.CustomerID AND pending.BookingStatus = 'PENDING_PAYMENT';
GO

CREATE PROCEDURE SP_HBMS_ACQUIRE_WRITE_LOCK AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Result INT;
    EXEC @Result = sys.sp_getapplock @Resource = N'HBMS:booking-wallet-write',
        @LockMode = 'Exclusive', @LockOwner = 'Transaction', @LockTimeout = 10000;
    IF @Result < 0 THROW 51000, 'System busy. Please retry the request.', 1;
END;
GO

CREATE PROCEDURE SP_RESET_BOOKING_CONTROL @UserID INT = NULL AS
BEGIN
    SET NOCOUNT ON;
    UPDATE USER_BOOKING_CONTROL
    SET WindowStartedAt = NULL, ConsecutiveCancellationCount = 0,
        CancellationCountInWindow = 0, PenaltyLevel = 0,
        BookingLockedUntil = NULL, UpdatedAt = SYSDATETIME()
    WHERE (@UserID IS NULL OR UserID = @UserID)
      AND DATEADD(DAY, 1, WindowStartedAt) <= SYSDATETIME();
END;
GO

CREATE PROCEDURE SP_CANCEL_BOOKING
    @BookingID CHAR(6),
    @ActorUserID INT = NULL,
    @Reason VARCHAR(30) = 'CUSTOMER_REQUEST',
    @ReturnResult BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;
        DECLARE @Now DATETIME2(3) = SYSDATETIME(), @CustomerID CHAR(6), @OwnerUserID INT,
            @Status VARCHAR(30), @FirstPaidAt DATETIME2(3), @Deadline DATETIME,
            @Paid DECIMAL(12,2), @WalletID BIGINT, @RefundID BIGINT,
            @Streak INT, @Level TINYINT, @Minutes INT, @PreviouslyLockedUntil DATETIME2(3);
        SELECT @CustomerID = b.CustomerID, @OwnerUserID = c.UserID,
            @Status = b.BookingStatus, @FirstPaidAt = b.FirstPaidAt, @Deadline = b.PaymentDeadline
        FROM BOOKING AS b WITH (UPDLOCK, HOLDLOCK)
        JOIN CUSTOMER AS c ON c.CustomerID = b.CustomerID WHERE b.BookingID = @BookingID;
        IF @CustomerID IS NULL THROW 51001, 'Booking not found.', 1;
        IF @Reason IS NULL OR @Reason NOT IN ('CUSTOMER_REQUEST', 'STAFF_REQUEST', 'PAYMENT_TIMEOUT')
            THROW 51002, 'Invalid cancellation reason.', 1;
        IF @Reason = 'CUSTOMER_REQUEST' AND (@ActorUserID IS NULL OR @ActorUserID <> @OwnerUserID)
            THROW 51003, 'You cannot cancel another customer booking.', 1;
        IF @Reason = 'STAFF_REQUEST' AND NOT EXISTS (
            SELECT 1 FROM USERS WHERE UserID = @ActorUserID AND Role IN ('Admin', 'Staff'))
            THROW 51004, 'Only staff or admin can cancel on behalf of customers.', 1;
        IF @Reason = 'PAYMENT_TIMEOUT' AND (@ActorUserID IS NOT NULL OR @FirstPaidAt IS NOT NULL
            OR @Deadline IS NULL OR @Deadline > @Now)
            THROW 51005, 'Payment timeout cancellation is not applicable.', 1;

        IF @Status = 'CANCELLED'
        BEGIN
            COMMIT TRANSACTION;
            IF @ReturnResult = 1 SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
            RETURN;
        END;
        IF @Status NOT IN ('PENDING_PAYMENT', 'CONFIRMED', 'ASSIGNED')
            THROW 51006, 'Only bookings before check-in can be cancelled.', 1;

        UPDATE BOOKING SET BookingStatus = 'CANCELLED', CancelledAt = @Now,
            CancellationReason = @Reason, CancelledByUserID = @ActorUserID
        WHERE BookingID = @BookingID;
        UPDATE PAYMENT SET Status = 'FAILED' WHERE BookingID = @BookingID AND Status = 'PENDING';
        UPDATE INVOICE SET Status = N'Mất hiệu lực' WHERE BookingID = @BookingID AND Status = N'Có hiệu lực';

        SELECT @Paid = COALESCE(SUM(Amount), 0) FROM PAYMENT
        WHERE BookingID = @BookingID AND Status = 'PAID';
        IF @Paid > 0 AND @FirstPaidAt IS NOT NULL AND @Now < DATEADD(HOUR, 24, @FirstPaidAt)
        BEGIN
            SELECT @WalletID = WalletID FROM CUSTOMER_WALLET WHERE CustomerID = @CustomerID;
            IF @WalletID IS NULL THROW 51007, 'Customer wallet not found.', 1;
            DECLARE @RefundTransactionID VARCHAR(100) = CONCAT('REFUND-', RTRIM(@BookingID));
            INSERT dbo.[TRANSACTION](TransactionID, TransactionType, TransactionValue)
            VALUES (@RefundTransactionID, 'REFUND', @Paid);
            INSERT BOOKING_REFUND(BookingID, CustomerID, WalletID, Amount, RefundedAt, TransactionID)
            VALUES (@BookingID, @CustomerID, @WalletID, @Paid, @Now, @RefundTransactionID);
            SET @RefundID = CONVERT(BIGINT, SCOPE_IDENTITY());
            INSERT REFUND_PAYMENT(RefundID, BookingID, PaymentID, Amount)
            SELECT @RefundID, BookingID, PaymentID, Amount FROM PAYMENT
            WHERE BookingID = @BookingID AND Status = 'PAID';
            INSERT WALLET_TRANSACTION(WalletID, TransactionType, Amount, TransactionTime, RefundID, TransactionID)
            VALUES (@WalletID, 'REFUND_CREDIT', @Paid, @Now, @RefundID, @RefundTransactionID);
            UPDATE PAYMENT SET Status = 'REFUNDED' WHERE BookingID = @BookingID AND Status = 'PAID';
        END;

        EXEC SP_RESET_BOOKING_CONTROL @UserID = @OwnerUserID;

        SELECT @PreviouslyLockedUntil = BookingLockedUntil FROM USER_BOOKING_CONTROL WHERE UserID = @OwnerUserID;
        UPDATE USER_BOOKING_CONTROL SET WindowStartedAt = COALESCE(WindowStartedAt, @Now),
            ConsecutiveCancellationCount = ConsecutiveCancellationCount
                + CASE WHEN BookingLockedUntil > @Now THEN 0 ELSE 1 END,
            CancellationCountInWindow = CancellationCountInWindow + 1, UpdatedAt = @Now
        WHERE UserID = @OwnerUserID;
        SELECT @Streak = ConsecutiveCancellationCount, @Level = PenaltyLevel
        FROM USER_BOOKING_CONTROL WHERE UserID = @OwnerUserID;
        IF (@PreviouslyLockedUntil IS NULL OR @PreviouslyLockedUntil <= @Now)
            AND @Streak >= CASE WHEN @Level = 0 THEN 3 WHEN @Level = 1 THEN 2 ELSE 1 END
        BEGIN
            SET @Level = CASE WHEN @Level < 3 THEN @Level + 1 ELSE 3 END;
            SET @Minutes = CASE WHEN @Level = 1 THEN 5 WHEN @Level = 2 THEN 15 ELSE 60 END;
            UPDATE USER_BOOKING_CONTROL SET PenaltyLevel = @Level,
                ConsecutiveCancellationCount = 0, BookingLockedUntil = DATEADD(MINUTE, @Minutes, @Now)
            WHERE UserID = @OwnerUserID;
            INSERT BOOKING_LOCK_HISTORY(UserID, TriggerBookingID, PenaltyLevel, LockedAt, LockedUntil, DurationMinutes)
            VALUES (@OwnerUserID, @BookingID, @Level, @Now, DATEADD(MINUTE, @Minutes, @Now), @Minutes);
        END;
        COMMIT TRANSACTION;
        IF @ReturnResult = 1 SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE PROCEDURE SP_EXPIRE_PENDING_BOOKINGS
    @CustomerID CHAR(6) = NULL, @ReturnResult BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @BookingID CHAR(6), @Count INT = 0;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;

        DECLARE expired CURSOR LOCAL FAST_FORWARD FOR
            SELECT BookingID FROM BOOKING WHERE BookingStatus = 'PENDING_PAYMENT'
                AND PaymentDeadline <= SYSDATETIME() AND (@CustomerID IS NULL OR CustomerID = @CustomerID)
            ORDER BY BookingDate, BookingID;
        OPEN expired;
        FETCH NEXT FROM expired INTO @BookingID;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            EXEC SP_CANCEL_BOOKING @BookingID = @BookingID, @ActorUserID = NULL,
                @Reason = 'PAYMENT_TIMEOUT', @ReturnResult = 0;
            SET @Count += 1;
            FETCH NEXT FROM expired INTO @BookingID;
        END;
        CLOSE expired;
        DEALLOCATE expired;
        EXEC SP_RESET_BOOKING_CONTROL;
        COMMIT TRANSACTION;
        IF @ReturnResult = 1 SELECT @Count AS ExpiredBookingCount;
        RETURN @Count;
    END TRY
    BEGIN CATCH
        IF CURSOR_STATUS('local', 'expired') >= 0 CLOSE expired;
        IF CURSOR_STATUS('local', 'expired') >= -1 DEALLOCATE expired;
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE TYPE BOOKING_ROOM_INPUT AS TABLE (
    RoomTypeID CHAR(4) NOT NULL PRIMARY KEY,
    Quantity INT NOT NULL CHECK (Quantity > 0),
    GuestCount INT NOT NULL CHECK (GuestCount > 0)
);
GO

CREATE PROCEDURE SP_CREATE_BOOKING
    @BookingID CHAR(6), @CustomerID CHAR(6), @ActorUserID INT,
    @CheckInDate DATE, @CheckOutDate DATE, @PaymentOption VARCHAR(10),
    @Rooms BOOKING_ROOM_INPUT READONLY,
    @PaymentDeadline DATETIME
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @OwnerUserID INT;
    SELECT @OwnerUserID = UserID FROM CUSTOMER WHERE CustomerID = @CustomerID;
    IF @OwnerUserID IS NULL THROW 51010, 'Customer not found.', 1;
    IF @ActorUserID IS NULL OR (@ActorUserID <> @OwnerUserID AND NOT EXISTS (
        SELECT 1 FROM USERS WHERE UserID = @ActorUserID AND Role IN ('Admin', 'Staff')))
        THROW 51011, 'Not authorized to create this booking.', 1;
    IF @PaymentOption IS NULL OR @PaymentOption NOT IN ('DEPOSIT', 'FULL')
        THROW 51012, 'Choose DEPOSIT (30 percent) or FULL.', 1;
    IF @CheckInDate IS NULL OR @CheckOutDate IS NULL OR @CheckOutDate <= @CheckInDate
        THROW 51013, 'Invalid stay dates.', 1;
    IF @PaymentDeadline IS NULL OR @PaymentDeadline <= SYSDATETIME()
        THROW 51014, 'Payment deadline must be in the future.', 1;
    IF NOT EXISTS (SELECT 1 FROM @Rooms) THROW 51015, 'At least one room type is required.', 1;

    IF @@TRANCOUNT <> 0 THROW 51021, 'Call SP_CREATE_BOOKING without an outer transaction.', 1;

    EXEC SP_EXPIRE_PENDING_BOOKINGS @CustomerID = @CustomerID, @ReturnResult = 0;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;
        EXEC SP_RESET_BOOKING_CONTROL @UserID = @OwnerUserID;
        IF @PaymentDeadline <= SYSDATETIME() THROW 51014, 'Payment deadline must be in the future.', 1;
        IF EXISTS (SELECT 1 FROM USER_BOOKING_CONTROL WHERE UserID = @OwnerUserID
            AND BookingLockedUntil > SYSDATETIME())
            THROW 51016, 'Booking temporarily locked. Check V_USER_BOOKING_ACCESS for unlock time.', 1;
        IF EXISTS (SELECT 1 FROM BOOKING WHERE CustomerID = @CustomerID AND BookingStatus = 'PENDING_PAYMENT')
            THROW 51017, 'Pay the existing booking deposit/full amount or cancel it before creating another.', 1;
        IF EXISTS (SELECT 1 FROM @Rooms AS i LEFT JOIN ROOM_TYPE AS rt ON rt.RoomTypeID = i.RoomTypeID
            WHERE rt.RoomTypeID IS NULL OR i.GuestCount > i.Quantity * rt.Capacity)
            THROW 51018, 'Invalid room type or guest capacity.', 1;
        IF EXISTS (
            SELECT 1 FROM @Rooms AS i
            CROSS APPLY (SELECT COUNT(*) AS ActiveRooms FROM ROOM
                WHERE RoomTypeID = i.RoomTypeID AND Status = 'ACTIVE') AS available
            OUTER APPLY (
                SELECT COALESCE(SUM(d.Quantity), 0) AS ReservedRooms
                FROM BOOKING_DETAIL AS d JOIN BOOKING AS b ON b.BookingID = d.BookingID
                WHERE d.RoomTypeID = i.RoomTypeID
                  AND (b.BookingStatus IN ('CONFIRMED', 'ASSIGNED', 'CHECKED_IN')
                    OR (b.BookingStatus = 'PENDING_PAYMENT' AND b.PaymentDeadline > SYSDATETIME()))
                  AND b.CheckInDate < @CheckOutDate AND b.CheckOutDate > @CheckInDate
            ) AS reserved
            WHERE i.Quantity > available.ActiveRooms - reserved.ReservedRooms
        ) THROW 51019, 'Not enough available rooms for the requested dates.', 1;
        INSERT BOOKING(BookingID, BookingDate, PaymentDeadline, CheckInDate, CheckOutDate,
            BookingStatus, CustomerID, PaymentOption)
        VALUES (@BookingID, SYSDATETIME(), @PaymentDeadline, @CheckInDate, @CheckOutDate,
            'PENDING_PAYMENT', @CustomerID, @PaymentOption);
        INSERT BOOKING_DETAIL(BookingID, RoomTypeID, Quantity, GuestCount, UnitPrice, Subtotal)
        SELECT @BookingID, i.RoomTypeID, i.Quantity, i.GuestCount, rt.Price,
            i.Quantity * rt.Price * DATEDIFF(DAY, @CheckInDate, @CheckOutDate)
        FROM @Rooms AS i JOIN ROOM_TYPE AS rt ON rt.RoomTypeID = i.RoomTypeID;
        IF EXISTS (SELECT 1 FROM BOOKING WHERE BookingID = @BookingID AND TotalAmount <= 0)
            THROW 51020, 'Booking amount must be positive.', 1;
        COMMIT TRANSACTION;
        SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE PROCEDURE SP_RECORD_PAYMENT
    @PaymentID CHAR(6), @BookingID CHAR(6), @ActorUserID INT,
    @PaymentType VARCHAR(10), @Amount DECIMAL(12,2), @MethodID CHAR(4),
    @TransactionCode VARCHAR(100) = NULL, @WalletAmount DECIMAL(12,2) = 0,
    @TransactionID VARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;
        DECLARE @Now DATETIME2(3) = SYSDATETIME(), @CustomerID CHAR(6), @OwnerUserID INT,
            @Status VARCHAR(30), @Option VARCHAR(10), @FirstPaidAt DATETIME2(3),
            @Total DECIMAL(12,2), @Paid DECIMAL(12,2), @Required DECIMAL(12,2),
            @Deadline DATETIME, @WalletID BIGINT, @Balance DECIMAL(12,2);
        SELECT @CustomerID = b.CustomerID, @OwnerUserID = c.UserID, @Status = b.BookingStatus,
            @Option = b.PaymentOption, @FirstPaidAt = b.FirstPaidAt, @Total = b.TotalAmount,
            @Deadline = b.PaymentDeadline
        FROM BOOKING AS b WITH (UPDLOCK, HOLDLOCK)
        JOIN CUSTOMER AS c ON c.CustomerID = b.CustomerID WHERE b.BookingID = @BookingID;
        IF @CustomerID IS NULL THROW 51030, 'Booking not found.', 1;
        IF @ActorUserID IS NULL OR (@ActorUserID <> @OwnerUserID AND NOT EXISTS (
            SELECT 1 FROM USERS WHERE UserID = @ActorUserID AND Role IN ('Admin', 'Staff')))
            THROW 51031, 'Not authorized to pay for this booking.', 1;
        IF @Amount IS NULL OR @Amount <= 0 THROW 51032, 'Payment amount must be positive.', 1;
        IF @PaymentType IS NULL OR @PaymentType NOT IN ('DEPOSIT', 'FULL', 'BALANCE')
            THROW 51033, 'Invalid payment type.', 1;
        IF NOT EXISTS (SELECT 1 FROM PAYMENTMETHOD WHERE MethodID = @MethodID)
            THROW 51034, 'Payment method not found.', 1;
        SET @TransactionCode = NULLIF(LTRIM(RTRIM(@TransactionCode)), '');
        SET @TransactionID = NULLIF(LTRIM(RTRIM(@TransactionID)), '');
        IF @WalletAmount IS NULL OR @WalletAmount < 0 OR @WalletAmount > @Amount
            THROW 51047, 'Invalid wallet contribution.', 1;
        IF @MethodID = 'PT02'
        BEGIN
            SET @WalletAmount = @Amount;
            SET @TransactionCode = CONCAT('WALLET-', RTRIM(@PaymentID));
        END
        ELSE IF @WalletAmount >= @Amount OR (@WalletAmount > 0 AND @MethodID <> 'PT01')
            THROW 51047, 'Choose Internal wallet for a wallet-only payment, or VietQR for the shortfall.', 1;
        IF @WalletAmount > 0 AND @ActorUserID <> @OwnerUserID
            THROW 51048, 'Only the wallet owner can authorize a wallet contribution.', 1;
        IF @MethodID = 'PT03'
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM USERS AS u JOIN EMPLOYEE AS e ON e.UserID = u.UserID
                WHERE u.UserID = @ActorUserID AND u.Role = 'Staff' AND e.Position = N'Receptionist')
                THROW 51035, 'Cash collection must be recorded by a receptionist on behalf of the customer.', 1;
            IF @TransactionCode IS NULL SET @TransactionCode = CONCAT('CASH-', RTRIM(@PaymentID));
        END;
        IF @TransactionID IS NULL AND @MethodID <> 'PT01'
            SET @TransactionID = CONCAT('PAYMENT-', RTRIM(@PaymentID));
        IF @TransactionID IS NULL
            THROW 51210, 'VietQR requires the verified transaction ID from the payment provider.', 1;
        IF @TransactionCode IS NULL OR LEN(LTRIM(RTRIM(@TransactionCode))) = 0
            THROW 51036, 'Successful payment requires a unique transaction code.', 1;

        IF EXISTS (SELECT 1 FROM PAYMENT WHERE PaymentID = @PaymentID AND Status IN ('PAID', 'REFUNDED'))
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM PAYMENT AS p
                JOIN dbo.[TRANSACTION] AS t ON t.TransactionID = p.TransactionID
                WHERE p.PaymentID = @PaymentID AND p.BookingID = @BookingID
                AND p.PaymentType = @PaymentType AND p.Amount = @Amount AND p.WalletAmount = @WalletAmount AND p.MethodID = @MethodID
                AND t.TransactionCode = @TransactionCode AND p.TransactionID = @TransactionID)
                THROW 51037, 'Payment ID already used with different payment data.', 1;
            COMMIT TRANSACTION;
            SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
            RETURN;
        END;
        IF EXISTS (SELECT 1 FROM dbo.[TRANSACTION] WHERE TransactionCode = @TransactionCode)
            THROW 51038, 'Transaction code already recorded in the transaction ledger.', 1;
        IF @TransactionID IS NOT NULL AND EXISTS (
            SELECT 1 FROM dbo.[TRANSACTION] WHERE TransactionID = @TransactionID)
            THROW 51049, 'Transaction ID already recorded in the transaction ledger.', 1;
        IF @Status IN ('CANCELLED', 'CHECKED_OUT')
            THROW 51039, 'Cannot record a new payment on a cancelled or completed booking.', 1;
        IF @Status = 'PENDING_PAYMENT' AND @Deadline <= @Now
            THROW 51040, 'Payment deadline has expired. Do not collect money for this booking.', 1;
        SELECT @Paid = COALESCE(SUM(Amount), 0) FROM PAYMENT WHERE BookingID = @BookingID AND Status = 'PAID';
        IF @FirstPaidAt IS NULL
        BEGIN
            IF @Status <> 'PENDING_PAYMENT' OR @Paid <> 0
                THROW 51041, 'Booking has an inconsistent initial payment state.', 1;
            IF (@Option = 'DEPOSIT' AND @PaymentType <> 'DEPOSIT')
                OR (@Option = 'FULL' AND @PaymentType <> 'FULL')
                THROW 51042, 'Payment type must match the selected booking option.', 1;
            SET @Required = CASE WHEN @Option = 'DEPOSIT' THEN ROUND(@Total * 0.30, 2) ELSE @Total END;
        END
        ELSE
        BEGIN
            IF @PaymentType <> 'BALANCE' THROW 51043, 'Initial payment already made; use BALANCE.', 1;
            SET @Required = @Total - @Paid;
        END;
        IF @Required <= 0 OR @Amount <> @Required
            THROW 51044, 'Pay exactly the initial required amount or the current remaining balance.', 1;
        IF EXISTS (SELECT 1 FROM PAYMENT WHERE PaymentID = @PaymentID AND (
            BookingID <> @BookingID OR PaymentType <> @PaymentType OR Amount <> @Amount))
            THROW 51045, 'Payment attempt does not match this booking and amount.', 1;
        IF @WalletAmount > 0
        BEGIN
            SELECT @WalletID = WalletID, @Balance = Balance FROM V_WALLET_BALANCE WHERE CustomerID = @CustomerID;
            IF @WalletID IS NULL OR @Balance < @WalletAmount
                THROW 51046, 'Insufficient internal wallet balance.', 1;
        END;
        INSERT dbo.[TRANSACTION](TransactionID, TransactionCode, TransactionType, TransactionValue)
        VALUES (@TransactionID, @TransactionCode, 'PAYMENT', @Amount);
        IF EXISTS (SELECT 1 FROM PAYMENT WHERE PaymentID = @PaymentID)
            UPDATE PAYMENT SET Status = 'PAID', PaymentTime = @Now,
                MethodID = @MethodID, WalletAmount = @WalletAmount, TransactionID = @TransactionID WHERE PaymentID = @PaymentID;
        ELSE
            INSERT PAYMENT(PaymentID, BookingID, PaymentType, PaymentTime, Amount, Status, MethodID, WalletAmount, TransactionID)
            VALUES (@PaymentID, @BookingID, @PaymentType, @Now, @Amount, 'PAID', @MethodID, @WalletAmount, @TransactionID);
        IF @WalletAmount > 0
            INSERT WALLET_TRANSACTION(WalletID, TransactionType, Amount, TransactionTime, PaymentID, TransactionID)
            VALUES (@WalletID, 'PAYMENT_DEBIT', @WalletAmount, @Now, @PaymentID, @TransactionID);
        INSERT INVOICE_TRANSACTION(InvoiceID, BookingID, PaymentID, TransactionID)
        SELECT i.InvoiceID, @BookingID, @PaymentID, @TransactionID
        FROM INVOICE AS i
        WHERE i.BookingID = @BookingID AND i.Status = N'Có hiệu lực'
          AND NOT EXISTS (SELECT 1 FROM INVOICE_TRANSACTION AS link
              WHERE link.InvoiceID = i.InvoiceID AND link.TransactionID = @TransactionID);
        IF @FirstPaidAt IS NULL
            UPDATE BOOKING SET FirstPaidAt = @Now, BookingAmountAtFirstPayment = @Total,
                BookingStatus = 'CONFIRMED', PaymentDeadline = NULL WHERE BookingID = @BookingID;
        COMMIT TRANSACTION;
        SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE PROCEDURE SP_ADD_BOOKING_SERVICE
    @BookingID CHAR(6), @ServiceID CHAR(4), @Quantity INT, @ActorUserID INT,
    @UnitPrice DECIMAL(12,2) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;
        IF @Quantity IS NULL OR @Quantity <= 0 THROW 51050, 'Service quantity must be positive.', 1;
        IF NOT EXISTS (SELECT 1 FROM BOOKING AS b JOIN CUSTOMER AS c ON c.CustomerID = b.CustomerID
            WHERE b.BookingID = @BookingID AND b.BookingStatus IN ('PENDING_PAYMENT', 'CONFIRMED', 'ASSIGNED', 'CHECKED_IN')
            AND (c.UserID = @ActorUserID OR EXISTS (
                SELECT 1 FROM USERS WHERE UserID = @ActorUserID AND Role IN ('Admin', 'Staff'))))
            THROW 51051, 'Booking not found, not authorized, or no longer accepts services.', 1;
        IF EXISTS (SELECT 1 FROM BOOKING WHERE BookingID = @BookingID AND BookingStatus = 'PENDING_PAYMENT'
            AND PaymentDeadline <= SYSDATETIME()) THROW 51052, 'Pending booking has expired.', 1;
        DECLARE @CatalogPrice DECIMAL(12,2);
        SELECT @CatalogPrice = UnitPrice FROM SERVICE WHERE ServiceID = @ServiceID;
        IF @CatalogPrice IS NULL THROW 51053, 'Service not found.', 1;
        IF @UnitPrice IS NOT NULL AND @UnitPrice <> @CatalogPrice AND NOT EXISTS (
            SELECT 1 FROM USERS WHERE UserID = @ActorUserID AND Role IN ('Admin', 'Staff'))
            THROW 51054, 'Only staff can set a service price different from the catalog.', 1;
        SET @UnitPrice = COALESCE(@UnitPrice, @CatalogPrice);
        IF @UnitPrice < 0 THROW 51055, 'Service price cannot be negative.', 1;
        IF EXISTS (SELECT 1 FROM BOOKING_SERVICE WHERE BookingID = @BookingID AND ServiceID = @ServiceID)
        BEGIN
            IF EXISTS (SELECT 1 FROM BOOKING_SERVICE WHERE BookingID = @BookingID AND ServiceID = @ServiceID
                AND UnitPrice <> @UnitPrice) THROW 51056, 'Existing service has a different price snapshot.', 1;
            UPDATE BOOKING_SERVICE SET Quantity = Quantity + @Quantity,
                Subtotal = (Quantity + @Quantity) * UnitPrice
            WHERE BookingID = @BookingID AND ServiceID = @ServiceID;
        END
        ELSE
            INSERT BOOKING_SERVICE(BookingID, ServiceID, Quantity, UnitPrice, Subtotal)
            VALUES (@BookingID, @ServiceID, @Quantity, @UnitPrice, @Quantity * @UnitPrice);
        COMMIT TRANSACTION;
        SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE PROCEDURE dbo.SP_SET_BOOKING_STATUS
    @BookingID CHAR(6), @NewStatus VARCHAR(30), @ActorUserID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;
        IF NOT EXISTS (SELECT 1 FROM USERS WHERE UserID = @ActorUserID AND Role IN ('Admin', 'Staff'))
            THROW 51060, 'Only staff/admin can manage stay status.', 1;
        DECLARE @OldStatus VARCHAR(30), @OwnerUserID INT;
        SELECT @OldStatus = b.BookingStatus, @OwnerUserID = c.UserID
        FROM BOOKING AS b JOIN CUSTOMER AS c ON c.CustomerID = b.CustomerID WHERE BookingID = @BookingID;
        IF @OldStatus IS NULL THROW 51061, 'Booking not found.', 1;
        IF @NewStatus IS NULL OR @NewStatus NOT IN ('ASSIGNED', 'CHECKED_IN', 'CHECKED_OUT')
            THROW 51062, 'Use payment/cancellation procedures for other status changes.', 1;
        IF @NewStatus = @OldStatus
        BEGIN
            COMMIT TRANSACTION;
            RETURN;
        END;
        IF NOT ((@OldStatus = 'CONFIRMED' AND @NewStatus = 'ASSIGNED')
            OR (@OldStatus = 'ASSIGNED' AND @NewStatus = 'CHECKED_IN')
            OR (@OldStatus = 'CHECKED_IN' AND @NewStatus = 'CHECKED_OUT'))
            THROW 51063, 'Invalid stay status transition.', 1;
        IF @NewStatus IN ('ASSIGNED', 'CHECKED_IN') AND EXISTS (
            SELECT 1 FROM BOOKING_DETAIL AS d WHERE d.BookingID = @BookingID
            AND d.Quantity <> (SELECT COUNT(*) FROM ROOM_ASSIGNMENT AS a WHERE a.BookingDetailID = d.BookingDetailID))
            THROW 51064, 'Assign all requested rooms first.', 1;
        IF @NewStatus = 'CHECKED_OUT' AND EXISTS (
            SELECT 1 FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID AND RemainingAmount > 0)
            THROW 51065, 'Pay the remaining balance before check-out.', 1;
        IF @NewStatus = 'CHECKED_IN'
        BEGIN
            IF EXISTS (SELECT 1 FROM dbo.V_BOOKING_ROOM_BALANCE
                WHERE BookingID = @BookingID AND RoomRemainingAmount > 0)
                THROW 51110, 'Pay all outstanding room charges before check-in.', 1;
            IF EXISTS (SELECT 1 FROM BOOKING WHERE BookingID = @BookingID
                AND NULLIF(LTRIM(RTRIM(GuestCCCDs)), '') IS NULL)
                THROW 51069, 'Verify guest identity documents before check-in.', 1;
            IF EXISTS (SELECT 1 FROM ROOM_ASSIGNMENT a
                JOIN BOOKING_DETAIL d ON d.BookingDetailID = a.BookingDetailID
                JOIN ROOM r ON r.RoomID = a.RoomID
                WHERE d.BookingID = @BookingID AND (r.Status <> 'ACTIVE' OR EXISTS
                    (SELECT 1 FROM ROOM_ASSIGNMENT otherA
                    JOIN BOOKING_DETAIL otherD ON otherD.BookingDetailID = otherA.BookingDetailID
                    JOIN BOOKING otherB ON otherB.BookingID = otherD.BookingID
                    WHERE otherA.RoomID = r.RoomID AND otherB.BookingID <> @BookingID
                        AND otherB.BookingStatus = 'CHECKED_IN')))
                THROW 51070, 'An assigned room is unavailable or still occupied.', 1;
        END;
        UPDATE BOOKING SET BookingStatus = @NewStatus WHERE BookingID = @BookingID;
        IF @NewStatus = 'CHECKED_OUT'
        BEGIN
            EXEC SP_RESET_BOOKING_CONTROL @UserID = @OwnerUserID;
            UPDATE USER_BOOKING_CONTROL SET ConsecutiveCancellationCount = 0, UpdatedAt = SYSDATETIME()
            WHERE UserID = @OwnerUserID;
        END;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_COUNTER_CHECKIN
    @BookingID CHAR(6), @ActorUserID INT, @GuestDocuments VARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC dbo.SP_HBMS_ACQUIRE_WRITE_LOCK;
        IF NOT EXISTS (SELECT 1 FROM EMPLOYEE e JOIN USERS u ON u.UserID = e.UserID
            WHERE e.UserID = @ActorUserID AND e.Position = N'Receptionist' AND u.Role = 'Staff')
            THROW 51193, 'Only receptionists can check in guests.', 1;
        IF NULLIF(LTRIM(RTRIM(@GuestDocuments)), '') IS NULL
            THROW 51194, 'Guest documents are required.', 1;
        IF NOT EXISTS (SELECT 1 FROM BOOKING WHERE BookingID = @BookingID AND BookingStatus = 'ASSIGNED')
            THROW 51195, 'Assign all rooms before check-in.', 1;
        UPDATE BOOKING SET GuestCCCDs = @GuestDocuments WHERE BookingID = @BookingID;
        EXEC dbo.SP_SET_BOOKING_STATUS @BookingID, 'CHECKED_IN', @ActorUserID;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE PROCEDURE SP_ASSIGN_ROOM
    @BookingDetailID INT, @RoomID CHAR(3), @ActorUserID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;
        DECLARE @EmployeeID CHAR(6);
        SELECT @EmployeeID = EmployeeID FROM EMPLOYEE
        WHERE UserID = @ActorUserID AND Position = N'Receptionist';
        IF @EmployeeID IS NULL THROW 51066, 'Only receptionists can assign rooms.', 1;
        IF NOT EXISTS (SELECT 1 FROM BOOKING_DETAIL AS d JOIN BOOKING AS b ON b.BookingID = d.BookingID
            WHERE d.BookingDetailID = @BookingDetailID AND b.BookingStatus IN ('CONFIRMED', 'ASSIGNED'))
            THROW 51067, 'Booking must be confirmed and not checked in to assign rooms.', 1;
        INSERT ROOM_ASSIGNMENT(BookingDetailID, RoomID, EmployeeID)
        VALUES (@BookingDetailID, @RoomID, @EmployeeID);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE ROLE HBMS_APP_ROLE AUTHORIZATION dbo;
GO

DENY INSERT, UPDATE, DELETE ON BOOKING TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON BOOKING_DETAIL TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON BOOKING_SERVICE TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON ROOM_ASSIGNMENT TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON PAYMENT TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON dbo.[TRANSACTION] TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON INVOICE_TRANSACTION TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON CUSTOMER_WALLET TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON WALLET_TRANSACTION TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON BOOKING_REFUND TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON REFUND_PAYMENT TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON USER_BOOKING_CONTROL TO HBMS_APP_ROLE;
DENY INSERT, UPDATE, DELETE ON BOOKING_LOCK_HISTORY TO HBMS_APP_ROLE;
GRANT EXECUTE ON SP_CREATE_BOOKING TO HBMS_APP_ROLE;
GRANT EXECUTE ON SP_RECORD_PAYMENT TO HBMS_APP_ROLE;
GRANT EXECUTE ON SP_CANCEL_BOOKING TO HBMS_APP_ROLE;
GRANT EXECUTE ON SP_EXPIRE_PENDING_BOOKINGS TO HBMS_APP_ROLE;
GRANT EXECUTE ON SP_ADD_BOOKING_SERVICE TO HBMS_APP_ROLE;
GRANT EXECUTE ON SP_SET_BOOKING_STATUS TO HBMS_APP_ROLE;
GRANT EXECUTE ON SP_ASSIGN_ROOM TO HBMS_APP_ROLE;
GRANT EXECUTE ON SP_GET_ROOM_TYPE_AVAILABILITY TO HBMS_APP_ROLE;
GRANT EXECUTE, REFERENCES ON TYPE::BOOKING_ROOM_INPUT TO HBMS_APP_ROLE;
GRANT SELECT ON SCHEMA::dbo TO HBMS_APP_ROLE;
GO

IF EXISTS (
    SELECT 1
    FROM BOOKING AS b
    CROSS APPLY (
        SELECT
            COALESCE((
                SELECT SUM(bd.Subtotal)
                FROM BOOKING_DETAIL AS bd
                WHERE bd.BookingID = b.BookingID
            ), 0)
            +
            COALESCE((
                SELECT SUM(bs.Subtotal)
                FROM BOOKING_SERVICE AS bs
                WHERE bs.BookingID = b.BookingID
            ), 0) AS ExpectedTotal
    ) AS totals
    WHERE b.TotalAmount <> totals.ExpectedTotal
)
BEGIN
    RAISERROR (
        'Seed booking totals are inconsistent.',
        16,
        1
    );
    RETURN;
END;
GO

IF EXISTS (
    SELECT 1
    FROM INVOICE AS i
    INNER JOIN BOOKING AS b
        ON b.BookingID = i.BookingID
    WHERE i.Status = N'Có hiệu lực'
      AND i.TotalAmount <> b.TotalAmount
)
BEGIN
    RAISERROR (
        'Seed invoice totals are inconsistent.',
        16,
        1
    );
    RETURN;
END;
GO

IF (SELECT COUNT(*) FROM BOOKING) <> 40
   OR EXISTS (
       SELECT 1
       FROM BOOKING AS b
       WHERE NOT EXISTS (
           SELECT 1 FROM BOOKING_DETAIL AS bd
           WHERE bd.BookingID = b.BookingID
       )
   )
BEGIN
    RAISERROR ('Expected 40 bookings, each with a room detail.', 16, 1);
    RETURN;
END;
GO

IF EXISTS (
    SELECT 1 FROM V_BOOKING_PAYMENT_SUMMARY
    WHERE BookingStatus IN ('CONFIRMED', 'ASSIGNED', 'CHECKED_IN', 'CHECKED_OUT')
      AND (FirstPaidAt IS NULL OR TotalPaidAmount < InitialRequiredAmount OR TotalPaidAmount > TotalAmount)
) THROW 51100, 'Seed confirmed bookings must have at least their required initial payment.', 1;
GO

IF EXISTS (
    SELECT 1 FROM V_BOOKING_PAYMENT_SUMMARY
    WHERE BookingStatus = 'CHECKED_OUT' AND RemainingAmount <> 0
) THROW 51101, 'Seed checked-out bookings must be fully paid.', 1;
GO

IF EXISTS (
    SELECT 1 FROM PAYMENT AS p JOIN BOOKING AS b ON b.BookingID = p.BookingID
    WHERE p.Status IN ('PAID', 'REFUNDED') AND (
        (p.PaymentType = 'DEPOSIT' AND (b.PaymentOption <> 'DEPOSIT'
            OR p.Amount <> ROUND(b.BookingAmountAtFirstPayment * 0.30, 2)))
        OR (p.PaymentType = 'FULL' AND (b.PaymentOption <> 'FULL'
            OR p.Amount <> b.BookingAmountAtFirstPayment))
    )
) THROW 51102, 'Seed initial payment types or amounts are inconsistent.', 1;
GO

IF EXISTS (
    SELECT 1 FROM BOOKING AS b OUTER APPLY (
        SELECT MIN(PaymentTime) AS FirstPaidAt FROM PAYMENT
        WHERE BookingID = b.BookingID AND Status IN ('PAID', 'REFUNDED')
    ) AS p
    WHERE (b.FirstPaidAt IS NULL AND p.FirstPaidAt IS NOT NULL)
       OR (b.FirstPaidAt IS NOT NULL AND p.FirstPaidAt IS NULL)
       OR b.FirstPaidAt <> p.FirstPaidAt
) THROW 51103, 'Seed first-payment timestamp is inconsistent.', 1;
GO

IF EXISTS (
    SELECT 1 FROM BOOKING_REFUND AS r JOIN BOOKING AS b ON b.BookingID = r.BookingID
    WHERE b.BookingStatus <> 'CANCELLED' OR b.FirstPaidAt IS NULL
       OR b.CancelledAt < b.FirstPaidAt OR b.CancelledAt >= b.RefundDeadline
       OR r.RefundedAt <> b.CancelledAt
       OR r.Amount <> (SELECT COALESCE(SUM(Amount), 0) FROM REFUND_PAYMENT WHERE RefundID = r.RefundID)
       OR r.Amount <> (SELECT COALESCE(SUM(Amount), 0) FROM PAYMENT
           WHERE BookingID = b.BookingID AND Status IN ('PAID', 'REFUNDED'))
       OR NOT EXISTS (SELECT 1 FROM WALLET_TRANSACTION AS t WHERE t.RefundID = r.RefundID
           AND t.WalletID = r.WalletID AND t.Amount = r.Amount AND t.TransactionType = 'REFUND_CREDIT')
) THROW 51104, 'Seed refunds must equal all captured payments and credit the correct wallet within 24h.', 1;
GO

IF EXISTS (
    SELECT 1 FROM REFUND_PAYMENT AS r JOIN PAYMENT AS p ON p.PaymentID = r.PaymentID
    WHERE p.Status <> 'REFUNDED' OR p.Amount <> r.Amount
) OR EXISTS (
    SELECT 1 FROM PAYMENT AS p WHERE p.Status = 'REFUNDED'
    AND NOT EXISTS (SELECT 1 FROM REFUND_PAYMENT AS r WHERE r.PaymentID = p.PaymentID)
) THROW 51105, 'Seed refunded payments require matching refund details.', 1;
GO

IF EXISTS (SELECT 1 FROM V_WALLET_BALANCE WHERE Balance < 0)
    THROW 51106, 'Internal wallet cannot have a negative balance.', 1;
IF (SELECT COUNT(*) FROM CUSTOMER_WALLET) <> (SELECT COUNT(*) FROM CUSTOMER)
    THROW 51107, 'Every customer must have exactly one internal wallet.', 1;
IF (SELECT COUNT(*) FROM USER_BOOKING_CONTROL) <> (SELECT COUNT(*) FROM CUSTOMER)
    THROW 51108, 'Every customer account must have booking-control state.', 1;
GO

PRINT N'QLKS created: 40 bookings, deposit/full payment, 24h wallet refunds and anti-spam booking locks.';
GO

USE QLKS;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.SP_CHECKOUT_WITH_INVOICE
    @BookingID CHAR(6), @ActorUserID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @@TRANCOUNT <> 0 THROW 51109, 'Call checkout without an outer transaction.', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC dbo.SP_HBMS_ACQUIRE_WRITE_LOCK;
        IF NOT EXISTS (SELECT 1 FROM dbo.USERS WHERE UserID = @ActorUserID AND Role IN ('Staff', 'Admin'))
            THROW 51100, 'Only staff/admin can issue invoices.', 1;
        DECLARE @EmployeeID CHAR(6);
        SELECT @EmployeeID = EmployeeID FROM dbo.EMPLOYEE WHERE UserID = @ActorUserID;
        IF @EmployeeID IS NULL THROW 51101, 'The account is not linked to an employee profile.', 1;
        DECLARE @Status VARCHAR(30), @Total DECIMAL(12,2), @FirstPaidAt DATETIME2(3), @Paid DECIMAL(38,2);
        SELECT @Status = BookingStatus, @Total = TotalAmount, @FirstPaidAt = FirstPaidAt
        FROM dbo.BOOKING WITH (UPDLOCK, HOLDLOCK) WHERE BookingID = @BookingID;
        IF @Status IS NULL THROW 51102, 'Booking not found.', 1;
        IF @Status NOT IN ('CHECKED_IN', 'CHECKED_OUT') THROW 51103, 'Only checked-in/out bookings can issue an invoice.', 1;
        SELECT @Paid = COALESCE(SUM(Amount), 0) FROM dbo.PAYMENT WHERE BookingID = @BookingID AND Status = 'PAID';
        IF @FirstPaidAt IS NULL OR @Paid <= 0 THROW 51105, 'The booking has no successful payment.', 1;
        IF @Paid < @Total THROW 51104, 'Complete the remaining payment before checkout.', 1;
        DECLARE @InvoiceID CHAR(6), @InvoiceTotal DECIMAL(12,2), @Created BIT = 0;
        SELECT @InvoiceID = InvoiceID, @InvoiceTotal = TotalAmount
        FROM dbo.INVOICE WITH (UPDLOCK, HOLDLOCK) WHERE BookingID = @BookingID AND Status = N'Có hiệu lực';
        IF @InvoiceID IS NOT NULL AND @InvoiceTotal <> @Total
            THROW 51106, 'The active invoice total does not match the booking total.', 1;
        IF @InvoiceID IS NULL
        BEGIN
            DECLARE @NextNumber INT;
            SELECT @NextNumber = COALESCE(MAX(TRY_CONVERT(INT, SUBSTRING(RTRIM(InvoiceID), 3, 4))), 0) + 1
            FROM dbo.INVOICE WITH (UPDLOCK, HOLDLOCK) WHERE RTRIM(InvoiceID) LIKE 'HD[0-9][0-9][0-9][0-9]';
            IF @NextNumber > 9999 THROW 51107, 'The invoice ID range is exhausted.', 1;
            SET @InvoiceID = 'HD' + RIGHT('0000' + CONVERT(VARCHAR(4), @NextNumber), 4);
            INSERT dbo.INVOICE (InvoiceID, InvoiceDate, TotalAmount, Status, EmployeeID, BookingID)
            VALUES (@InvoiceID, CAST(SYSDATETIME() AS DATE), @Total, N'Có hiệu lực', @EmployeeID, @BookingID);
            SET @Created = 1;
        END;
        INSERT INVOICE_TRANSACTION(InvoiceID, BookingID, PaymentID, TransactionID)
        SELECT @InvoiceID, @BookingID, p.PaymentID, p.TransactionID
        FROM PAYMENT AS p
        WHERE p.BookingID = @BookingID AND p.Status = 'PAID'
          AND NOT EXISTS (SELECT 1 FROM INVOICE_TRANSACTION AS link
              WHERE link.InvoiceID = @InvoiceID AND link.TransactionID = p.TransactionID);
        IF @Status = 'CHECKED_IN'
            EXEC dbo.SP_SET_BOOKING_STATUS @BookingID = @BookingID, @NewStatus = 'CHECKED_OUT', @ActorUserID = @ActorUserID;
        COMMIT TRANSACTION;
        SELECT @InvoiceID AS InvoiceID, @BookingID AS BookingID, @Total AS TotalAmount, @Created AS InvoiceCreated;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

DENY INSERT, UPDATE, DELETE ON dbo.INVOICE TO HBMS_APP_ROLE;
GRANT EXECUTE ON dbo.SP_CHECKOUT_WITH_INVOICE TO HBMS_APP_ROLE;
GO

SET XACT_ABORT ON;
GO

BEGIN TRY
    BEGIN TRANSACTION;
    EXEC dbo.SP_HBMS_ACQUIRE_WRITE_LOCK;
    IF COL_LENGTH('dbo.PAYMENT', 'WalletAmount') IS NULL
    BEGIN
        ALTER TABLE dbo.PAYMENT ADD WalletAmount DECIMAL(12,2) NOT NULL
            CONSTRAINT DF_PAYMENT_WalletAmount DEFAULT (0) WITH VALUES;

        EXEC(N'UPDATE p SET WalletAmount = t.Amount
            FROM dbo.PAYMENT p JOIN dbo.WALLET_TRANSACTION t ON t.PaymentID = p.PaymentID
            WHERE t.TransactionType = ''PAYMENT_DEBIT'';');
    END;
    IF COL_LENGTH('dbo.PAYMENT', 'ExternalAmount') IS NULL
        EXEC(N'ALTER TABLE dbo.PAYMENT ADD ExternalAmount AS
            CAST(Amount - WalletAmount AS DECIMAL(12,2)) PERSISTED;');
    IF OBJECT_ID('dbo.CK_PAYMENT_WalletAmount', 'C') IS NULL
        EXEC(N'ALTER TABLE dbo.PAYMENT WITH CHECK ADD CONSTRAINT CK_PAYMENT_WalletAmount
            CHECK (WalletAmount >= 0 AND WalletAmount <= Amount);');
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

ALTER PROCEDURE dbo.SP_RECORD_PAYMENT
    @PaymentID CHAR(6), @BookingID CHAR(6), @ActorUserID INT,
    @PaymentType VARCHAR(10), @Amount DECIMAL(12,2), @MethodID CHAR(4),
    @TransactionCode VARCHAR(100) = NULL, @WalletAmount DECIMAL(12,2) = 0,
    @TransactionID VARCHAR(100) = NULL, @WalletAuthorizedBy INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;
        DECLARE @Now DATETIME2(3) = SYSDATETIME(), @CustomerID CHAR(6), @OwnerUserID INT,
            @Status VARCHAR(30), @Option VARCHAR(10), @FirstPaidAt DATETIME2(3),
            @Total DECIMAL(12,2), @Paid DECIMAL(12,2), @Required DECIMAL(12,2),
            @Deadline DATETIME, @WalletID BIGINT, @Balance DECIMAL(12,2);
        SELECT @CustomerID = b.CustomerID, @OwnerUserID = c.UserID, @Status = b.BookingStatus,
            @Option = b.PaymentOption, @FirstPaidAt = b.FirstPaidAt, @Total = b.TotalAmount,
            @Deadline = b.PaymentDeadline
        FROM BOOKING AS b WITH (UPDLOCK, HOLDLOCK)
        JOIN CUSTOMER AS c ON c.CustomerID = b.CustomerID WHERE b.BookingID = @BookingID;
        IF @CustomerID IS NULL THROW 51030, 'Booking not found.', 1;
        IF @ActorUserID IS NULL OR (@ActorUserID <> @OwnerUserID AND NOT EXISTS (
            SELECT 1 FROM USERS WHERE UserID = @ActorUserID AND Role IN ('Admin', 'Staff')))
            THROW 51031, 'Not authorized to pay for this booking.', 1;
        IF @Amount IS NULL OR @Amount <= 0 THROW 51032, 'Payment amount must be positive.', 1;
        IF @PaymentType IS NULL OR @PaymentType NOT IN ('DEPOSIT', 'FULL', 'BALANCE')
            THROW 51033, 'Invalid payment type.', 1;
        IF NOT EXISTS (SELECT 1 FROM PAYMENTMETHOD WHERE MethodID = @MethodID)
            THROW 51034, 'Payment method not found.', 1;
        SET @TransactionCode = NULLIF(LTRIM(RTRIM(@TransactionCode)), '');
        SET @TransactionID = NULLIF(LTRIM(RTRIM(@TransactionID)), '');
        IF @WalletAmount IS NULL OR @WalletAmount < 0 OR @WalletAmount > @Amount
            THROW 51047, 'Invalid wallet contribution.', 1;
        IF @MethodID = 'PT02'
        BEGIN
            SET @WalletAmount = @Amount;
            SET @TransactionCode = CONCAT('WALLET-', RTRIM(@PaymentID));
        END
        ELSE IF @WalletAmount >= @Amount OR (@WalletAmount > 0 AND @MethodID <> 'PT01')
            THROW 51047, 'Choose Internal wallet for a wallet-only payment, or VietQR for the shortfall.', 1;
        IF @WalletAmount > 0 AND @ActorUserID <> @OwnerUserID
            AND (ISNULL(@WalletAuthorizedBy, -1) <> @OwnerUserID OR NOT EXISTS
                (SELECT 1 FROM EMPLOYEE e JOIN USERS u ON u.UserID = e.UserID
                 WHERE e.UserID = @ActorUserID AND u.Role = 'Staff' AND e.Position = N'Receptionist'))
            THROW 51048, 'Only the wallet owner can authorize a wallet contribution.', 1;
        IF @MethodID = 'PT03'
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM USERS AS u JOIN EMPLOYEE AS e ON e.UserID = u.UserID
                WHERE u.UserID = @ActorUserID AND u.Role = 'Staff' AND e.Position = N'Receptionist')
                THROW 51035, 'Cash collection must be recorded by a receptionist on behalf of the customer.', 1;
            IF @TransactionCode IS NULL SET @TransactionCode = CONCAT('CASH-', RTRIM(@PaymentID));
        END;
        IF @TransactionID IS NULL AND @MethodID <> 'PT01'
            SET @TransactionID = CONCAT('PAYMENT-', RTRIM(@PaymentID));
        IF @TransactionID IS NULL
            THROW 51210, 'VietQR requires the verified transaction ID from the payment provider.', 1;
        IF @TransactionCode IS NULL OR LEN(LTRIM(RTRIM(@TransactionCode))) = 0
            THROW 51036, 'Successful payment requires a unique transaction code.', 1;

        IF EXISTS (SELECT 1 FROM PAYMENT WHERE PaymentID = @PaymentID AND Status IN ('PAID', 'REFUNDED'))
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM PAYMENT AS p
                JOIN dbo.[TRANSACTION] AS t ON t.TransactionID = p.TransactionID
                WHERE p.PaymentID = @PaymentID AND p.BookingID = @BookingID
                AND p.PaymentType = @PaymentType AND p.Amount = @Amount AND p.WalletAmount = @WalletAmount AND p.MethodID = @MethodID
                AND t.TransactionCode = @TransactionCode AND p.TransactionID = @TransactionID)
                THROW 51037, 'Payment ID already used with different payment data.', 1;
            COMMIT TRANSACTION;
            SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
            RETURN;
        END;
        IF EXISTS (SELECT 1 FROM dbo.[TRANSACTION] WHERE TransactionCode = @TransactionCode)
            THROW 51038, 'Transaction code already recorded in the transaction ledger.', 1;
        IF @TransactionID IS NOT NULL AND EXISTS (
            SELECT 1 FROM dbo.[TRANSACTION] WHERE TransactionID = @TransactionID)
            THROW 51049, 'Transaction ID already recorded in the transaction ledger.', 1;
        IF @Status IN ('CANCELLED', 'CHECKED_OUT')
            THROW 51039, 'Cannot record a new payment on a cancelled or completed booking.', 1;
        IF @Status = 'PENDING_PAYMENT' AND @Deadline <= @Now
            THROW 51040, 'Payment deadline has expired. Do not collect money for this booking.', 1;
        SELECT @Paid = COALESCE(SUM(Amount), 0) FROM PAYMENT WHERE BookingID = @BookingID AND Status = 'PAID';
        IF @FirstPaidAt IS NULL
        BEGIN
            IF @Status <> 'PENDING_PAYMENT' OR @Paid <> 0
                THROW 51041, 'Booking has an inconsistent initial payment state.', 1;
            IF (@Option = 'DEPOSIT' AND @PaymentType <> 'DEPOSIT')
                OR (@Option = 'FULL' AND @PaymentType <> 'FULL')
                THROW 51042, 'Payment type must match the selected booking option.', 1;
            SET @Required = CASE WHEN @Option = 'DEPOSIT' THEN ROUND(@Total * 0.30, 2) ELSE @Total END;
        END
        ELSE
        BEGIN
            IF @PaymentType <> 'BALANCE' THROW 51043, 'Initial payment already made; use BALANCE.', 1;
            IF @Status IN ('CONFIRMED', 'ASSIGNED')
                SELECT @Required = RoomRemainingAmount FROM dbo.V_BOOKING_ROOM_BALANCE WHERE BookingID = @BookingID;
            ELSE
                SET @Required = @Total - @Paid;
        END;
        IF @Required <= 0 OR @Amount <> @Required
            THROW 51044, 'Pay exactly the amount currently due for this payment stage.', 1;
        IF EXISTS (SELECT 1 FROM PAYMENT WHERE PaymentID = @PaymentID AND (
            BookingID <> @BookingID OR PaymentType <> @PaymentType OR Amount <> @Amount))
            THROW 51045, 'Payment attempt does not match this booking and amount.', 1;
        IF @WalletAmount > 0
        BEGIN
            SELECT @WalletID = WalletID, @Balance = Balance FROM V_WALLET_BALANCE WHERE CustomerID = @CustomerID;
            IF @WalletID IS NULL OR @Balance < @WalletAmount
                THROW 51046, 'Insufficient internal wallet balance.', 1;
        END;
        INSERT dbo.[TRANSACTION](TransactionID, TransactionCode, TransactionType, TransactionValue)
        VALUES (@TransactionID, @TransactionCode, 'PAYMENT', @Amount);
        IF EXISTS (SELECT 1 FROM PAYMENT WHERE PaymentID = @PaymentID)
            UPDATE PAYMENT SET Status = 'PAID', PaymentTime = @Now,
                MethodID = @MethodID, WalletAmount = @WalletAmount, TransactionID = @TransactionID WHERE PaymentID = @PaymentID;
        ELSE
            INSERT PAYMENT(PaymentID, BookingID, PaymentType, PaymentTime, Amount, Status, MethodID, WalletAmount, TransactionID)
            VALUES (@PaymentID, @BookingID, @PaymentType, @Now, @Amount, 'PAID', @MethodID, @WalletAmount, @TransactionID);
        IF @WalletAmount > 0
            INSERT WALLET_TRANSACTION(WalletID, TransactionType, Amount, TransactionTime, PaymentID, TransactionID)
            VALUES (@WalletID, 'PAYMENT_DEBIT', @WalletAmount, @Now, @PaymentID, @TransactionID);
        INSERT INVOICE_TRANSACTION(InvoiceID, BookingID, PaymentID, TransactionID)
        SELECT i.InvoiceID, @BookingID, @PaymentID, @TransactionID
        FROM INVOICE AS i
        WHERE i.BookingID = @BookingID AND i.Status = N'Có hiệu lực'
          AND NOT EXISTS (SELECT 1 FROM INVOICE_TRANSACTION AS link
              WHERE link.InvoiceID = i.InvoiceID AND link.TransactionID = @TransactionID);
        IF @FirstPaidAt IS NULL
            UPDATE BOOKING SET FirstPaidAt = @Now, BookingAmountAtFirstPayment = @Total,
                BookingStatus = 'CONFIRMED', PaymentDeadline = NULL WHERE BookingID = @BookingID;
        UPDATE PAYMENT SET CollectedByUserID = @ActorUserID,
            WalletAuthorizedByUserID = CASE WHEN @WalletAmount > 0 THEN @OwnerUserID ELSE NULL END
        WHERE PaymentID = @PaymentID;
        COMMIT TRANSACTION;
        SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_CHECKIN_WITH_ROOM_PAYMENT
    @BookingID CHAR(6), @ActorUserID INT, @GuestDocuments VARCHAR(500),
    @ExpectedRoomAmount DECIMAL(12,2), @MethodID CHAR(4) = NULL,
    @TransactionCode VARCHAR(100) = NULL, @WalletAuthorizedBy INT = NULL,
    @TransactionID VARCHAR(100) = NULL, @WalletAmount DECIMAL(12,2) = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC dbo.SP_HBMS_ACQUIRE_WRITE_LOCK;
        IF NOT EXISTS (SELECT 1 FROM dbo.USERS WHERE UserID = @ActorUserID AND Role IN ('Admin', 'Staff'))
            THROW 51060, 'Only staff/admin can check in guests.', 1;
        DECLARE @Status VARCHAR(30), @FirstPaidAt DATETIME2(3), @RoomDue DECIMAL(12,2),
            @PaymentID CHAR(6), @NextPayment INT, @AssignedRooms INT;
        SELECT @Status = BookingStatus, @FirstPaidAt = FirstPaidAt
        FROM dbo.BOOKING WITH (UPDLOCK, HOLDLOCK) WHERE BookingID = @BookingID;
        SELECT @RoomDue = RoomRemainingAmount FROM dbo.V_BOOKING_ROOM_BALANCE WHERE BookingID = @BookingID;
        IF @Status = 'CHECKED_IN'
        BEGIN
            IF @RoomDue > 0 THROW 51110, 'This existing stay still has unpaid room charges.', 1;
            COMMIT TRANSACTION;
            SELECT * FROM dbo.V_BOOKING_ROOM_BALANCE WHERE BookingID = @BookingID;
            RETURN;
        END;
        IF @Status IS NULL OR @Status <> 'ASSIGNED'
            THROW 51115, 'Assign all rooms before check-in; cancelled/completed bookings are not eligible.', 1;
        IF @FirstPaidAt IS NULL
            THROW 51116, 'A successful initial booking payment is required.', 1;
        IF @ExpectedRoomAmount IS NULL OR @ExpectedRoomAmount < 0 OR @RoomDue IS NULL OR @ExpectedRoomAmount <> @RoomDue
            THROW 51111, 'Room balance changed. Reload the check-in form before collecting payment.', 1;
        SELECT @AssignedRooms = COUNT(*) FROM dbo.ROOM_ASSIGNMENT a
        JOIN dbo.BOOKING_DETAIL d ON d.BookingDetailID = a.BookingDetailID WHERE d.BookingID = @BookingID;
        IF NULLIF(LTRIM(RTRIM(@GuestDocuments)), '') IS NULL
            OR (SELECT COUNT(*) FROM STRING_SPLIT(@GuestDocuments, ',')) < @AssignedRooms
            OR EXISTS (SELECT 1 FROM STRING_SPLIT(@GuestDocuments, ',')
                WHERE LEN(LTRIM(RTRIM(value))) <> 12 OR LTRIM(RTRIM(value)) LIKE '%[^0-9]%')
            THROW 51114, 'Valid 12-digit guest identity documents are required for every assigned room.', 1;
        IF @RoomDue > 0
        BEGIN
            IF @MethodID IS NULL OR @MethodID NOT IN ('PT01', 'PT02', 'PT03')
                OR NOT EXISTS (SELECT 1 FROM dbo.PAYMENTMETHOD WHERE MethodID = @MethodID)
                THROW 51112, 'Select an available booking payment method.', 1;
            SELECT @NextPayment = COALESCE(MAX(TRY_CONVERT(INT, SUBSTRING(PaymentID, 3, 4))), 0) + 1
            FROM dbo.PAYMENT WHERE PaymentID LIKE 'PM[0-9][0-9][0-9][0-9]';
            IF @NextPayment > 9999 THROW 51113, 'Payment ID limit reached.', 1;
            SET @PaymentID = 'PM' + RIGHT('0000' + CONVERT(VARCHAR(4), @NextPayment), 4);
            EXEC dbo.SP_RECORD_PAYMENT @PaymentID = @PaymentID, @BookingID = @BookingID,
                @ActorUserID = @ActorUserID, @PaymentType = 'BALANCE', @Amount = @RoomDue,
                @MethodID = @MethodID, @TransactionCode = @TransactionCode, @WalletAmount = @WalletAmount,
                @WalletAuthorizedBy = @WalletAuthorizedBy, @TransactionID = @TransactionID;
        END;
        UPDATE dbo.BOOKING SET GuestCCCDs = @GuestDocuments WHERE BookingID = @BookingID;
        EXEC dbo.SP_SET_BOOKING_STATUS @BookingID = @BookingID, @NewStatus = 'CHECKED_IN', @ActorUserID = @ActorUserID;
        COMMIT TRANSACTION;
        SELECT * FROM dbo.V_BOOKING_ROOM_BALANCE WHERE BookingID = @BookingID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

GRANT EXECUTE ON dbo.SP_COUNTER_CHECKIN TO HBMS_APP_ROLE;
GRANT EXECUTE ON dbo.SP_HBMS_ACQUIRE_WRITE_LOCK TO HBMS_APP_ROLE;
GRANT SELECT ON dbo.V_BOOKING_ROOM_BALANCE TO HBMS_APP_ROLE;
GRANT EXECUTE ON dbo.SP_CHECKIN_WITH_ROOM_PAYMENT TO HBMS_APP_ROLE;
GO

IF DATABASE_PRINCIPAL_ID('HBMS_APP_ROLE') IS NOT NULL
    GRANT EXECUTE ON dbo.SP_RECORD_PAYMENT TO HBMS_APP_ROLE;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRANSACTION;
    EXEC dbo.SP_HBMS_ACQUIRE_WRITE_LOCK;
    EXEC(N'CREATE OR ALTER FUNCTION dbo.FN_HBMS_VIETNAM_NOW()
RETURNS DATETIME2(3)
AS
BEGIN
    RETURN DATEADD(MINUTE, 420, SYSUTCDATETIME());
END;');
    EXEC(N'CREATE OR ALTER FUNCTION dbo.FN_HBMS_MIN_CHECKIN_DATE(@Now DATETIME2(3))
RETURNS DATE
AS
BEGIN
    RETURN CASE WHEN CAST(@Now AS TIME) < CAST(''10:00:00'' AS TIME)
        THEN CAST(@Now AS DATE) ELSE DATEADD(DAY, 1, CAST(@Now AS DATE)) END;
END;');
    EXEC(N'CREATE OR ALTER FUNCTION dbo.FN_HBMS_REFUND_ELIGIBLE(
    @BookedAt DATETIME2(3), @CheckInDate DATE, @CancelledAt DATETIME2(3))
RETURNS BIT
AS
BEGIN
    RETURN CASE WHEN @BookedAt IS NOT NULL AND @CheckInDate IS NOT NULL
        AND @CancelledAt IS NOT NULL AND @CancelledAt >= @BookedAt
        AND DATEADD(HOUR, 24, @BookedAt) < DATEADD(HOUR, 14, CAST(@CheckInDate AS DATETIME2(3)))
        AND @CancelledAt < DATEADD(HOUR, 24, @BookedAt)
        THEN 1 ELSE 0 END;
END;');
    EXEC(N'IF COL_LENGTH(''dbo.BOOKING'', ''CheckInAt'') IS NULL
    ALTER TABLE dbo.BOOKING ADD CheckInAt AS
        DATEADD(HOUR, 14, CAST(CheckInDate AS DATETIME2(3))) PERSISTED;
IF COL_LENGTH(''dbo.BOOKING'', ''NoShowDeadline'') IS NULL
    ALTER TABLE dbo.BOOKING ADD NoShowDeadline AS
        DATEADD(MINUTE, 855, CAST(CheckInDate AS DATETIME2(3))) PERSISTED;
IF COL_LENGTH(''dbo.BOOKING'', ''RefundDeadline'') IS NOT NULL
    ALTER TABLE dbo.BOOKING DROP COLUMN RefundDeadline;
ALTER TABLE dbo.BOOKING ADD RefundDeadline AS (
    CASE WHEN DATEADD(HOUR, 24, CAST(BookingDate AS DATETIME2(3)))
        < DATEADD(HOUR, 14, CAST(CheckInDate AS DATETIME2(3)))
    THEN DATEADD(HOUR, 24, CAST(BookingDate AS DATETIME2(3))) END
) PERSISTED;
IF OBJECT_ID(''dbo.CK_BOOKING_CancellationReason'', ''C'') IS NOT NULL
    ALTER TABLE dbo.BOOKING DROP CONSTRAINT CK_BOOKING_CancellationReason;
ALTER TABLE dbo.BOOKING WITH CHECK ADD CONSTRAINT CK_BOOKING_CancellationReason CHECK (
    CancellationReason IS NULL OR CancellationReason IN
    (''CUSTOMER_REQUEST'', ''STAFF_REQUEST'', ''PAYMENT_TIMEOUT'', ''NO_SHOW'')
);');
    EXEC(N'ALTER VIEW dbo.V_BOOKING_PAYMENT_SUMMARY AS
SELECT b.BookingID, b.CustomerID, b.BookingStatus, b.PaymentOption, b.TotalAmount,
    b.BookingAmountAtFirstPayment, b.FirstPaidAt, b.RefundDeadline,
    b.CancelledAt, b.CancellationReason, b.BookingDate, b.CheckInAt, b.NoShowDeadline,
    CAST(CASE WHEN b.BookingStatus IN (''CONFIRMED'', ''ASSIGNED'')
        AND b.NoShowDeadline <= dbo.FN_HBMS_VIETNAM_NOW() THEN 1 ELSE 0 END AS BIT) AS IsNoShow,
    CAST(CASE WHEN b.BookingStatus IN (''CONFIRMED'', ''ASSIGNED'') AND p.TotalPaidAmount > 0
        AND dbo.FN_HBMS_REFUND_ELIGIBLE(b.BookingDate, b.CheckInDate, dbo.FN_HBMS_VIETNAM_NOW()) = 1
        THEN 1 ELSE 0 END AS BIT) AS CanRefundNow,
    CAST(CASE WHEN b.PaymentOption = ''DEPOSIT''
        THEN ROUND(COALESCE(b.BookingAmountAtFirstPayment, b.TotalAmount) * 0.30, 2)
        ELSE COALESCE(b.BookingAmountAtFirstPayment, b.TotalAmount) END AS DECIMAL(12,2)) AS InitialRequiredAmount,
    p.TotalPaidAmount, COALESCE(r.Amount, 0) AS RefundedAmount,
    p.TotalPaidAmount - COALESCE(r.Amount, 0) AS NetPaidAmount,
    CAST(CASE WHEN b.BookingStatus = ''CANCELLED'' THEN 0
        WHEN b.TotalAmount > p.TotalPaidAmount THEN b.TotalAmount - p.TotalPaidAmount
        ELSE 0 END AS DECIMAL(12,2)) AS RemainingAmount,
    CASE WHEN r.RefundID IS NOT NULL THEN ''REFUNDED''
        WHEN b.BookingStatus = ''CANCELLED'' AND p.TotalPaidAmount > 0 THEN ''NO_REFUND''
        WHEN p.TotalPaidAmount = 0 THEN ''UNPAID''
        WHEN p.TotalPaidAmount >= b.TotalAmount THEN ''FULLY_PAID''
        ELSE ''DEPOSIT_PAID'' END AS PaymentStatus
FROM BOOKING AS b
OUTER APPLY (
    SELECT CAST(COALESCE(SUM(Amount), 0) AS DECIMAL(12,2)) AS TotalPaidAmount
    FROM PAYMENT WHERE BookingID = b.BookingID AND Status IN (''PAID'', ''REFUNDED'')
) AS p LEFT JOIN BOOKING_REFUND AS r ON r.BookingID = b.BookingID;');
    EXEC(N'ALTER PROCEDURE dbo.SP_CREATE_BOOKING
    @BookingID CHAR(6), @CustomerID CHAR(6), @ActorUserID INT,
    @CheckInDate DATE, @CheckOutDate DATE, @PaymentOption VARCHAR(10),
    @Rooms BOOKING_ROOM_INPUT READONLY,
    @PaymentDeadline DATETIME
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @OwnerUserID INT, @BookedAt DATETIME2(3) = dbo.FN_HBMS_VIETNAM_NOW();
    SELECT @OwnerUserID = UserID FROM CUSTOMER WHERE CustomerID = @CustomerID;
    IF @OwnerUserID IS NULL THROW 51010, ''Customer not found.'', 1;
    IF @ActorUserID IS NULL OR (@ActorUserID <> @OwnerUserID AND NOT EXISTS (
        SELECT 1 FROM USERS WHERE UserID = @ActorUserID AND Role IN (''Admin'', ''Staff'')))
        THROW 51011, ''Not authorized to create this booking.'', 1;
    IF @PaymentOption IS NULL OR @PaymentOption NOT IN (''DEPOSIT'', ''FULL'')
        THROW 51012, ''Choose DEPOSIT (30 percent) or FULL.'', 1;
    IF @CheckInDate IS NULL OR @CheckOutDate IS NULL OR @CheckOutDate <= @CheckInDate
        THROW 51013, ''Invalid stay dates.'', 1;
    IF @PaymentDeadline IS NULL OR @PaymentDeadline <= SYSDATETIME()
        THROW 51014, ''Payment deadline must be in the future.'', 1;
    IF NOT EXISTS (SELECT 1 FROM @Rooms) THROW 51015, ''At least one room type is required.'', 1;
    IF @CheckInDate < CAST(@BookedAt AS DATE) OR
        (@CheckInDate < dbo.FN_HBMS_MIN_CHECKIN_DATE(@BookedAt) AND NOT EXISTS
            (SELECT 1 FROM EMPLOYEE e JOIN USERS u ON u.UserID = e.UserID
             WHERE e.UserID = @ActorUserID AND u.Role = ''Staff'' AND e.Position = N''Receptionist''))
        THROW 51022, ''Same-day bookings close at 10:00 Vietnam time. Select tomorrow or later.'', 1;

    IF @@TRANCOUNT <> 0 THROW 51021, ''Call SP_CREATE_BOOKING without an outer transaction.'', 1;

    EXEC SP_EXPIRE_PENDING_BOOKINGS @CustomerID = @CustomerID, @ReturnResult = 0;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;
        EXEC SP_RESET_BOOKING_CONTROL @UserID = @OwnerUserID;
        IF @PaymentDeadline <= SYSDATETIME() THROW 51014, ''Payment deadline must be in the future.'', 1;
        IF EXISTS (SELECT 1 FROM USER_BOOKING_CONTROL WHERE UserID = @OwnerUserID
            AND BookingLockedUntil > SYSDATETIME())
            THROW 51016, ''Booking temporarily locked. Check V_USER_BOOKING_ACCESS for unlock time.'', 1;
        IF EXISTS (SELECT 1 FROM BOOKING WHERE CustomerID = @CustomerID AND BookingStatus = ''PENDING_PAYMENT'')
            THROW 51017, ''Pay the existing booking deposit/full amount or cancel it before creating another.'', 1;
        IF EXISTS (SELECT 1 FROM @Rooms AS i LEFT JOIN ROOM_TYPE AS rt ON rt.RoomTypeID = i.RoomTypeID
            WHERE rt.RoomTypeID IS NULL OR i.GuestCount > i.Quantity * rt.Capacity)
            THROW 51018, ''Invalid room type or guest capacity.'', 1;
        IF EXISTS (
            SELECT 1 FROM @Rooms AS i
            CROSS APPLY (SELECT COUNT(*) AS ActiveRooms FROM ROOM
                WHERE RoomTypeID = i.RoomTypeID AND Status = ''ACTIVE'') AS available
            OUTER APPLY (
                SELECT COALESCE(SUM(d.Quantity), 0) AS ReservedRooms
                FROM BOOKING_DETAIL AS d JOIN BOOKING AS b ON b.BookingID = d.BookingID
                WHERE d.RoomTypeID = i.RoomTypeID
                  AND (b.BookingStatus IN (''CONFIRMED'', ''ASSIGNED'', ''CHECKED_IN'')
                    OR (b.BookingStatus = ''PENDING_PAYMENT'' AND b.PaymentDeadline > SYSDATETIME()))
                  AND b.CheckInDate < @CheckOutDate AND b.CheckOutDate > @CheckInDate
            ) AS reserved
            WHERE i.Quantity > available.ActiveRooms - reserved.ReservedRooms
        ) THROW 51019, ''Not enough available rooms for the requested dates.'', 1;

        SET @BookedAt = dbo.FN_HBMS_VIETNAM_NOW();
        IF @CheckInDate < CAST(@BookedAt AS DATE) OR
        (@CheckInDate < dbo.FN_HBMS_MIN_CHECKIN_DATE(@BookedAt) AND NOT EXISTS
            (SELECT 1 FROM EMPLOYEE e JOIN USERS u ON u.UserID = e.UserID
             WHERE e.UserID = @ActorUserID AND u.Role = ''Staff'' AND e.Position = N''Receptionist''))
            THROW 51022, ''Same-day bookings close at 10:00 Vietnam time. Select tomorrow or later.'', 1;
        INSERT BOOKING(BookingID, BookingDate, PaymentDeadline, CheckInDate, CheckOutDate,
            BookingStatus, CustomerID, PaymentOption, BookedByUserID)
        VALUES (@BookingID, @BookedAt, @PaymentDeadline, @CheckInDate, @CheckOutDate,
            ''PENDING_PAYMENT'', @CustomerID, @PaymentOption, @ActorUserID);
        INSERT BOOKING_DETAIL(BookingID, RoomTypeID, Quantity, GuestCount, UnitPrice, Subtotal)
        SELECT @BookingID, i.RoomTypeID, i.Quantity, i.GuestCount, rt.Price,
            i.Quantity * rt.Price * DATEDIFF(DAY, @CheckInDate, @CheckOutDate)
        FROM @Rooms AS i JOIN ROOM_TYPE AS rt ON rt.RoomTypeID = i.RoomTypeID;
        IF EXISTS (SELECT 1 FROM BOOKING WHERE BookingID = @BookingID AND TotalAmount <= 0)
            THROW 51020, ''Booking amount must be positive.'', 1;
        COMMIT TRANSACTION;
        SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;');
    EXEC(N'ALTER PROCEDURE dbo.SP_CANCEL_BOOKING
    @BookingID CHAR(6),
    @ActorUserID INT = NULL,
    @Reason VARCHAR(30) = ''CUSTOMER_REQUEST'',
    @ReturnResult BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC SP_HBMS_ACQUIRE_WRITE_LOCK;
        DECLARE @Now DATETIME2(3) = SYSDATETIME(), @CustomerID CHAR(6), @OwnerUserID INT,
            @Status VARCHAR(30), @FirstPaidAt DATETIME2(3), @Deadline DATETIME,
            @Paid DECIMAL(12,2), @WalletID BIGINT, @RefundID BIGINT,
            @Streak INT, @Level TINYINT, @Minutes INT, @PreviouslyLockedUntil DATETIME2(3),
            @BookedAt DATETIME2(3), @CheckInDate DATE,
            @PolicyNow DATETIME2(3) = dbo.FN_HBMS_VIETNAM_NOW();
        SELECT @CustomerID = b.CustomerID, @OwnerUserID = c.UserID,
            @Status = b.BookingStatus, @FirstPaidAt = b.FirstPaidAt, @Deadline = b.PaymentDeadline,
            @BookedAt = b.BookingDate, @CheckInDate = b.CheckInDate
        FROM BOOKING AS b WITH (UPDLOCK, HOLDLOCK)
        JOIN CUSTOMER AS c ON c.CustomerID = b.CustomerID WHERE b.BookingID = @BookingID;
        IF @CustomerID IS NULL THROW 51001, ''Booking not found.'', 1;
        IF @Reason IS NULL OR @Reason NOT IN (''CUSTOMER_REQUEST'', ''STAFF_REQUEST'', ''PAYMENT_TIMEOUT'', ''NO_SHOW'')
            THROW 51002, ''Invalid cancellation reason.'', 1;
        IF @Reason = ''CUSTOMER_REQUEST'' AND (@ActorUserID IS NULL OR @ActorUserID <> @OwnerUserID)
            THROW 51003, ''You cannot cancel another customer booking.'', 1;
        IF @Reason IN (''STAFF_REQUEST'', ''NO_SHOW'') AND NOT EXISTS (
            SELECT 1 FROM USERS WHERE UserID = @ActorUserID AND Role IN (''Admin'', ''Staff''))
            THROW 51004, ''Only staff or admin can cancel on behalf of customers.'', 1;
        IF @Reason = ''PAYMENT_TIMEOUT'' AND (@ActorUserID IS NOT NULL OR @FirstPaidAt IS NOT NULL
            OR @Deadline IS NULL OR @Deadline > @Now)
            THROW 51005, ''Payment timeout cancellation is not applicable.'', 1;

        IF @Status = ''CANCELLED''
        BEGIN
            COMMIT TRANSACTION;
            IF @ReturnResult = 1 SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
            RETURN;
        END;
        IF @Reason = ''NO_SHOW'' AND EXISTS (
            SELECT 1 FROM dbo.BOOKING wb
            JOIN dbo.CUSTOMER wc ON wc.CustomerID = wb.CustomerID
            WHERE wb.BookingID = @BookingID
                AND wb.BookedByUserID IS NOT NULL
                AND wb.BookedByUserID <> wc.UserID
                AND CAST(wb.BookingDate AS DATE) = wb.CheckInDate)
            THROW 51009, ''Walk-in guests have already arrived at the counter. Use staff cancellation if needed.'', 1;
        IF @Reason = ''NO_SHOW'' AND (@Status NOT IN (''CONFIRMED'', ''ASSIGNED'')
            OR @PolicyNow < DATEADD(MINUTE, 855, CAST(@CheckInDate AS DATETIME2(3))))
            THROW 51008, ''No-show cancellation is allowed from 14:15, only before check-in.'', 1;
        IF @Status NOT IN (''PENDING_PAYMENT'', ''CONFIRMED'', ''ASSIGNED'')
            THROW 51006, ''Only bookings before check-in can be cancelled.'', 1;

        UPDATE BOOKING SET BookingStatus = ''CANCELLED'', CancelledAt = @Now,
            CancellationReason = @Reason, CancelledByUserID = @ActorUserID
        WHERE BookingID = @BookingID;
        UPDATE PAYMENT SET Status = ''FAILED'' WHERE BookingID = @BookingID AND Status = ''PENDING'';
        UPDATE INVOICE SET Status = N''Mất hiệu lực'' WHERE BookingID = @BookingID AND Status = N''Có hiệu lực'';

        SELECT @Paid = COALESCE(SUM(Amount), 0) FROM PAYMENT
        WHERE BookingID = @BookingID AND Status = ''PAID'';
        IF @Reason <> ''NO_SHOW'' AND @Paid > 0
            AND dbo.FN_HBMS_REFUND_ELIGIBLE(@BookedAt, @CheckInDate, @PolicyNow) = 1
        BEGIN
            SELECT @WalletID = WalletID FROM CUSTOMER_WALLET WHERE CustomerID = @CustomerID;
            IF @WalletID IS NULL THROW 51007, ''Customer wallet not found.'', 1;
            DECLARE @RefundTransactionID VARCHAR(100) = CONCAT(''REFUND-'', RTRIM(@BookingID));
            INSERT dbo.[TRANSACTION](TransactionID, TransactionType, TransactionValue)
            VALUES (@RefundTransactionID, ''REFUND'', @Paid);
            INSERT BOOKING_REFUND(BookingID, CustomerID, WalletID, Amount, RefundedAt, TransactionID)
            VALUES (@BookingID, @CustomerID, @WalletID, @Paid, @Now, @RefundTransactionID);
            SET @RefundID = CONVERT(BIGINT, SCOPE_IDENTITY());
            INSERT REFUND_PAYMENT(RefundID, BookingID, PaymentID, Amount)
            SELECT @RefundID, BookingID, PaymentID, Amount FROM PAYMENT
            WHERE BookingID = @BookingID AND Status = ''PAID'';
            INSERT WALLET_TRANSACTION(WalletID, TransactionType, Amount, TransactionTime, RefundID, TransactionID)
            VALUES (@WalletID, ''REFUND_CREDIT'', @Paid, @Now, @RefundID, @RefundTransactionID);
            UPDATE PAYMENT SET Status = ''REFUNDED'' WHERE BookingID = @BookingID AND Status = ''PAID'';
        END;

        EXEC SP_RESET_BOOKING_CONTROL @UserID = @OwnerUserID;

        SELECT @PreviouslyLockedUntil = BookingLockedUntil FROM USER_BOOKING_CONTROL WHERE UserID = @OwnerUserID;
        UPDATE USER_BOOKING_CONTROL SET WindowStartedAt = COALESCE(WindowStartedAt, @Now),
            ConsecutiveCancellationCount = ConsecutiveCancellationCount
                + CASE WHEN BookingLockedUntil > @Now THEN 0 ELSE 1 END,
            CancellationCountInWindow = CancellationCountInWindow + 1, UpdatedAt = @Now
        WHERE UserID = @OwnerUserID;
        SELECT @Streak = ConsecutiveCancellationCount, @Level = PenaltyLevel
        FROM USER_BOOKING_CONTROL WHERE UserID = @OwnerUserID;
        IF (@PreviouslyLockedUntil IS NULL OR @PreviouslyLockedUntil <= @Now)
            AND @Streak >= CASE WHEN @Level = 0 THEN 3 WHEN @Level = 1 THEN 2 ELSE 1 END
        BEGIN
            SET @Level = CASE WHEN @Level < 3 THEN @Level + 1 ELSE 3 END;
            SET @Minutes = CASE WHEN @Level = 1 THEN 5 WHEN @Level = 2 THEN 15 ELSE 60 END;
            UPDATE USER_BOOKING_CONTROL SET PenaltyLevel = @Level,
                ConsecutiveCancellationCount = 0, BookingLockedUntil = DATEADD(MINUTE, @Minutes, @Now)
            WHERE UserID = @OwnerUserID;
            INSERT BOOKING_LOCK_HISTORY(UserID, TriggerBookingID, PenaltyLevel, LockedAt, LockedUntil, DurationMinutes)
            VALUES (@OwnerUserID, @BookingID, @Level, @Now, DATEADD(MINUTE, @Minutes, @Now), @Minutes);
        END;
        COMMIT TRANSACTION;
        IF @ReturnResult = 1 SELECT * FROM V_BOOKING_PAYMENT_SUMMARY WHERE BookingID = @BookingID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;');
    IF DATABASE_PRINCIPAL_ID('HBMS_APP_ROLE') IS NOT NULL
    BEGIN
        GRANT EXECUTE ON dbo.FN_HBMS_VIETNAM_NOW TO HBMS_APP_ROLE;
        GRANT EXECUTE ON dbo.FN_HBMS_MIN_CHECKIN_DATE TO HBMS_APP_ROLE;
        GRANT EXECUTE ON dbo.FN_HBMS_REFUND_ELIGIBLE TO HBMS_APP_ROLE;
        GRANT EXECUTE ON dbo.SP_CREATE_BOOKING TO HBMS_APP_ROLE;
        GRANT EXECUTE ON dbo.SP_CANCEL_BOOKING TO HBMS_APP_ROLE;
    END;
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

IF (SELECT COUNT(*) FROM PAYMENTMETHOD) <> 3
    OR EXISTS (SELECT 1 FROM PAYMENTMETHOD WHERE MethodID NOT IN ('PT01', 'PT02', 'PT03'))
    THROW 51120, 'Expected only Cash, VietQR and Internal wallet payment methods.', 1;
IF EXISTS (
    SELECT 1 FROM PAYMENT
    WHERE (MethodID = 'PT02' AND WalletAmount <> Amount)
       OR (MethodID = 'PT03' AND WalletAmount <> 0)
       OR (MethodID = 'PT01' AND WalletAmount >= Amount)
)
    THROW 51121, 'Seed payment methods and wallet contributions are inconsistent.', 1;
IF EXISTS (
    SELECT 1 FROM PAYMENT AS p
    OUTER APPLY (
        SELECT COALESCE(SUM(t.Amount), 0) AS DebitedAmount
        FROM WALLET_TRANSACTION AS t
        WHERE t.PaymentID = p.PaymentID AND t.TransactionType = 'PAYMENT_DEBIT'
    ) AS ledger
    WHERE ledger.DebitedAmount <> CASE WHEN p.Status IN ('PAID', 'REFUNDED') THEN p.WalletAmount ELSE 0 END
)
    THROW 51122, 'Seed wallet debits must match successful wallet contributions.', 1;
IF EXISTS (
    SELECT 1 FROM PAYMENT
    WHERE MethodID = 'PT01' AND Status IN ('PAID', 'REFUNDED') AND TransactionID IS NULL
)
    THROW 51123, 'Seed successful VietQR payments require a transaction ID.', 1;
IF EXISTS (SELECT 1 FROM V_WALLET_BALANCE WHERE Balance < 0)
    THROW 51124, 'Internal wallet cannot have a negative balance.', 1;
GO

CREATE VIEW V_INVOICE_TRANSACTION_DETAILS AS
SELECT i.InvoiceID, i.InvoiceDate, i.BookingID, i.Status AS InvoiceStatus,
    i.TotalAmount AS InvoiceAmount, t.id AS TransactionRowID, t.TransactionID,
    t.TransactionType, t.TransactionValue, p.PaymentID, p.PaymentType,
    p.PaymentTime, p.Status AS PaymentStatus, p.MethodID, m.MethodName,
    t.TransactionCode, p.WalletAmount, p.ExternalAmount
FROM INVOICE AS i
JOIN INVOICE_TRANSACTION AS link ON link.InvoiceID = i.InvoiceID AND link.BookingID = i.BookingID
JOIN PAYMENT AS p ON p.PaymentID = link.PaymentID AND p.TransactionID = link.TransactionID
JOIN dbo.[TRANSACTION] AS t ON t.TransactionID = link.TransactionID
JOIN PAYMENTMETHOD AS m ON m.MethodID = p.MethodID;
GO

IF (SELECT COUNT(*) FROM dbo.[TRANSACTION]) <> 39
    THROW 51220, 'Expected 37 successful payment transactions and 2 refund transactions.', 1;
IF EXISTS (
    SELECT 1 FROM PAYMENT AS p
    LEFT JOIN dbo.[TRANSACTION] AS t ON t.TransactionID = p.TransactionID
    WHERE p.Status IN ('PAID', 'REFUNDED')
      AND (t.TransactionID IS NULL OR t.TransactionType <> 'PAYMENT' OR t.TransactionValue <> p.Amount)
)
    THROW 51221, 'Seed successful payments must match their central transactions.', 1;
IF EXISTS (
    SELECT 1 FROM BOOKING_REFUND AS r
    JOIN dbo.[TRANSACTION] AS t ON t.TransactionID = r.TransactionID
    WHERE t.TransactionType <> 'REFUND' OR t.TransactionValue <> r.Amount
)
    THROW 51222, 'Seed refunds must match their central transactions.', 1;
IF EXISTS (
    SELECT 1 FROM dbo.[TRANSACTION] AS t
    WHERE (t.TransactionType = 'PAYMENT' AND NOT EXISTS (
        SELECT 1 FROM PAYMENT AS p WHERE p.TransactionID = t.TransactionID))
       OR (t.TransactionType = 'REFUND' AND NOT EXISTS (
        SELECT 1 FROM BOOKING_REFUND AS r WHERE r.TransactionID = t.TransactionID))
)
    THROW 51223, 'Seed central transactions must reference a payment or refund.', 1;
IF EXISTS (
    SELECT 1 FROM INVOICE AS i JOIN PAYMENT AS p ON p.BookingID = i.BookingID
    WHERE i.Status = N'Có hiệu lực' AND p.Status IN ('PAID', 'REFUNDED')
      AND NOT EXISTS (SELECT 1 FROM INVOICE_TRANSACTION AS link
          WHERE link.InvoiceID = i.InvoiceID AND link.PaymentID = p.PaymentID
            AND link.TransactionID = p.TransactionID)
)
    THROW 51224, 'Seed active invoices must link every captured payment transaction.', 1;
GO

IF COL_LENGTH('dbo.BOOKING', 'GuestCCCDs') IS NULL
    OR COL_LENGTH('dbo.BOOKING', 'BookedByUserID') IS NULL
    OR COL_LENGTH('dbo.PAYMENT', 'CollectedByUserID') IS NULL
    OR COL_LENGTH('dbo.PAYMENT', 'WalletAuthorizedByUserID') IS NULL
    THROW 51230, 'Counter booking and payment audit columns are required.', 1;
IF OBJECT_ID('dbo.FK_COMPLAINT_EMPLOYEE', 'F') IS NULL
    THROW 51231, 'Complaint must reference an employee.', 1;
IF OBJECT_ID('dbo.V_BOOKING_ROOM_BALANCE', 'V') IS NULL
    OR OBJECT_ID('dbo.SP_COUNTER_CHECKIN', 'P') IS NULL
    OR OBJECT_ID('dbo.SP_CHECKIN_WITH_ROOM_PAYMENT', 'P') IS NULL
    THROW 51232, 'Room balance and check-in procedures are required.', 1;
IF NOT EXISTS (SELECT 1 FROM PAYMENTMETHOD WHERE MethodID = 'PT01' AND MethodName = N'VietQR')
    OR NOT EXISTS (SELECT 1 FROM PAYMENTMETHOD WHERE MethodID = 'PT02' AND MethodName = N'Internal wallet')
    OR NOT EXISTS (SELECT 1 FROM PAYMENTMETHOD WHERE MethodID = 'PT03' AND MethodName = N'Cash')
    THROW 51233, 'Payment method IDs must be PT01 VietQR, PT02 Internal wallet, PT03 Cash.', 1;
PRINT N'QLKS merged: central transactions, VietQR/internal wallet/cash, counter bookings, room settlement at check-in and released rooms after checkout.';
GO

CREATE OR ALTER PROCEDURE dbo.SP_CONFIRM_PAYOS_ORDER
    @OrderCode BIGINT, @PaymentLinkId VARCHAR(100), @ExternalAmount DECIMAL(12,2), @Reference VARCHAR(100)
AS
BEGIN
<<<<<<< HEAD:db/DB_v6_merged_transaction.sql
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @BookingID CHAR(6), @UserID INT, @Status VARCHAR(20), @PaymentType VARCHAR(10),
        @Amount DECIMAL(12,2), @WalletAmount DECIMAL(12,2), @ExpectedExternal DECIMAL(12,2),
        @PaymentID CHAR(6), @TransactionID VARCHAR(100) = CONCAT('PAYOS-', @OrderCode),
        @BookingStatus VARCHAR(30), @Deadline DATETIME, @Required DECIMAL(12,2), @CheckInStaffUserID INT,
        @WalletBalance DECIMAL(12,2), @Reason VARCHAR(300), @NextID INT;

    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC dbo.SP_HBMS_ACQUIRE_WRITE_LOCK;
        SELECT @BookingID = o.BookingID, @UserID = o.UserID, @Status = o.Status,
            @PaymentType = o.PaymentType, @Amount = o.Amount, @WalletAmount = o.WalletAmount,
            @ExpectedExternal = o.ExternalAmount, @CheckInStaffUserID = o.CheckInStaffUserID
        FROM dbo.PAYOS_ORDER o WITH (UPDLOCK, HOLDLOCK)
        WHERE o.OrderCode = @OrderCode
          AND o.PaymentLinkId COLLATE Latin1_General_100_BIN2 = @PaymentLinkId;

        -- Ignore test events and orders already paid.
        IF @BookingID IS NULL OR @Status = 'PAID'
        BEGIN
            COMMIT TRANSACTION;
            RETURN;
        END;

        IF @ExpectedExternal <> @ExternalAmount
            SET @Reason = N'Transfer amount does not match the PayOS order.';
        ELSE
        BEGIN
            SELECT @PaymentID = p.PaymentID
            FROM dbo.PAYMENT p
            JOIN dbo.[TRANSACTION] t ON t.TransactionID = p.TransactionID
            WHERE p.TransactionID IN (@TransactionID, @Reference) AND t.TransactionCode = @Reference
              AND p.BookingID = @BookingID AND p.PaymentType = @PaymentType AND p.MethodID = 'PT01'
              AND p.Amount = @Amount AND p.WalletAmount = @WalletAmount AND p.Status IN ('PAID','REFUNDED');

            IF @PaymentID IS NULL
            BEGIN
                SELECT @BookingStatus = b.BookingStatus, @Deadline = b.PaymentDeadline,
                    @Required = CASE WHEN b.FirstPaidAt IS NULL AND b.PaymentOption = @PaymentType
                            AND b.BookingStatus = 'PENDING_PAYMENT' THEN s.InitialRequiredAmount
                        WHEN b.FirstPaidAt IS NOT NULL AND @PaymentType = 'BALANCE'
                            AND b.BookingStatus IN ('CONFIRMED','ASSIGNED')
                            AND (@CheckInStaffUserID IS NULL OR (b.BookingStatus = 'ASSIGNED' AND b.PaymentOption = 'DEPOSIT'))
                            THEN r.RoomRemainingAmount
                        WHEN b.FirstPaidAt IS NOT NULL AND @PaymentType = 'BALANCE'
                            AND b.BookingStatus = 'CHECKED_IN' AND @CheckInStaffUserID IS NULL
                            THEN s.RemainingAmount END,
                    @WalletBalance = w.Balance
                FROM dbo.BOOKING b
                JOIN dbo.CUSTOMER c ON c.CustomerID = b.CustomerID
                JOIN dbo.V_BOOKING_PAYMENT_SUMMARY s ON s.BookingID = b.BookingID
                LEFT JOIN dbo.V_BOOKING_ROOM_BALANCE r ON r.BookingID = b.BookingID
                LEFT JOIN dbo.V_WALLET_BALANCE w ON w.CustomerID = b.CustomerID
                WHERE b.BookingID = @BookingID AND c.UserID = @UserID;

                IF @Required IS NULL OR @Required <> @Amount
                    OR (@BookingStatus = 'PENDING_PAYMENT' AND (@Deadline IS NULL OR @Deadline <= SYSDATETIME()))
                    SET @Reason = N'Booking expired or the amount due changed.';
                ELSE IF @WalletAmount > 0 AND ISNULL(@WalletBalance, 0) < @WalletAmount
                    SET @Reason = N'Wallet balance changed after the PayOS order was created.';
                ELSE IF EXISTS (SELECT 1 FROM dbo.[TRANSACTION] WHERE TransactionCode = @Reference
                    OR TransactionID = @TransactionID)
                    SET @Reason = N'This bank transaction was already recorded elsewhere.';
                ELSE
                BEGIN
                    SELECT @NextID = COALESCE(MAX(TRY_CONVERT(INT, SUBSTRING(PaymentID, 3, 4))), 0) + 1
                    FROM dbo.PAYMENT WHERE PaymentID LIKE 'PM[0-9][0-9][0-9][0-9]';
                    IF @NextID > 9999 THROW 51311, 'Payment ID limit reached.', 1;
                    SET @PaymentID = 'PM' + RIGHT('0000' + CONVERT(VARCHAR(4), @NextID), 4);

                    EXEC dbo.SP_RECORD_PAYMENT @PaymentID = @PaymentID, @BookingID = @BookingID,
                        @ActorUserID = @UserID, @PaymentType = @PaymentType, @Amount = @Amount,
                        @MethodID = 'PT01', @TransactionCode = @Reference, @WalletAmount = @WalletAmount,
                        @WalletAuthorizedBy = @UserID, @TransactionID = @TransactionID;
                    -- This payment was confirmed by PayOS.
                    UPDATE dbo.PAYMENT SET CollectedByUserID = NULL WHERE PaymentID = @PaymentID;
                END;
            END;
        END;

        IF @Reason IS NULL
            UPDATE dbo.PAYOS_ORDER SET Status = 'PAID', PaidAt = SYSDATETIME(),
                Reference = @Reference, PaymentID = @PaymentID, ErrorMessage = NULL WHERE OrderCode = @OrderCode;
        ELSE
            UPDATE dbo.PAYOS_ORDER SET Status = 'FAILED', Reference = @Reference,
                ErrorMessage = @Reason WHERE OrderCode = @OrderCode;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
=======
    ALTER TABLE dbo.BOOKING_SERVICE ADD ServiceStatus VARCHAR(20) DEFAULT 'PENDING';
END
>>>>>>> origin/main:db/DB_v5.sql
GO

IF DATABASE_PRINCIPAL_ID(N'HBMS_APP_ROLE') IS NOT NULL
BEGIN
    GRANT INSERT ON dbo.PAYOS_ORDER TO HBMS_APP_ROLE;
    GRANT EXECUTE ON dbo.SP_CONFIRM_PAYOS_ORDER TO HBMS_APP_ROLE;
END;
GO
-- them cột dể satff dánh công 
USE QLKS;
GO
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'BOOKING_SERVICE' AND COLUMN_NAME = 'ServedByUserID'
)
BEGIN
    ALTER TABLE dbo.BOOKING_SERVICE ADD ServedByUserID INT NULL;
END
GO
