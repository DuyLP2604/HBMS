package dao;

import entity.BookingService;
import entity.Service;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import util.PersistenceManager;

public class ServiceDAO {

    public List<Service> getAllServices() {
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            String jpql = "SELECT s FROM Service s ORDER BY s.serviceID ASC";
            TypedQuery<Service> query = em.createQuery(jpql, Service.class);
            return query.getResultList();
        } finally {
            close(em);
        }
    }

    public List<Service> getActiveServices() {
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            String jpql = "SELECT s FROM Service s WHERE s.serviceStatus = 'ACTIVE' ORDER BY s.serviceID ASC";
            TypedQuery<Service> query = em.createQuery(jpql, Service.class);
            return query.getResultList();
        } finally {
            close(em);
        }
    }

    public Service findByID(String serviceID) {
        if (serviceID == null || serviceID.trim().isEmpty()) {
            return null;
        }
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            return em.find(Service.class, serviceID.trim());
        } finally {
            close(em);
        }
    }

    public List<BookingService> getServicesByBookingId(String bookingID) {
        if (bookingID == null || bookingID.trim().isEmpty()) {
            return Collections.emptyList();
        }
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            String jpql = "SELECT bs FROM BookingService bs WHERE bs.booking.bookingID = :bookingID";
            TypedQuery<BookingService> query = em.createQuery(jpql, BookingService.class);
            query.setParameter("bookingID", bookingID.trim());
            return query.getResultList();
        } catch (Exception e) {
            return Collections.emptyList();
        } finally {
            close(em);
        }
    }

    public List<BookingService> getAllBookServices() {
        return getAllBookedServices();
    }

    public List<BookingService> getAllBookedServices() {
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            String jpql = "SELECT bs FROM BookingService bs "
                    + "JOIN FETCH bs.service "
                    + "JOIN FETCH bs.booking b "
                    + "JOIN FETCH b.customerID "
                    + "WHERE b.bookingStatus <> 'CANCELLED' "
                    + "ORDER BY b.bookingID DESC";
            TypedQuery<BookingService> query = em.createQuery(jpql, BookingService.class);
            return query.getResultList();
        } catch (Exception e) {
            return Collections.emptyList();
        } finally {
            close(em);
        }
    }

    public String generateNextServiceID() {
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            String jpql = "SELECT s.serviceID FROM Service s";
            TypedQuery<String> query = em.createQuery(jpql, String.class);
            List<String> serviceIDs = query.getResultList();
            int max = 0;
            for (String sid : serviceIDs) {
                if (sid != null) {
                    String trimmed = sid.trim();
                    if (trimmed.matches("S\\d+")) {
                        try {
                            int num = Integer.parseInt(trimmed.substring(1));
                            if (num > max) {
                                max = num;
                            }
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
            }
            return String.format("S%02d", max + 1);
        } finally {
            close(em);
        }
    }

    public void createService(String serviceName, double unitPrice) {
        if (serviceName == null || serviceName.trim().isEmpty()) {
            throw new IllegalArgumentException("Tên dịch vụ không được để trống.");
        }
        if (unitPrice < 0) {
            throw new IllegalArgumentException("Đơn giá dịch vụ không được âm.");
        }
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            em.getTransaction().begin();
            String serviceID = generateNextServiceID();
            Service service = new Service();
            service.setServiceID(serviceID);
            service.setServiceName(serviceName.trim());
            service.setUnitPrice(BigDecimal.valueOf(unitPrice));
            em.persist(service);
            em.getTransaction().commit();
            PersistenceManager.getEMF().getCache().evictAll();
        } catch (Exception e) {
            rollback(em);
            throw new IllegalStateException("Không thể tạo dịch vụ mới: " + e.getMessage(), e);
        } finally {
            close(em);
        }
    }

    public void updateService(String serviceID, String serviceName, double unitPrice) {
        if (serviceID == null || serviceName == null || serviceName.trim().isEmpty() || unitPrice < 0) {
            throw new IllegalArgumentException("Thông tin dịch vụ không hợp lệ.");
        }
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            em.getTransaction().begin();
            List<Service> list = em.createQuery("SELECT s FROM Service s WHERE TRIM(s.serviceID) = :sid", Service.class)
                    .setParameter("sid", serviceID.trim())
                    .getResultList();
            if (list.isEmpty()) {
                throw new IllegalArgumentException("Không tìm thấy dịch vụ: " + serviceID);
            }

            Service service = list.get(0);
            service.setServiceName(serviceName.trim());
            service.setUnitPrice(BigDecimal.valueOf(unitPrice));

            em.getTransaction().commit();
            PersistenceManager.getEMF().getCache().evictAll();
        } catch (Exception e) {
            rollback(em);
            throw new IllegalStateException("Lỗi cập nhật: " + e.getMessage(), e);
        } finally {
            close(em);
        }
    }

    public void deleteService(String serviceID) {
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            em.getTransaction().begin();
            Long count = em.createQuery("SELECT COUNT(bs) FROM BookingService bs WHERE TRIM(bs.bookingServicePK.serviceID) = :sid", Long.class)
                    .setParameter("sid", serviceID.trim())
                    .getSingleResult();
            if (count != null && count > 0) {
                throw new IllegalStateException("Dịch vụ này đã có khách đặt trong đơn phòng, không thể xóa để bảo toàn hóa đơn.");
            }
            em.createQuery("DELETE FROM Service s WHERE TRIM(s.serviceID) = :sid")
                    .setParameter("sid", serviceID.trim())
                    .executeUpdate();
            em.getTransaction().commit();
            PersistenceManager.getEMF().getCache().evictAll();
        } catch (Exception e) {
            rollback(em);
            throw new IllegalStateException(e.getMessage(), e);
        } finally {
            close(em);
        }
    }

    public void toggleServiceStatus(String serviceID) {
        if (serviceID == null || serviceID.trim().isEmpty()) {
            throw new IllegalArgumentException("Mã dịch vụ không hợp lệ.");
        }
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            em.getTransaction().begin();
            List<Service> list = em.createQuery("SELECT s FROM Service s WHERE TRIM(s.serviceID) = :sid", Service.class)
                    .setParameter("sid", serviceID.trim())
                    .getResultList();
            if (list.isEmpty()) {
                throw new IllegalArgumentException("Không tìm thấy dịch vụ: " + serviceID);
            }
            Service service = list.get(0);
            if ("ACTIVE".equalsIgnoreCase(service.getServiceStatus())) {
                service.setServiceStatus("SUSPENDED");
            } else {
                service.setServiceStatus("ACTIVE");
            }
            em.getTransaction().commit();
            PersistenceManager.getEMF().getCache().evictAll();
        } catch (Exception e) {
            rollback(em);
            throw new IllegalStateException("Lỗi cập nhật trạng thái: " + e.getMessage(), e);
        } finally {
            close(em);
        }
    }

    public void insertBookingService(String bookingID, String serviceID, int quantity, int actorUserID) {
        String sql = "EXEC dbo.SP_ADD_BOOKING_SERVICE @BookingID=?, @ServiceID=?, @Quantity=?, @ActorUserID=?";
        try (Connection connection = PersistenceManager.openConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookingID);
            statement.setString(2, serviceID);
            statement.setInt(3, quantity);
            statement.setInt(4, actorUserID);
            statement.execute();
        } catch (SQLException exception) {
            throw new IllegalStateException("Không thể thêm dịch vụ: " + exception.getMessage(), exception);
        }
        PersistenceManager.getEMF().getCache().evictAll();
    }

    public boolean updateBookingServiceStatus(String bookingID, String serviceID, int actorUserID, String status) {
        String sql = "EXEC dbo.SP_UPDATE_BOOKING_SERVICE_STATUS @BookingID=?, @ServiceID=?, @ActorUserID=?, @NewStatus=?";
        boolean changed;
        try (Connection connection = PersistenceManager.openConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookingID);
            statement.setString(2, serviceID);
            statement.setInt(3, actorUserID);
            statement.setString(4, status);
            try (ResultSet result = statement.executeQuery()) {
                changed = result.next() && result.getBoolean("Changed");
            }
        } catch (SQLException exception) {
            throw new IllegalStateException("Không thể cập nhật đơn dịch vụ.", exception);
        }
        if (changed) {
            PersistenceManager.getEMF().getCache().evictAll();
        }
        return changed;
    }

    public List<BookingService> getBookedServicesPaged(int offset, int pageSize) {
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            String jpql = "SELECT bs FROM BookingService bs "
                    + "JOIN FETCH bs.service "
                    + "JOIN FETCH bs.booking b "
                    + "JOIN FETCH b.customerID "
                    + "WHERE b.bookingStatus <> 'CANCELLED' "
                    + "ORDER BY b.bookingID DESC, bs.service.serviceID DESC";
            TypedQuery<BookingService> query = em.createQuery(jpql, BookingService.class);
            query.setFirstResult(offset);
            query.setMaxResults(pageSize);
            return query.getResultList();
        } catch (Exception e) {
            return Collections.emptyList();
        } finally {
            close(em);
        }
    }

    public long countBookedServices() {
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            String jpql = "SELECT COUNT(bs) FROM BookingService bs "
                    + "WHERE bs.booking.bookingStatus <> 'CANCELLED'";
            return em.createQuery(jpql, Long.class).getSingleResult();
        } catch (Exception e) {
            return 0L;
        } finally {
            close(em);
        }
    }

    public void cancelBookingService(String bookingID, String serviceID, int actorUserID) {
        if (bookingID == null || serviceID == null) {
            throw new IllegalArgumentException("Thông tin đơn dịch vụ không hợp lệ.");
        }
        EntityManager em = PersistenceManager.createEntityManager();
        try {
            em.getTransaction().begin();
            List<BookingService> list = em.createQuery(
                    "SELECT bs FROM BookingService bs WHERE TRIM(bs.booking.bookingID) = :bid AND TRIM(bs.service.serviceID) = :sid",
                    BookingService.class)
                    .setParameter("bid", bookingID.trim())
                    .setParameter("sid", serviceID.trim())
                    .getResultList();

            if (list.isEmpty()) {
                throw new IllegalArgumentException("Không tìm thấy dịch vụ trong đơn phòng.");
            }

            BookingService bs = list.get(0);
            String status = bs.getServiceStatus();
            if (status != null && !"PENDING".equalsIgnoreCase(status.trim())) {
                throw new IllegalStateException("Dịch vụ đã được tiếp nhận hoặc đã hoàn thành, không thể hủy.");
            }

            em.remove(bs);
            em.getTransaction().commit();
            PersistenceManager.getEMF().getCache().evictAll();
        } catch (Exception e) {
            rollback(em);
            throw new IllegalStateException(e.getMessage(), e);
        } finally {
            close(em);
        }
    }

    private void rollback(EntityManager em) {
        if (em != null && em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }
    }

    private void close(EntityManager em) {
        if (em != null && em.isOpen()) {
            em.close();
        }
    }
}
