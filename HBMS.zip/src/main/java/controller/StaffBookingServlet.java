package controller;

import entity.Booking;
import entity.BookingDetail;
import entity.Room;
import entity.Users;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import service.RoomAssignmentService;
import util.BookingTimePolicy;

/** Shows bookings and booking details to reception staff. */
@WebServlet(
        name = "StaffBookingServlet",
        urlPatterns = {"/staff/bookings"}
)
public class StaffBookingServlet extends HttpServlet {

    private final RoomAssignmentService assignmentService
            = new RoomAssignmentService();

    /** Show bookings for room assignment or available rooms for one booking. */
    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session
                = request.getSession(false);

        if (!hasStaffPermission(session)) {
            response.sendError(
                    HttpServletResponse.SC_FORBIDDEN,
                    "You do not have permission to access this page."
            );

            return;
        }

        synchronized (session) {
            if (session.getAttribute("roomAssignmentCsrf") == null)
                session.setAttribute("roomAssignmentCsrf", UUID.randomUUID().toString());
        }
        moveFlashMessage(request, session);
        synchronized (session)
        {
            if (!(session.getAttribute("bookingCsrfToken") instanceof String))
            {
                session.setAttribute("bookingCsrfToken", UUID.randomUUID().toString());
            }
        }

        String bookingID
                = request.getParameter("bookingID");

        if (bookingID == null
                || bookingID.trim().isEmpty()) {
            
            //Get booking need to assign room
            List<Booking> bookings
                    = assignmentService
                            .getWaitingBookings();

            request.setAttribute(
                    "bookings",
                    bookings
            );
            //MArk no show booking prior
            request.setAttribute("noShowBookings", BookingTimePolicy.prepareStaffList(bookings, BookingTimePolicy.now()));

        request.getRequestDispatcher(
                    "/WEB-INF/views/staff-bookings.jsp"
            ).forward(request, response);

            return;
        }

        Booking booking
                = assignmentService.getBooking(
                        bookingID.trim()
                );

        if (booking == null) {
            response.sendError(
                    HttpServletResponse.SC_NOT_FOUND,
                    "The requested booking was not found."
            );

            return;
        }

        List<BookingDetail> details
                = assignmentService
                        .getBookingDetails(
                                bookingID.trim()
                        );

        // List the actual rooms that can be assigned to each booking detail.
        Map<Integer, List<Room>> availableRoomMap
                = new HashMap<>();

        for (BookingDetail detail : details) {
            List<Room> rooms
                    = assignmentService
                            .getAvailableRooms(
                                    detail.getBookingDetailID()
                            );

            availableRoomMap.put(
                    detail.getBookingDetailID(),
                    rooms
            );
        }

        request.setAttribute("booking", booking);
        request.setAttribute("details", details);

        request.setAttribute(
                "availableRoomMap",
                availableRoomMap
        );

        request.getRequestDispatcher(
                "/WEB-INF/views/staff-booking-detail.jsp"
        ).forward(request, response);
    }

    private boolean hasStaffPermission(
            HttpSession session) {

        if (session == null) {
            return false;
        }

        Users user
                = (Users) session.getAttribute("user");

        if (user == null) {
            return false;
        }

        String role
                = (String) session.getAttribute("role");

        if (role == null) {
            role = user.getRole();
        }

        return "Staff".equalsIgnoreCase(role)
                || "Admin".equalsIgnoreCase(role);
    }

    private void moveFlashMessage(
            HttpServletRequest request,
            HttpSession session) {

        Object success
                = session.getAttribute(
                        "assignmentSuccess"
                );

        Object error
                = session.getAttribute(
                        "assignmentError"
                );

        if (success != null) {
            request.setAttribute(
                    "successMessage",
                    success.toString()
            );

            session.removeAttribute(
                    "assignmentSuccess"
            );
        }

        if (error != null) {
            request.setAttribute(
                    "errorMessage",
                    error.toString()
            );

            session.removeAttribute(
                    "assignmentError"
            );
        }
    }
}
