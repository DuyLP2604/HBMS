package controller;

import dao.DashboardDAO;
import dto.CustomerSource;
import dto.RevenueChart;
import dto.RoomUtilizationReport;
import dto.ServiceUsageReport;
import entity.Users;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

/** Builds the admin dashboard for revenue, customers, room usage, and service usage. */
@WebServlet(name = "DashboardServlet", urlPatterns = {"/dashboard"})
public class DashboardServlet extends HttpServlet {

    private static final LocalDate ALL_TIME_START = LocalDate.of(2010, 1, 1);
    private static final DateTimeFormatter DATE_LABEL_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    /** Load admin dashboard data for the selected date range. */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!hasPermission(request.getSession())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "You do not have permission to access the dashboard.");
            return;
        }

        try {
            LocalDate reportToday = LocalDate.now();
            LocalDate[] dateRange = parseDateRange(request, reportToday);
            LocalDate startDate = dateRange[0];
            LocalDate endDate = dateRange[1];

            DashboardDAO dashboardDAO = new DashboardDAO();

            long revenue = dashboardDAO.getRevenueByDateRange(startDate, endDate);
            int occupiedRooms = dashboardDAO.getOccupiedRoomsCount(startDate, endDate);
            int totalRooms = dashboardDAO.getTotalRoomsCount();
            int totalCustomers = dashboardDAO.getTotalCustomers(startDate, endDate); // Đã fix logic
            List<RevenueChart> revenueChart = dashboardDAO.getRevenueChartData(startDate, endDate); // Đã fix logic
            List<CustomerSource> customerSource = dashboardDAO.getCustomerSource();
            RoomUtilizationReport roomUtilization = dashboardDAO.getRoomUtilization(startDate, endDate);
            ServiceUsageReport serviceUsage = dashboardDAO.getServiceUsageReport(startDate, endDate);

            request.setAttribute("todayRevenue", revenue);
            request.setAttribute("selectedRevenue", revenue);
            request.setAttribute("occupiedRooms", occupiedRooms);
            request.setAttribute("totalRooms", totalRooms);
            request.setAttribute("totalCustomers", totalCustomers);
            request.setAttribute("revenueChart", revenueChart);
            request.setAttribute("customerSource", customerSource);
            request.setAttribute("roomUtilization", roomUtilization);
            request.setAttribute("serviceUsage", serviceUsage);
            boolean allTime = ALL_TIME_START.equals(startDate) && reportToday.equals(endDate);
            request.setAttribute("allTime", allTime);
            request.setAttribute("reportDateRange", allTime ? "All Time"
                    : startDate.format(DATE_LABEL_FORMAT) + " - " + endDate.format(DATE_LABEL_FORMAT));
            request.setAttribute("reportToday", reportToday.toString());
            request.setAttribute("weekStart", reportToday.minusDays(6).toString());
            request.setAttribute("monthStart", reportToday.withDayOfMonth(1).toString());
            request.setAttribute("yearStart", reportToday.withDayOfYear(1).toString());
            request.setAttribute("from", startDate.toString());
            request.setAttribute("to", endDate.toString());
            request.setAttribute("revenueLabel", createRevenueLabel(startDate, endDate));

            response.setHeader("Cache-Control", "no-store");
            request.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(request, response);
        } catch (IllegalArgumentException exception) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, exception.getMessage());
        } catch (ServletException | IOException exception) {
            throw new ServletException("Unable to load dashboard data.", exception);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    /** Read the reporting period from the dashboard request. */
    private LocalDate[] parseDateRange(HttpServletRequest request, LocalDate reportToday) {
        String fromValue = request.getParameter("from");
        String toValue = request.getParameter("to");

        boolean fromEmpty = fromValue == null || fromValue.trim().isEmpty();
        boolean toEmpty = toValue == null || toValue.trim().isEmpty();

        if (fromEmpty && toEmpty) {
            return new LocalDate[]{ALL_TIME_START, reportToday};
        }

        if (fromEmpty || toEmpty) {
            throw new IllegalArgumentException("Both start date and end date are required.");
        }

        try {
            LocalDate startDate = LocalDate.parse(fromValue.trim());
            LocalDate endDate = LocalDate.parse(toValue.trim());

            if (endDate.isBefore(startDate)) {
                throw new IllegalArgumentException("End date must not be before start date.");
            }
            return new LocalDate[]{startDate, endDate};
        } catch (DateTimeParseException exception) {
            throw new IllegalArgumentException("Invalid date format. Please use YYYY-MM-DD.");
        }
    }

    private String createRevenueLabel(LocalDate startDate, LocalDate endDate) {
        if (startDate.equals(endDate)) {
            return "Revenue for " + startDate;
        }
        return "Revenue from " + startDate + " to " + endDate;
    }

    private boolean hasPermission(HttpSession session) {
        String role = (String) session.getAttribute("role");
        if (role == null) {
            Users user = (Users) session.getAttribute("user");
            if (user != null) {
                role = user.getRole();
            }
        }
        return "Admin".equalsIgnoreCase(role) || "Staff".equalsIgnoreCase(role);
    }

    @Override
    public String getServletInfo() {
        return "Displays hotel dashboard statistics.";
    }
}
