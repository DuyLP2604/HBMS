package service;

import com.google.gson.JsonObject;
import dao.BookingDAO;
import dao.WalletDAO;
import dto.PayOsLink;
import dto.WalletSummary;
import entity.Booking;
import entity.Payment;
import entity.Transaction;
import entity.Paymentmethod;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.PersistenceManager;

/** Calculates booking payments and records wallet or external payments. */
public class PaymentService {

    private static final Logger LOGGER = Logger.getLogger(PaymentService.class.getName());
    private final PayOsService payOsService = new PayOsService();

    /** Load the booking only if it belongs to the customer. */
    public Booking getBookingForPayment(String bookingID, int userID) {
        if (bookingID == null || bookingID.isBlank() || userID <= 0) {
            return null;
        }
        try (EntityManager em = PersistenceManager.createEntityManager()) {
            TypedQuery<Booking> query = em.createQuery("SELECT b FROM Booking b JOIN FETCH b.customerID c JOIN FETCH c.userID WHERE b.bookingID = :bookingID AND c.userID.userID = :userID", Booking.class);
            query.setParameter("bookingID", bookingID.trim());
            query.setParameter("userID", userID);
            query.setHint("jakarta.persistence.cache.retrieveMode", jakarta.persistence.CacheRetrieveMode.BYPASS);
            query.setHint("jakarta.persistence.cache.storeMode", jakarta.persistence.CacheStoreMode.REFRESH);
            List<Booking> bookings = query.setMaxResults(1).getResultList();
            return bookings.isEmpty() ? null : bookings.get(0);
        }
    }

    /** Read the payment summary for a booking owned by the customer. */
    public Map<String, Object> getPaymentSummary(String bookingID, int userID) {
        Booking booking = getBookingForPayment(bookingID, userID);
        if (booking == null) {
            throw new IllegalArgumentException("The requested booking was not found.");
        }
        BookingDAO dao = new BookingDAO();
        if ("PENDING_PAYMENT".equals(booking.getBookingStatus())) {
            dao.expirePendingBookings(booking.getCustomerID().getCustomerID());
        }
        Map<String, Object> summary = dao.getPaymentSummary(booking.getBookingID());
        if (summary.isEmpty()) {
            throw new IllegalStateException("The booking payment summary is unavailable.");
        }
        return summary;
    }

    /** Calculate the amount due for the current booking stage and read the wallet balance. */
    public PaymentRequest createPaymentRequest(String bookingID, int userID) {
        Map<String, Object> summary = getPaymentSummary(bookingID, userID);
        String status = String.valueOf(summary.get("bookingStatus"));
        boolean initial = summary.get("firstPaidAt") == null;
        if ((initial && !"PENDING_PAYMENT".equals(status)) || (!initial && !Set.of("CONFIRMED", "ASSIGNED", "CHECKED_IN").contains(status))) {
            throw new IllegalStateException("This booking no longer accepts payments.");
        }
        String type = initial ? String.valueOf(summary.get("paymentOption")) : "BALANCE";
        if (!Set.of("DEPOSIT", "FULL", "BALANCE").contains(type)) {
            throw new IllegalStateException("The booking payment option is invalid.");
        }
        // Before arrival, clear room charges only. Extra services remain due at checkout.
        String amountKey = initial ? "initialRequiredAmount"
                : ("CHECKED_IN".equals(status) ? "remainingAmount" : "roomRemainingAmount");
        Object value = summary.get(amountKey);
        if (!(value instanceof BigDecimal) || ((BigDecimal) value).signum() <= 0) {
            throw new IllegalStateException("This booking has no outstanding payment.");
        }
        BigDecimal walletBalance = null;
        try {
            walletBalance = loadWalletBalance(userID);
        } catch (IllegalStateException exception) {
            LOGGER.log(Level.WARNING, "Unable to offer wallet payment.", exception);
        }
        return new PaymentRequest(bookingID.trim(), userID, type, (BigDecimal) value, walletBalance);
    }

    // Compatibility entry point for initial payments. Balance payments require a saved PaymentRequest.
    public Payment processPayment(String bookingID, String methodID, int userID) {
        PaymentRequest paymentRequest = createPaymentRequest(bookingID, userID);
        if ("BALANCE".equals(paymentRequest.getPaymentType())) {
            throw new IllegalStateException("Open the payment page to pay the remaining balance.");
        }
        return processPayment(paymentRequest, methodID, userID);
    }

    // The PayOS webhook confirms online QR payments.
    public Payment processPayment(PaymentRequest paymentRequest, String methodID, int userID) {
        return processPayment(paymentRequest, methodID, userID, false);
    }

    /** Record a payment requested by the booking customer. */
    public Payment processPayment(PaymentRequest paymentRequest, String methodID, int userID, boolean useWallet) {
        return processPayment(paymentRequest, methodID, userID, useWallet, userID, false);
    }

    /** Record a receptionist payment using the customer's authorization when required. */
    public Payment collectAtCounter(PaymentRequest paymentRequest, String methodID, int actorUserID,
            boolean useWallet, boolean walletAuthorized, String reference) {
        if (paymentRequest == null) {
            throw new IllegalArgumentException("Reload the payment page.");
        }
        if (!isReceptionist(actorUserID)) {
            throw new SecurityException("Only receptionists can collect counter payments.");
        }
        if (useWallet && !walletAuthorized) {
            throw new IllegalArgumentException("The customer must authorize wallet use.");
        }
        if (!java.util.Set.of("PT03", "PT02", "PT01").contains(methodID)) {
            throw new IllegalArgumentException("Choose Cash, Internal Wallet or VietQR.");
        }
        if (useWallet && paymentRequest.getOfferedWalletAmount().compareTo(paymentRequest.getAmount()) >= 0) {
            methodID = "PT02";
        }
        synchronized (paymentRequest) {
            if (paymentRequest.methodID == null) {
                paymentRequest.transactionCode = "PT01".equals(methodID) ? reference : "COUNTER-" + UUID.randomUUID();
                paymentRequest.transactionID = "PT01".equals(methodID) ? reference : null;
            } else if ("PT01".equals(methodID) && !paymentRequest.transactionCode.equals(reference)) {
                throw new IllegalArgumentException("Retry with the same bank reference or reload the page.");
            }
            if (paymentRequest.transactionCode == null || paymentRequest.transactionCode.isBlank()
                    || paymentRequest.transactionCode.length() > 100) {
                throw new IllegalArgumentException("Enter a bank transaction reference (maximum 100 characters).");
            }
            return processPayment(paymentRequest, methodID, paymentRequest.getUserID(), useWallet, actorUserID, walletAuthorized);
        }
    }
    
    //process payment with procedure
    private Payment processPayment(PaymentRequest paymentRequest, String methodID, int userID,
            boolean useWallet, int actorUserID, boolean walletAuthorized) {

        // Check the payment request and calculate the wallet contribution.
        String selectedMethod = validateAndResolveMethod(paymentRequest, methodID, userID, useWallet, actorUserID);
        BigDecimal walletAmount = calculateWalletAmount(paymentRequest, selectedMethod, useWallet);

        synchronized (paymentRequest) {
            // A retry must use the same method and wallet amount.
            if (paymentRequest.methodID != null && (!paymentRequest.methodID.equals(selectedMethod) || paymentRequest.walletAmount.compareTo(walletAmount) != 0)) {
                throw new IllegalStateException("This request already uses another payment method. Reload the payment page to change it.");
            }

            Booking booking = getBookingForPayment(paymentRequest.getBookingID(), userID);
            if (booking == null) {
                throw new IllegalArgumentException("The requested booking was not found.");
            }
            if ("PENDING_PAYMENT".equals(booking.getBookingStatus())) {
                new BookingDAO().expirePendingBookings(booking.getCustomerID().getCustomerID());
            }

            Paymentmethod method = findMethod(selectedMethod);
            if (method == null) {
                throw new IllegalArgumentException("The selected payment method does not exist.");
            }

            // Keep the payer and wallet owner so SQL can check authorization.
            paymentRequest.actorUserID = actorUserID;
            paymentRequest.walletAuthorizedBy = walletAuthorized ? userID : null;
            paymentRequest.methodID = selectedMethod;
            paymentRequest.walletAmount = walletAmount;
            
            //call paymeny procedure
            return executePaymentTransaction(paymentRequest, booking, method);
        }
    }

    /** Check the payment method and decide whether the wallet can cover the amount. */
    private String validateAndResolveMethod(PaymentRequest paymentRequest, String methodID, int userID, boolean useWallet, int actorUserID) {
        if (paymentRequest == null || paymentRequest.getUserID() != userID || userID <= 0) {
            throw new IllegalArgumentException("The payment request is invalid. Reload the payment page.");
        }

        String selectedMethod = methodID == null ? "" : methodID.trim();
        BigDecimal walletAmount = useWallet ? paymentRequest.getOfferedWalletAmount() : BigDecimal.ZERO;

        if (useWallet && walletAmount.signum() <= 0) {
            throw new IllegalArgumentException("No wallet balance is available. Reload the page or pay using an external method.");
        }
        if (useWallet && walletAmount.compareTo(paymentRequest.getAmount()) == 0) {
            selectedMethod = "PT02";
        }
        if ("PT02".equals(selectedMethod)) {
            // Check the wallet amount
            if (paymentRequest.getOfferedWalletAmount().compareTo(paymentRequest.getAmount()) < 0) {
                throw new IllegalArgumentException("Your wallet cannot cover the full payment. Select an external method and use your wallet for part of it.");
            }
        }
        if (!Set.of("PT01", "PT02", "PT03").contains(selectedMethod)) {
            throw new IllegalArgumentException("Please select a valid payment method.");
        }
        if ("PT01".equals(selectedMethod) && actorUserID == userID) {
            throw new IllegalArgumentException("VietQR is awaiting verification. Displaying or scanning the QR does not confirm a payment.");
        }
        if ("PT03".equals(selectedMethod) && actorUserID == userID) {
            throw new IllegalArgumentException("Cash payments must be recorded by staff.");
        }

        return selectedMethod;
    }
    
    /** Return the wallet portion of this payment. */
    private BigDecimal calculateWalletAmount(PaymentRequest paymentRequest, String selectedMethod, boolean useWallet) {
        if ("PT02".equals(selectedMethod)) {
            return paymentRequest.getAmount();
        }
        return useWallet ? paymentRequest.getOfferedWalletAmount() : BigDecimal.ZERO;
    }

    /** Record the payment and any wallet debit in one transaction. */
    private Payment executePaymentTransaction(PaymentRequest paymentRequest, Booking booking, Paymentmethod method) {
        try (Connection connection = openConnection()) {
            connection.setAutoCommit(false);
            try {
                // Use sp_getapplock to prevent concurrent payment and wallet writes.
                execute(connection, "SELECT TOP (1) UserID FROM dbo.USERS; DECLARE @LockResult int; EXEC @LockResult = sys.sp_getapplock @Resource = N'HBMS:booking-wallet-write', @LockMode = 'Exclusive', @LockOwner = 'Transaction', @LockTimeout = 10000; IF @LockResult < 0 THROW 51000, 'System busy. Please retry the request.', 1;", null);

                if (paymentRequest.paymentID == null || isIDUsedByAnotherRequest(connection, paymentRequest)) {
                    paymentRequest.paymentID = generatePaymentID(connection);
                }

                // SP_RECORD_PAYMENT checks the live balance and records any wallet debit.
                execute(connection, "EXEC dbo.SP_RECORD_PAYMENT @PaymentID = ?, @BookingID = ?, @ActorUserID = ?, @PaymentType = ?, @Amount = ?, @MethodID = ?, @TransactionCode = ?, @WalletAmount = ?, @WalletAuthorizedBy = ?, @TransactionID = ?;", paymentRequest);
                Payment payment = readPayment(connection, paymentRequest, booking, method);

                connection.commit();
                return payment;
            } catch (SQLException | RuntimeException exception) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackError) {
                    exception.addSuppressed(rollbackError);
                }
                throw exception;
            }
        } catch (SQLException exception) {
            throw new IllegalStateException(paymentError(exception), exception);
        } finally {
            try {
                clearCache();
            } catch (RuntimeException exception) {
                LOGGER.log(Level.WARNING, "Unable to clear the payment cache.", exception);
            }
        }
    }

    /** Read the current balance of the customer's wallet. */
    protected BigDecimal loadWalletBalance(int userID) {
        WalletSummary wallet = new WalletDAO().getWalletByUserID(userID);
        return wallet == null ? null : wallet.getBalance();
    }

    protected boolean isReceptionist(int userID) {
        return new dao.EmployeeDAO().isReceptionistByUserId(userID);
    }

    protected Paymentmethod findMethod(String methodID) {
        try (EntityManager em = PersistenceManager.createEntityManager()) {
            return em.find(Paymentmethod.class, methodID);
        }
    }

    protected Connection openConnection() throws SQLException {
        return PersistenceManager.openConnection();
    }

    protected void clearCache() {
        PersistenceManager.getEMF().getCache().evictAll();
    }

    /** Check whether another request already used this payment ID. */
    private boolean isIDUsedByAnotherRequest(Connection connection, PaymentRequest request) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT p.BookingID, p.PaymentType, p.Amount, p.WalletAmount, p.MethodID, t.TransactionCode FROM dbo.PAYMENT AS p LEFT JOIN dbo.[TRANSACTION] AS t ON t.TransactionID = p.TransactionID WHERE p.PaymentID = ?")) {
            statement.setString(1, request.paymentID);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    return false;
                }
                String transactionCode = "PT02".equals(request.methodID) ? "WALLET-" + request.paymentID : request.transactionCode;
                return !request.getBookingID().equals(result.getString("BookingID").trim()) || !request.getPaymentType().equals(result.getString("PaymentType")) || request.getAmount().compareTo(result.getBigDecimal("Amount")) != 0 || request.walletAmount.compareTo(result.getBigDecimal("WalletAmount")) != 0 || !request.methodID.equals(result.getString("MethodID")) || !java.util.Objects.equals(transactionCode, result.getString("TransactionCode"));
            }
        }
    }

    /** Generate the next sequential payment ID. */
    private String generatePaymentID(Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT COALESCE(MAX(TRY_CONVERT(int, SUBSTRING(PaymentID, 3, 4))), 0) FROM dbo.PAYMENT WHERE PaymentID LIKE 'PM[0-9][0-9][0-9][0-9]'"); ResultSet result = statement.executeQuery()) {
            if (!result.next() || result.getInt(1) >= 9999) {
                throw new IllegalStateException("The payment ID limit has been reached.");
            }
            return String.format(Locale.ROOT, "PM%04d", result.getInt(1) + 1);
        }
    }

    private void execute(Connection connection, String sql, PaymentRequest request) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            if (request != null) {
                statement.setString(1, request.paymentID);
                statement.setString(2, request.getBookingID());
                statement.setInt(3, request.actorUserID);
                statement.setString(4, request.getPaymentType());
                statement.setBigDecimal(5, request.getAmount());
                statement.setString(6, request.methodID);
                statement.setString(7, request.transactionCode);
                statement.setBigDecimal(8, request.walletAmount);
                if (request.walletAuthorizedBy == null) {
                    statement.setNull(9, java.sql.Types.INTEGER);
                } else {
                    statement.setInt(9, request.walletAuthorizedBy);
                }
                statement.setString(10, request.transactionID);
            }
            boolean hasResult = statement.execute();
            while (true) {
                if (hasResult) {
                    try (ResultSet result = statement.getResultSet()) {
                        while (result.next()) {
                            // Consume procedure results so errors after earlier result sets are not missed.
                        }
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults(Statement.CLOSE_CURRENT_RESULT);
            }
        }
    }

    private Payment readPayment(Connection connection, PaymentRequest request, Booking booking, Paymentmethod method) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT p.PaymentTime, p.Amount, p.WalletAmount, p.Status, p.TransactionID, t.id AS TransactionRowID, t.TransactionCode, t.TransactionType, t.TransactionValue FROM dbo.PAYMENT AS p JOIN dbo.[TRANSACTION] AS t ON t.TransactionID = p.TransactionID WHERE p.PaymentID = ? AND p.BookingID = ?")) {
            statement.setString(1, request.paymentID);
            statement.setString(2, request.getBookingID());
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    throw new IllegalStateException("The payment result could not be confirmed.");
                }
                Payment payment = new Payment();
                payment.setPaymentID(request.paymentID);
                payment.setBookingID(booking);
                payment.setMethodID(method);
                payment.setPaymentTime(result.getTimestamp("PaymentTime"));
                payment.setAmount(result.getBigDecimal("Amount"));
                payment.setWalletAmount(result.getBigDecimal("WalletAmount"));
                payment.setPaymentType(request.getPaymentType());
                payment.setStatus(result.getString("Status"));
                Transaction transaction = new Transaction(result.getLong("TransactionRowID"),
                        result.getString("TransactionID"), result.getString("TransactionType"),
                        result.getBigDecimal("TransactionValue"));
                transaction.setTransactionCode(result.getString("TransactionCode"));
                payment.setTransactionID(transaction);
                return payment;
            }
        }
    }

    public PayOsLink createGatewayLink(long orderCode, PaymentRequest request, String returnUrl, String cancelUrl) throws Exception {
        if (request == null || request.getAmount().signum() <= 0) {
            throw new IllegalArgumentException("Pay request invalid or pay amount must greater than 0.");
        }

        Booking booking = getBookingForPayment(request.getBookingID(), request.getUserID());
        long expiredAtEpochSeconds = (booking != null && booking.getPaymentDeadline() != null)
                ? booking.getPaymentDeadline().getTime() / 1000
                : (System.currentTimeMillis() / 1000) + (15 * 60);

        String description = "Pay for " + request.getBookingID();
        return payOsService.createPaymentLink(orderCode, request.getAmount(), description, returnUrl, cancelUrl, expiredAtEpochSeconds);
    }

    /**
     * Overload khởi tạo link PayOS tự sinh orderCode nếu không truyền sẵn.
     *
     * @param request
     * @param returnUrl
     * @param cancelUrl
     * @return
     * @throws java.lang.Exception
     */
    public PayOsLink createGatewayLink(PaymentRequest request, String returnUrl, String cancelUrl) throws Exception {
        long orderCode = Long.parseLong(String.valueOf(System.currentTimeMillis()).substring(5) + request.getUserID());
        return createGatewayLink(orderCode, request, returnUrl, cancelUrl);
    }

    /**
     * Xác thực dữ liệu Webhook từ PayOS. Hàm này bọc logic kiểm tra chữ ký để
     * Controller Controller bên ngoài chỉ cần tương tác duy nhất với
     * PaymentService.
     *
     * @param webhookData
     * @return
     */
    public boolean verifyGatewayWebhook(JsonObject webhookData) {
        return payOsService.verifyWebhook(webhookData);
    }

    private String paymentError(SQLException exception) {
        switch (exception.getErrorCode()) {
            case 51000:
                return "The payment system is busy. Retry the same payment request.";
            case 51030:
            case 51031:
                return "The requested booking was not found or is not yours.";
            case 51034:
                return "The selected payment method does not exist.";
            case 51035:
                return "Cash payments must be recorded by staff.";
            case 51039:
                return "This booking no longer accepts payments.";
            case 51040:
                return "The payment deadline has expired.";
            case 51042:
            case 51043:
            case 51044:
            case 51045:
                return "The booking amount or payment state has changed. Reload the payment page.";
            case 51046:
                return "Your wallet balance has changed or is insufficient. Reload the payment page to review the amounts.";
            case 51047:
                return "The wallet contribution is invalid. Reload the payment page.";
            case 51210:
                return "A verified bank transaction reference is required for VietQR.";
            case 51048:
                return "Only the wallet owner can authorize a wallet contribution.";
            default:
                return "Payment could not be confirmed. Check your booking or retry the same request.";
        }
    }
}
